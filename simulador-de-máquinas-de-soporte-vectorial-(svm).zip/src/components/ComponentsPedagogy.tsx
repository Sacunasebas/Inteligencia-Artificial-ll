import React, { useState } from 'react';
import {
  Layers,
  Sparkles,
  ShieldAlert,
  Maximize2,
  Workflow,
  CheckCircle2,
  ChevronRight,
  HelpCircle,
  ArrowRight,
  Zap,
  Split,
  Eye
} from 'lucide-react';

export const ComponentsPedagogy: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'hyperplane' | 'support_vectors' | 'margin' | 'parameter_c' | 'kernel_trick'>('hyperplane');

  // Interactive mini-demos state
  const [demoB, setDemoB] = useState<number>(0);
  const [demoWAngle, setDemoWAngle] = useState<number>(45);
  const [demoC, setDemoC] = useState<number>(1);
  const [removedNonSvCount, setRemovedNonSvCount] = useState<number>(0);

  return (
    <div className="space-y-6 max-w-6xl mx-auto">
      {/* Hero Pedagogical Header */}
      <div className="bg-gradient-to-r from-indigo-900 via-indigo-800 to-blue-900 rounded-2xl p-6 sm:p-8 text-white shadow-md relative overflow-hidden">
        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 text-indigo-200 text-xs font-semibold backdrop-blur-xs mb-3 border border-white/10">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>Guía Interactiva & Pedagógica</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight text-white mb-2">
            Anatomía de las Máquinas de Soporte Vectorial (SVM)
          </h1>
          <p className="text-indigo-200 text-sm leading-relaxed">
            Las SVM son uno de los algoritmos de Machine Learning más elegantes y robustos de la historia.
            Descubre cómo cada componente geométrico colabora para clasificar las viviendas de Estados Unidos con máxima confianza.
          </p>
        </div>
      </div>

      {/* Navigation Tabs for Components */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2">
        <button
          onClick={() => setActiveTab('hyperplane')}
          className={`flex flex-col items-center text-center p-3 rounded-xl border transition-all ${
            activeTab === 'hyperplane'
              ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
              : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
          }`}
        >
          <Split className="w-5 h-5 mb-1 text-current" />
          <span className="text-xs font-bold">1. El Hiperplano</span>
          <span className="text-[10px] opacity-80">La frontera óptima</span>
        </button>

        <button
          onClick={() => setActiveTab('support_vectors')}
          className={`flex flex-col items-center text-center p-3 rounded-xl border transition-all ${
            activeTab === 'support_vectors'
              ? 'bg-amber-600 text-white border-amber-600 shadow-xs'
              : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
          }`}
        >
          <Sparkles className="w-5 h-5 mb-1 text-amber-400" />
          <span className="text-xs font-bold">2. Vectores Soporte</span>
          <span className="text-[10px] opacity-80">Los pilares críticos</span>
        </button>

        <button
          onClick={() => setActiveTab('margin')}
          className={`flex flex-col items-center text-center p-3 rounded-xl border transition-all ${
            activeTab === 'margin'
              ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
              : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
          }`}
        >
          <Maximize2 className="w-5 h-5 mb-1 text-current" />
          <span className="text-xs font-bold">3. El Margen (2/||w||)</span>
          <span className="text-[10px] opacity-80">La autopista segura</span>
        </button>

        <button
          onClick={() => setActiveTab('parameter_c')}
          className={`flex flex-col items-center text-center p-3 rounded-xl border transition-all ${
            activeTab === 'parameter_c'
              ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
              : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
          }`}
        >
          <ShieldAlert className="w-5 h-5 mb-1 text-current" />
          <span className="text-xs font-bold">4. Parámetro C & Holguras</span>
          <span className="text-[10px] opacity-80">Tolerancia a errores</span>
        </button>

        <button
          onClick={() => setActiveTab('kernel_trick')}
          className={`flex flex-col items-center text-center p-3 rounded-xl border transition-all ${
            activeTab === 'kernel_trick'
              ? 'bg-purple-600 text-white border-purple-600 shadow-xs'
              : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
          }`}
        >
          <Workflow className="w-5 h-5 mb-1 text-current" />
          <span className="text-xs font-bold">5. Truco del Kernel</span>
          <span className="text-[10px] opacity-80">Saltar a dimensión superior</span>
        </button>
      </div>

      {/* TAB CONTENT 1: EL HIPERPLANO */}
      {activeTab === 'hyperplane' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-6">
          <div className="border-b border-slate-100 pb-4">
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <Split className="w-5 h-5 text-indigo-600" />
              ¿Qué es exactamente el Hiperplano de Decisión?
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              La frontera geométrica que separa las dos categorías de viviendas de Estados Unidos.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4 text-sm text-slate-700 leading-relaxed">
              <p>
                Un <strong>hiperplano</strong> es una generalización matemática de un plano a cualquier dimensión $N$.
                Su dimensión espacial siempre es exactamente $(N - 1)$:
              </p>
              <ul className="space-y-2 text-xs">
                <li className="flex items-start gap-2 bg-slate-50 p-2.5 rounded-lg border border-slate-200">
                  <span className="font-bold text-indigo-700 shrink-0">En 2 Dimensiones:</span>
                  <span>Es una <strong>línea recta</strong> que divide el plano: $w_1 x_1 + w_2 x_2 + b = 0$.</span>
                </li>
                <li className="flex items-start gap-2 bg-slate-50 p-2.5 rounded-lg border border-slate-200">
                  <span className="font-bold text-indigo-700 shrink-0">En 3 Dimensiones:</span>
                  <span>Es una <strong>superficie plana</strong> que rebana el espacio: $w_1 x_1 + w_2 x_2 + w_3 x_3 + b = 0$.</span>
                </li>
                <li className="flex items-start gap-2 bg-slate-50 p-2.5 rounded-lg border border-slate-200">
                  <span className="font-bold text-indigo-700 shrink-0">En N Dimensiones:</span>
                  <span>Es un hiperplano $w^T x + b = 0$, donde el vector normal $w$ apunta perpendicularmente.</span>
                </li>
              </ul>

              <div className="bg-indigo-50 border border-indigo-200 rounded-xl p-4 text-xs text-indigo-950">
                <span className="font-bold block mb-1">Regla de Clasificación en Tiempo Real:</span>
                Dada una vivienda desconocida x = (superficie, ingreso):
                <div className="my-2 p-2 bg-white rounded font-mono text-center font-bold text-indigo-700 border border-indigo-200">
                  f(x) = sign(w · x + b)
                </div>
                Si $f(x) &gt; 0$ → <strong>Vivienda Premium / Alto Valor</strong> (+1).<br />
                Si $f(x) &lt; 0$ → <strong>Vivienda Estándar / Accesible</strong> (-1).
              </div>
            </div>

            {/* Interactive Sandbox for Plane Orientation */}
            <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 flex flex-col justify-between">
              <div>
                <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5 mb-2">
                  <Eye className="w-4 h-4 text-indigo-600" />
                  Mini-Laboratorio: Modifica los Pesos w y el Sesgo b
                </span>
                <p className="text-[11px] text-slate-500 mb-3">
                  Observa cómo el vector $w$ gira el hiperplano y el sesgo $b$ lo traslada respecto al origen:
                </p>

                {/* SVG Visualizer */}
                <div className="w-full h-44 bg-white rounded-lg border border-slate-200 relative overflow-hidden flex items-center justify-center">
                  <svg viewBox="0 0 200 140" className="w-full h-full">
                    {/* Grid */}
                    <line x1="100" y1="0" x2="100" y2="140" stroke="#e2e8f0" strokeWidth="1" />
                    <line x1="0" y1="70" x2="200" y2="70" stroke="#e2e8f0" strokeWidth="1" />

                    {/* Plane line */}
                    {(() => {
                      const rad = (demoWAngle * Math.PI) / 180;
                      const cos = Math.cos(rad);
                      const sin = Math.sin(rad);
                      const cx = 100 - sin * demoB * 2;
                      const cy = 70 + cos * demoB * 2;
                      const x1 = cx - cos * 150;
                      const y1 = cy - sin * 150;
                      const x2 = cx + cos * 150;
                      const y2 = cy + sin * 150;
                      return (
                        <g>
                          <line x1={x1} y1={y1} x2={x2} y2={y2} stroke="#4f46e5" strokeWidth="3" />
                          {/* Normal vector arrow */}
                          <line x1={cx} y1={cy} x2={cx - sin * 25} y2={cy - cos * 25} stroke="#dc2626" strokeWidth="2" markerEnd="url(#arrow)" />
                        </g>
                      );
                    })()}
                  </svg>
                  <span className="absolute bottom-1 right-2 text-[10px] text-slate-400 font-mono">
                    w=[cos({demoWAngle}°), sin({demoWAngle}°)], b={demoB}
                  </span>
                </div>
              </div>

              {/* Sliders */}
              <div className="space-y-3 mt-3">
                <div>
                  <div className="flex justify-between text-xs text-slate-600 mb-1">
                    <span>Ángulo del Vector Normal w:</span>
                    <strong className="font-mono">{demoWAngle}°</strong>
                  </div>
                  <input
                    type="range"
                    min="0"
                    max="180"
                    value={demoWAngle}
                    onChange={(e) => setDemoWAngle(parseInt(e.target.value))}
                    className="w-full accent-indigo-600 h-1.5 bg-slate-200 rounded"
                  />
                </div>
                <div>
                  <div className="flex justify-between text-xs text-slate-600 mb-1">
                    <span>Desplazamiento del Sesgo b:</span>
                    <strong className="font-mono">{demoB}</strong>
                  </div>
                  <input
                    type="range"
                    min="-20"
                    max="20"
                    value={demoB}
                    onChange={(e) => setDemoB(parseInt(e.target.value))}
                    className="w-full accent-indigo-600 h-1.5 bg-slate-200 rounded"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB CONTENT 2: VECTORES DE SOPORTE */}
      {activeTab === 'support_vectors' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-6">
          <div className="border-b border-slate-100 pb-4">
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-amber-500" />
              ¿Por qué se llaman "Vectores de Soporte"?
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              El secreto de la eficiencia de las SVM: solo una pequeña fracción de datos define todo el modelo.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4 text-sm text-slate-700 leading-relaxed">
              <p>
                A diferencia de la regresión logística o las redes neuronales donde <em>todos los datos</em> influyen en la función de coste,
                en una Máquina de Soporte Vectorial ocurre algo asombroso:
              </p>

              <div className="p-3 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-950 space-y-2">
                <span className="font-bold flex items-center gap-1.5 text-amber-800">
                  <CheckCircle2 className="w-4 h-4 text-amber-600" />
                  La Propiedad de Dispersión (Sparsity):
                </span>
                <p>
                  Solo las casas situadas en la frontera crítica o que penetran el margen reciben un multiplicador de Lagrange α_i &gt; 0.
                  A estas casas se les llama <strong>Vectores de Soporte</strong>.
                </p>
                <p>
                  Para todas las demás viviendas alejadas de la frontera, <strong>α_i = 0</strong>.
                  Podrías añadir 10,000 casas más en el centro de las clases y la solución matemática sería <em>idéntica</em>.
                </p>
              </div>

              <p className="text-xs text-slate-600">
                Piénsalo como el puente Golden Gate de San Francisco: solo los cables y pilares principales soportan la tensión del puente;
                el resto de la estructura se apoya en ellos.
              </p>
            </div>

            {/* Interactive Invariance Proof Demo */}
            <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 flex flex-col justify-between">
              <div>
                <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5 mb-1">
                  🧪 Experimento Mental: "Prueba de Invarianza"
                </span>
                <p className="text-[11px] text-slate-500 mb-3">
                  Prueba a eliminar viviendas que no son vectores de soporte y comprueba que el hiperplano no se altera:
                </p>

                <div className="bg-white rounded-lg p-3 border border-slate-200 text-xs space-y-2 mb-3">
                  <div className="flex justify-between">
                    <span className="text-slate-600">Total casas en el dataset:</span>
                    <strong className="font-mono">30 viviendas</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">Vectores de Soporte activos:</span>
                    <strong className="font-mono text-amber-600">6 viviendas (20%)</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-600">Casas eliminadas sin afectar al modelo:</span>
                    <strong className="font-mono text-indigo-600">{removedNonSvCount} de 24</strong>
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <button
                  type="button"
                  onClick={() => setRemovedNonSvCount(Math.min(24, removedNonSvCount + 4))}
                  className="w-full py-2 px-3 bg-amber-500 hover:bg-amber-600 text-white font-semibold text-xs rounded-lg transition-colors shadow-xs"
                >
                  Eliminar 4 casas no-soporte ({removedNonSvCount}/24)
                </button>
                <button
                  type="button"
                  onClick={() => setRemovedNonSvCount(0)}
                  className="w-full py-1.5 px-3 bg-slate-200 hover:bg-slate-300 text-slate-700 font-medium text-xs rounded-lg transition-colors"
                >
                  Restaurar dataset completo
                </button>
                {removedNonSvCount > 0 && (
                  <p className="text-[10px] text-emerald-700 font-medium text-center">
                    ✨ ¡Comprobado! El hiperplano sigue exactamente en la misma posición matemática.
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB CONTENT 3: EL MARGEN MAXIMO */}
      {activeTab === 'margin' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-6">
          <div className="border-b border-slate-100 pb-4">
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <Maximize2 className="w-5 h-5 text-blue-600" />
              El Margen Máximo: La Autopista entre Clases
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              ¿Por qué SVM no se conforma con cualquier línea separadora y busca la más ancha posible?
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-3 text-sm text-slate-700 leading-relaxed">
              <p>
                Existen infinitas líneas rectas capaces de separar dos clases limpias. Pero muchas pasan muy cerca de algún dato,
                haciéndolas vulnerables a equivocarse cuando llegue una casa con ligeras fluctuaciones de mercado.
              </p>

              <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 text-xs space-y-2">
                <span className="font-bold text-blue-900 block">Fórmula del Ancho del Margen Geométrico:</span>
                <div className="p-2.5 bg-white rounded-lg text-center font-mono font-bold text-blue-800 text-sm border border-blue-200">
                  Margen = 2 / ||w||
                </div>
                <p className="text-blue-900/80">
                  Donde ||w|| = √(w₁² + w₂² + ...) es la norma euclídea del vector de pesos.
                </p>
                <p className="text-blue-900/80">
                  Para hacer el margen lo más grande posible, <strong>debemos minimizar ||w||</strong>.
                  Por conveniencia de optimización cuadrática, esto se formula como: min ½ ||w||².
                </p>
              </div>

              <p className="text-xs text-slate-500">
                Un margen amplio equivale a una gran "calle de seguridad": ninguna vivienda queda a pocos milímetros de la frontera de decisión.
              </p>
            </div>

            <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 flex flex-col justify-center items-center text-center">
              <div className="w-full max-w-xs space-y-3">
                <div className="h-32 bg-white rounded-lg border border-slate-200 p-2 flex items-center justify-center relative">
                  {/* Visual Lane representation */}
                  <div className="w-full h-16 bg-indigo-50 border-y-2 border-dashed border-indigo-400 flex items-center justify-center relative">
                    <div className="w-full h-0.5 bg-indigo-600"></div>
                    <span className="absolute text-[11px] font-bold text-indigo-700 bg-white px-2 py-0.5 rounded shadow-2xs">
                      Margen 2 / ||w||
                    </span>
                  </div>
                </div>
                <div className="text-xs font-semibold text-slate-800">
                  Franja de Margen Máximo
                </div>
                <p className="text-[11px] text-slate-500">
                  Las líneas punteadas corresponden a $w \cdot x + b = +1$ y $w \cdot x + b = -1$.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB CONTENT 4: PARAMETRO C Y HOLGURAS */}
      {activeTab === 'parameter_c' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-6">
          <div className="border-b border-slate-100 pb-4">
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-emerald-600" />
              Margen Duro vs Blando y el Parámetro C
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Cómo SVM maneja datos ruidosos o viviendas atípicas en el mercado real de EE.UU.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4 text-sm text-slate-700 leading-relaxed">
              <p>
                En el mundo real, los datos rara vez son perfectamente separables por una línea pura.
                Puede haber una casa en Detroit con mucho metraje pero precio bajo, o un mini-apartamento en Manhattan con precio astronómico.
              </p>

              <div className="space-y-2 text-xs">
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200">
                  <span className="font-bold text-slate-800 block mb-1">Margen Duro (Hard Margin):</span>
                  <span>Exige separación absoluta sin permitir ni una sola vivienda en el margen. Es hipersensible al ruido.</span>
                </div>
                <div className="p-3 bg-emerald-50 rounded-lg border border-emerald-200 text-emerald-950">
                  <span className="font-bold block mb-1">Margen Blando (Soft Margin) & Variables de Holgura ξ_i:</span>
                  <span>
                    Permite que ciertas viviendas penetren la franja del margen o se clasifiquen erróneamente, midiendo su distancia de infracción con ξ_i ≥ 0.
                  </span>
                </div>
              </div>

              <div className="bg-slate-100 p-3 rounded-lg font-mono text-center text-xs text-slate-800 font-bold">
                min 1/2 ||w||² + C · ∑ ξ_i
              </div>
            </div>

            {/* Interactive C slider */}
            <div className="bg-slate-50 rounded-xl p-4 border border-slate-200 flex flex-col justify-between">
              <div>
                <span className="text-xs font-bold text-slate-800 flex items-center gap-1.5 mb-2">
                  🎚️ Simulador del Dilema de C
                </span>
                <p className="text-[11px] text-slate-500 mb-3">
                  Ajusta C para ver cómo cambia la filosofía del modelo:
                </p>

                <div className="p-4 bg-white rounded-lg border border-slate-200 mb-4">
                  <div className="text-xs font-bold text-slate-800 mb-1">
                    {demoC < 1 ? (
                      <span className="text-amber-700">Modo C Bajo (Margen Blando y Relajado)</span>
                    ) : demoC > 10 ? (
                      <span className="text-indigo-700">Modo C Alto (Margen Estricto y Rígido)</span>
                    ) : (
                      <span className="text-emerald-700">Modo C Moderado (Equilibrio de Vapnik)</span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-600 leading-relaxed">
                    {demoC < 1
                      ? 'Tolerante con los errores: prioriza una autopista muy amplia. Las casas atípicas no arruinan la orientación general.'
                      : demoC > 10
                      ? 'Cero tolerancia: castiga duramente cada infracción. El margen se contrae al máximo para salvar cada punto.'
                      : 'El compromiso óptimo entre generalización en casas futuras y fidelidad al dataset de entrenamiento.'}
                  </p>
                </div>

                <div className="flex justify-between text-xs text-slate-600 mb-1">
                  <span>Valor de C:</span>
                  <strong className="font-mono text-indigo-700">{demoC.toFixed(1)}</strong>
                </div>
                <input
                  type="range"
                  min="0.1"
                  max="20"
                  step="0.1"
                  value={demoC}
                  onChange={(e) => setDemoC(parseFloat(e.target.value))}
                  className="w-full accent-indigo-600 h-1.5 bg-slate-200 rounded"
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB CONTENT 5: TRUCO DEL KERNEL */}
      {activeTab === 'kernel_trick' && (
        <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-6">
          <div className="border-b border-slate-100 pb-4">
            <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
              <Workflow className="w-5 h-5 text-purple-600" />
              El "Truco del Kernel" (Kernel Trick)
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Cómo resolver problemas no separables proyectándolos a dimensiones superiores sin coste computacional extra.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4 text-sm text-slate-700 leading-relaxed">
              <p>
                Imagina que las viviendas premium se ubican en una zona céntrica circular rodeadas por viviendas estándar.
                Ninguna línea recta en 2D puede separar un círculo de su exterior.
              </p>

              <div className="bg-purple-50 border border-purple-200 rounded-xl p-4 text-xs text-purple-950 space-y-2">
                <span className="font-bold block">La Idea Mágica:</span>
                Si elevamos cada punto $(x, y)$ a una 3ª coordenada $z = x^2 + y^2$, los puntos centrales se quedan abajo
                y los exteriores se elevan en forma de cuenco (paraboloide).
                ¡Ahora un simple plano horizontal 3D puede rebanar y separar ambas clases a la perfección!
              </div>

              <p className="text-xs text-slate-600">
                El <strong>Truco del Kernel</strong> consiste en que nunca necesitamos calcular explícitamente las coordenadas gigantes en alta dimensión;
                basta con calcular una función de similitud $K(x_i, x_j)$.
              </p>
            </div>

            {/* Kernel Comparison Cards */}
            <div className="space-y-2.5">
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs">
                <span className="font-bold text-indigo-700 block mb-0.5">1. Kernel Lineal</span>
                <code className="text-[11px] font-mono text-slate-700 bg-white px-1.5 py-0.5 rounded border border-slate-200">
                  K(x, z) = x · z
                </code>
                <p className="text-slate-500 mt-1 text-[11px]">
                  Frontera plana y rígida. Óptimo cuando las variables ya son linealmente separables (ej: Metraje vs Ingreso).
                </p>
              </div>

              <div className="p-3 bg-purple-50 rounded-xl border border-purple-200 text-xs">
                <span className="font-bold text-purple-800 block mb-0.5">2. Kernel RBF (Radial Basis Function / Gaussiano)</span>
                <code className="text-[11px] font-mono text-purple-900 bg-white px-1.5 py-0.5 rounded border border-purple-200">
                  K(x, z) = exp(-γ ||x - z||²)
                </code>
                <p className="text-purple-800/80 mt-1 text-[11px]">
                  Equivale a proyectar los datos a un espacio de <strong>dimensión infinita</strong>. Crea contornos suaves y bolsas circulares.
                </p>
              </div>

              <div className="p-3 bg-blue-50 rounded-xl border border-blue-200 text-xs">
                <span className="font-bold text-blue-800 block mb-0.5">3. Kernel Polinomial</span>
                <code className="text-[11px] font-mono text-blue-900 bg-white px-1.5 py-0.5 rounded border border-blue-200">
                  K(x, z) = (x · z + 1)^d
                </code>
                <p className="text-blue-800/80 mt-1 text-[11px]">
                  Genera curvas parabólicas o cúbicas que modelan interacciones no lineales entre pares de variables.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
