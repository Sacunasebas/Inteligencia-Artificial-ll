import React, { useState, useMemo } from 'react';
import confetti from 'canvas-confetti';
import { HousingRecord } from '../types';
import { USA_HOUSING_DATASET_30 } from '../data/housingData';
import { Trophy, RefreshCw, Sparkles, CheckCircle2, AlertTriangle, Play, HelpCircle } from 'lucide-react';

export const MiniGameChallenge: React.FC = () => {
  const records = USA_HOUSING_DATASET_30;

  // Normalized coordinates for Superficie (X) and Ingreso Medio (Y)
  const normData = useMemo(() => {
    const minX = 900, maxX = 3800;
    const minY = 30, maxY = 140;
    return records.map((r) => ({
      ...r,
      nx: (r.sqft - minX) / (maxX - minX),
      ny: (r.median_income_k - minY) / (maxY - minY),
    }));
  }, [records]);

  // User controls for manual hyperplane
  const [userAngle, setUserAngle] = useState<number>(52); // degrees
  const [userOffset, setUserOffset] = useState<number>(0.0); // translation offset
  const [userMarginWidth, setUserMarginWidth] = useState<number>(0.14); // margin width in normalized units
  const [showAiSolution, setShowAiSolution] = useState<boolean>(false);

  // Compute User Performance
  const evaluation = useMemo(() => {
    const rad = (userAngle * Math.PI) / 180;
    const nx = Math.cos(rad);
    const ny = Math.sin(rad);

    let correct = 0;
    let collisions = 0;

    normData.forEach((d) => {
      // Distance from point (d.nx, d.ny) to line passing through center (0.5, 0.5) with normal (nx, ny) + offset
      const dist = (d.nx - 0.5) * nx + (d.ny - 0.5) * ny - userOffset;
      const pred = dist >= 0 ? 1 : -1;

      if (pred === d.label) correct++;

      // Check margin collision: if within margin band
      if (Math.abs(dist) < userMarginWidth / 2) {
        collisions++;
      }
    });

    const accuracy = (correct / normData.length) * 100;
    const marginScore = Math.min(50, Math.round((userMarginWidth / 0.25) * 50));
    const accuracyScore = Math.round((accuracy / 100) * 50);
    const collisionPenalty = collisions * 4;
    const totalScore = Math.max(0, Math.min(100, marginScore + accuracyScore - collisionPenalty));

    return {
      accuracy,
      collisions,
      totalScore,
      marginScore,
      accuracyScore,
    };
  }, [normData, userAngle, userOffset, userMarginWidth]);

  // Trigger confetti if high score
  const handleEvaluate = () => {
    setShowAiSolution(true);
    if (evaluation.totalScore >= 75) {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
      });
    }
  };

  const handleReset = () => {
    setUserAngle(30);
    setUserOffset(0.1);
    setUserMarginWidth(0.08);
    setShowAiSolution(false);
  };

  // SVG dimensions
  const svgW = 580;
  const svgH = 380;
  const pad = 40;
  const pw = svgW - pad * 2;
  const ph = svgH - pad * 2;

  const toSvgX = (nx: number) => pad + nx * pw;
  const toSvgY = (ny: number) => pad + (1 - ny) * ph;

  // Manual line endpoints
  const rad = (userAngle * Math.PI) / 180;
  const nx = Math.cos(rad);
  const ny = Math.sin(rad);
  const cx = 0.5;
  const cy = 0.5;
  const dx = -ny;
  const dy = nx;

  // Center point shifted by offset along normal
  const midX = cx + nx * userOffset;
  const midY = cy + ny * userOffset;

  const userLineP1 = { x: toSvgX(midX - dx * 1.5), y: toSvgY(midY - dy * 1.5) };
  const userLineP2 = { x: toSvgX(midX + dx * 1.5), y: toSvgY(midY + dy * 1.5) };

  // Margin boundaries
  const halfM = userMarginWidth / 2;
  const mPlusP1 = { x: toSvgX(midX + nx * halfM - dx * 1.5), y: toSvgY(midY + ny * halfM - dy * 1.5) };
  const mPlusP2 = { x: toSvgX(midX + nx * halfM + dx * 1.5), y: toSvgY(midY + ny * halfM + dy * 1.5) };

  const mMinusP1 = { x: toSvgX(midX - nx * halfM - dx * 1.5), y: toSvgY(midY - ny * halfM - dy * 1.5) };
  const mMinusP2 = { x: toSvgX(midX - nx * halfM + dx * 1.5), y: toSvgY(midY - ny * halfM + dy * 1.5) };

  // Optimal AI Line (preset optimal angle and offset for this feature pair)
  const aiAngle = 48;
  const aiRad = (aiAngle * Math.PI) / 180;
  const aiNx = Math.cos(aiRad);
  const aiNy = Math.sin(aiRad);
  const aiOffset = 0.03;
  const aiMidX = cx + aiNx * aiOffset;
  const aiMidY = cy + aiNy * aiOffset;
  const aiDx = -aiNy;
  const aiDy = aiNx;
  const aiP1 = { x: toSvgX(aiMidX - aiDx * 1.5), y: toSvgY(aiMidY - aiDy * 1.5) };
  const aiP2 = { x: toSvgX(aiMidX + aiDx * 1.5), y: toSvgY(aiMidY + aiDy * 1.5) };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-amber-600 via-amber-500 to-orange-600 rounded-2xl p-6 text-white shadow-md flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-white/20 text-amber-100 text-xs font-semibold mb-2">
            <Trophy className="w-3.5 h-3.5 text-yellow-200" />
            <span>Mini-Juego Pedagógico</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-black">
            El Desafío del Separador Óptimo: Tú vs el SVM
          </h1>
          <p className="text-amber-100 text-xs sm:text-sm mt-1 max-w-2xl leading-relaxed">
            Tu misión es actuar como el optimizador matemático de Vapnik: ajusta el hiperplano y abre el margen lo más ancho posible sin tocar las casas.
          </p>
        </div>

        {/* Score Pill */}
        <div className="bg-white rounded-xl p-3 text-slate-800 text-center shadow-lg border border-amber-200 min-w-[120px]">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Tu Puntaje</span>
          <span className="text-3xl font-black text-amber-600 font-mono">{evaluation.totalScore}</span>
          <span className="text-[10px] text-slate-500 block">/ 100 pts</span>
        </div>
      </div>

      {/* Main Game Interface */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Interactive Canvas */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 p-4 shadow-xs flex flex-col">
          <div className="flex items-center justify-between pb-2 border-b border-slate-100 text-xs mb-2">
            <span className="font-bold text-slate-700">Plano de Viviendas: Superficie vs Ingreso</span>
            <div className="flex items-center gap-3">
              <span className="flex items-center gap-1 text-blue-700">
                <span className="w-2.5 h-2.5 rounded-full bg-blue-600"></span> Premium
              </span>
              <span className="flex items-center gap-1 text-amber-700">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span> Estándar
              </span>
              {showAiSolution && (
                <span className="flex items-center gap-1 text-emerald-700 font-bold">
                  <span className="w-3 h-0.5 bg-emerald-600"></span> Solución SVM
                </span>
              )}
            </div>
          </div>

          <div className="relative w-full aspect-[16/10] bg-slate-50 rounded-xl overflow-hidden border border-slate-200">
            <svg viewBox={`0 0 ${svgW} ${svgH}`} className="w-full h-full">
              {/* Coordinate axis */}
              <line x1={pad} y1={svgH - pad} x2={svgW - pad} y2={svgH - pad} stroke="#cbd5e1" strokeWidth="1.5" />
              <line x1={pad} y1={pad} x2={pad} y2={svgH - pad} stroke="#cbd5e1" strokeWidth="1.5" />

              {/* User Margin Corridor */}
              <polygon
                points={`${mPlusP1.x},${mPlusP1.y} ${mPlusP2.x},${mPlusP2.y} ${mMinusP2.x},${mMinusP2.y} ${mMinusP1.x},${mMinusP1.y}`}
                fill="#fef3c7"
                fillOpacity="0.45"
              />

              {/* User Margin Borders */}
              <line
                x1={mPlusP1.x}
                y1={mPlusP1.y}
                x2={mPlusP2.x}
                y2={mPlusP2.y}
                stroke="#d97706"
                strokeWidth="1.5"
                strokeDasharray="4 3"
              />
              <line
                x1={mMinusP1.x}
                y1={mMinusP1.y}
                x2={mMinusP2.x}
                y2={mMinusP2.y}
                stroke="#d97706"
                strokeWidth="1.5"
                strokeDasharray="4 3"
              />

              {/* User Hyperplane */}
              <line
                x1={userLineP1.x}
                y1={userLineP1.y}
                x2={userLineP2.x}
                y2={userLineP2.y}
                stroke="#b45309"
                strokeWidth="3"
                strokeLinecap="round"
              />

              {/* Optimal AI Hyperplane */}
              {showAiSolution && (
                <line
                  x1={aiP1.x}
                  y1={aiP1.y}
                  x2={aiP2.x}
                  y2={aiP2.y}
                  stroke="#10b981"
                  strokeWidth="3.5"
                  strokeDasharray="6 4"
                />
              )}

              {/* 30 Housing dots */}
              {normData.map((d) => {
                const px = toSvgX(d.nx);
                const py = toSvgY(d.ny);
                const isPremium = d.label === 1;
                return (
                  <circle
                    key={`game-dot-${d.id}`}
                    cx={px}
                    cy={py}
                    r="5.5"
                    fill={isPremium ? '#2563eb' : '#ea580c'}
                    stroke="#ffffff"
                    strokeWidth="1.5"
                  />
                );
              })}
            </svg>

            {/* Labels */}
            <span className="absolute bottom-2 right-6 text-[10px] text-slate-400 font-bold uppercase">
              Superficie (sqft) →
            </span>
            <span className="absolute top-4 left-6 text-[10px] text-slate-400 font-bold uppercase">
              ↑ Ingreso Medio
            </span>
          </div>

          {/* Feedback message */}
          <div className="mt-3 p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs flex items-center justify-between">
            <div className="flex items-center gap-2">
              {evaluation.collisions > 0 ? (
                <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0" />
              ) : (
                <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />
              )}
              <span className="text-slate-700">
                {evaluation.collisions > 0
                  ? `Infracción: ${evaluation.collisions} viviendas invaden tu margen (-${evaluation.collisions * 4} pts)`
                  : '¡Excelente! Margen libre de colisiones.'}
              </span>
            </div>
            <span className="font-bold text-slate-800">
              Precisión: {evaluation.accuracy.toFixed(0)}%
            </span>
          </div>
        </div>

        {/* Right: Game Controls */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between space-y-4">
          <div className="space-y-4">
            <h2 className="text-sm font-bold text-slate-900 border-b border-slate-100 pb-2 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-amber-500" />
              Tus Mandos de Optimización
            </h2>

            {/* Angle Slider */}
            <div>
              <div className="flex justify-between text-xs text-slate-600 mb-1 font-semibold">
                <span>1. Inclinación del Hiperplano:</span>
                <span className="font-mono text-indigo-600">{userAngle}°</span>
              </div>
              <input
                type="range"
                min="10"
                max="80"
                value={userAngle}
                onChange={(e) => setUserAngle(parseInt(e.target.value))}
                className="w-full accent-amber-600 h-1.5 bg-slate-200 rounded cursor-pointer"
              />
            </div>

            {/* Position Offset Slider */}
            <div>
              <div className="flex justify-between text-xs text-slate-600 mb-1 font-semibold">
                <span>2. Posición / Desplazamiento:</span>
                <span className="font-mono text-indigo-600">{userOffset.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min="-0.3"
                max="0.3"
                step="0.01"
                value={userOffset}
                onChange={(e) => setUserOffset(parseFloat(e.target.value))}
                className="w-full accent-amber-600 h-1.5 bg-slate-200 rounded cursor-pointer"
              />
            </div>

            {/* Margin Width Slider */}
            <div>
              <div className="flex justify-between text-xs text-slate-600 mb-1 font-semibold">
                <span>3. Ancho del Margen (Autopista):</span>
                <span className="font-mono text-amber-700">{(userMarginWidth * 10).toFixed(1)} m</span>
              </div>
              <input
                type="range"
                min="0.04"
                max="0.30"
                step="0.01"
                value={userMarginWidth}
                onChange={(e) => setUserMarginWidth(parseFloat(e.target.value))}
                className="w-full accent-amber-600 h-1.5 bg-slate-200 rounded cursor-pointer"
              />
              <p className="text-[10px] text-slate-400 mt-1">
                Abre el margen para sumar más puntos, pero ten cuidado de no aplastar ninguna casa.
              </p>
            </div>

            {/* Score Breakdown Card */}
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs space-y-1.5">
              <div className="flex justify-between text-slate-600">
                <span>Puntos por Margen:</span>
                <span className="font-mono font-bold text-slate-800">+{evaluation.marginScore} / 50</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>Puntos por Precisión:</span>
                <span className="font-mono font-bold text-slate-800">+{evaluation.accuracyScore} / 50</span>
              </div>
              <div className="flex justify-between text-red-600">
                <span>Penalización por invasión:</span>
                <span className="font-mono font-bold">-{evaluation.collisions * 4}</span>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="space-y-2 pt-2 border-t border-slate-100">
            <button
              onClick={handleEvaluate}
              className="w-full py-2.5 px-4 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs shadow-xs transition-colors flex items-center justify-center gap-2"
            >
              <Trophy className="w-4 h-4 text-yellow-300" />
              <span>Evaluar contra el SVM Matemático</span>
            </button>

            <button
              onClick={handleReset}
              className="w-full py-2 px-3 rounded-xl border border-slate-200 text-slate-600 hover:bg-slate-50 font-medium text-xs transition-colors flex items-center justify-center gap-1.5"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Reiniciar Posición</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
