import React, { useState, useRef, useMemo } from 'react';
import { HousingRecord, HousingFeatureKey, SVMSolution, SVMHyperparameters } from '../types';
import { HOUSING_FEATURES } from '../data/housingData';
import { SVMSolver, generate2DMesh } from '../ml/svmEngine';
import { Home, Sparkles, AlertCircle, Info, Crosshair, ZoomIn, ZoomOut, RotateCcw } from 'lucide-react';

interface Svm2DViewProps {
  records: HousingRecord[];
  featureX: HousingFeatureKey;
  featureY: HousingFeatureKey;
  solver: SVMSolver;
  solution: SVMSolution;
  params: SVMHyperparameters;
  showHyperplane: boolean;
  showMargins: boolean;
  showSupportVectors: boolean;
  showSlackLines: boolean;
  showDecisionSurface: boolean;
  probePoint: { x: number; y: number } | null;
  onSetProbePoint: (point: { x: number; y: number } | null) => void;
  selectedHouseId: number | null;
  onSelectHouse: (record: HousingRecord | null) => void;
}

export const Svm2DView: React.FC<Svm2DViewProps> = ({
  records,
  featureX,
  featureY,
  solver,
  solution,
  params,
  showHyperplane,
  showMargins,
  showSupportVectors,
  showSlackLines,
  showDecisionSurface,
  probePoint,
  onSetProbePoint,
  selectedHouseId,
  onSelectHouse,
}) => {
  const svgRef = useRef<SVGSVGElement>(null);
  const [hoveredRecord, setHoveredRecord] = useState<HousingRecord | null>(null);
  const [hoverPos, setHoverPos] = useState<{ x: number; y: number } | null>(null);

  const metaX = HOUSING_FEATURES[featureX];
  const metaY = HOUSING_FEATURES[featureY];

  // Compute data ranges with padding
  const { xMin, xMax, yMin, yMax } = useMemo(() => {
    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
    for (const r of records) {
      const vx = r[featureX];
      const vy = r[featureY];
      if (vx < minX) minX = vx;
      if (vx > maxX) maxX = vx;
      if (vy < minY) minY = vy;
      if (vy > maxY) maxY = vy;
    }
    const padX = (maxX - minX) * 0.12 || 1;
    const padY = (maxY - minY) * 0.12 || 1;
    return {
      xMin: minX - padX,
      xMax: maxX + padX,
      yMin: minY - padY,
      yMax: maxY + padY,
    };
  }, [records, featureX, featureY]);

  // SVG dimensions
  const width = 760;
  const height = 520;
  const padding = { top: 40, right: 40, bottom: 65, left: 75 };
  const plotWidth = width - padding.left - padding.right;
  const plotHeight = height - padding.top - padding.bottom;

  // Coordinate scales
  const scaleX = (val: number) => padding.left + ((val - xMin) / (xMax - xMin)) * plotWidth;
  const scaleY = (val: number) => padding.top + plotHeight - ((val - yMin) / (yMax - yMin)) * plotHeight;
  const unscaleX = (px: number) => xMin + ((px - padding.left) / plotWidth) * (xMax - xMin);
  const unscaleY = (py: number) => yMin + ((padding.top + plotHeight - py) / plotHeight) * (yMax - yMin);

  // Set of support vector IDs for quick lookup
  const svMap = useMemo(() => {
    const map = new Map<number, (typeof solution.supportVectors)[0]>();
    for (const sv of solution.supportVectors) {
      map.set(sv.record.id, sv);
    }
    return map;
  }, [solution]);

  // Mesh grid calculation for decision boundary and heatmap
  const mesh = useMemo(() => {
    return generate2DMesh(solver, xMin, xMax, yMin, yMax, 42);
  }, [solver, xMin, xMax, yMin, yMax]);

  // Contour path generator using marching squares
  const getContourPath = (level: number): string => {
    const grid = mesh.grid;
    const N = mesh.xs.length;
    const segments: Array<[number, number, number, number]> = [];

    for (let i = 0; i < N - 1; i++) {
      for (let j = 0; j < N - 1; j++) {
        const v00 = grid[i][j] - level;
        const v10 = grid[i + 1][j] - level;
        const v11 = grid[i + 1][j + 1] - level;
        const v01 = grid[i][j + 1] - level;

        const x0 = scaleX(mesh.xs[i]);
        const x1 = scaleX(mesh.xs[i + 1]);
        const y0 = scaleY(mesh.ys[j]);
        const y1 = scaleY(mesh.ys[j + 1]);

        let cellType = 0;
        if (v00 > 0) cellType |= 1;
        if (v10 > 0) cellType |= 2;
        if (v11 > 0) cellType |= 4;
        if (v01 > 0) cellType |= 8;

        const interpolate = (pA: number, pB: number, vA: number, vB: number) => {
          if (Math.abs(vB - vA) < 1e-6) return (pA + pB) / 2;
          return pA + ((0 - vA) / (vB - vA)) * (pB - pA);
        };

        const bottom: [number, number] = [interpolate(x0, x1, v00, v10), y0];
        const right: [number, number] = [x1, interpolate(y0, y1, v10, v11)];
        const top: [number, number] = [interpolate(x0, x1, v01, v11), y1];
        const left: [number, number] = [x0, interpolate(y0, y1, v00, v01)];

        switch (cellType) {
          case 1:
          case 14:
            segments.push([left[0], left[1], bottom[0], bottom[1]]);
            break;
          case 2:
          case 13:
            segments.push([bottom[0], bottom[1], right[0], right[1]]);
            break;
          case 3:
          case 12:
            segments.push([left[0], left[1], right[0], right[1]]);
            break;
          case 4:
          case 11:
            segments.push([right[0], right[1], top[0], top[1]]);
            break;
          case 5:
            segments.push([left[0], left[1], top[0], top[1]]);
            segments.push([bottom[0], bottom[1], right[0], right[1]]);
            break;
          case 6:
          case 9:
            segments.push([bottom[0], bottom[1], top[0], top[1]]);
            break;
          case 7:
          case 8:
            segments.push([left[0], left[1], top[0], top[1]]);
            break;
          case 10:
            segments.push([left[0], left[1], bottom[0], bottom[1]]);
            segments.push([right[0], right[1], top[0], top[1]]);
            break;
        }
      }
    }

    if (segments.length === 0) return '';
    return segments.map(([x1, y1, x2, y2]) => `M ${x1.toFixed(1)} ${y1.toFixed(1)} L ${x2.toFixed(1)} ${y2.toFixed(1)}`).join(' ');
  };

  const hyperplanePath = useMemo(() => getContourPath(0), [mesh]);
  const marginPlusPath = useMemo(() => getContourPath(1), [mesh]);
  const marginMinusPath = useMemo(() => getContourPath(-1), [mesh]);

  // Handle click on canvas to place probe point
  const handleSvgClick = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!svgRef.current) return;
    const rect = svgRef.current.getBoundingClientRect();
    const px = ((e.clientX - rect.left) / rect.width) * width;
    const py = ((e.clientY - rect.top) / rect.height) * height;

    if (px >= padding.left && px <= width - padding.right && py >= padding.top && py <= height - padding.bottom) {
      const realX = unscaleX(px);
      const realY = unscaleY(py);
      onSetProbePoint({ x: realX, y: realY });
    }
  };

  // Prediction for probe point
  const probePrediction = useMemo(() => {
    if (!probePoint) return null;
    const val = solver.predictRaw([probePoint.x, probePoint.y]);
    return {
      fVal: val,
      isPremium: val >= 0,
      confidence: Math.min(100, Math.round(Math.abs(val) * 50)),
      inMargin: Math.abs(val) < 1,
    };
  }, [probePoint, solver]);

  return (
    <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs flex flex-col">
      {/* Metrics Banner */}
      <div className="bg-slate-50 border-b border-slate-200 px-4 py-3 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-4 text-xs">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span className="font-semibold text-slate-700">Precisión SVM:</span>
            <span className="font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
              {solution.accuracy.toFixed(1)}%
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="font-semibold text-slate-700">Ancho del Margen (2/||w||):</span>
            <span className="font-mono font-bold text-indigo-700 bg-indigo-50 px-2 py-0.5 rounded-md border border-indigo-200">
              {solution.marginWidth > 10 ? 'Margen Amplio' : solution.marginWidth.toFixed(2)}
            </span>
          </div>

          <div className="flex items-center gap-1.5">
            <span className="font-semibold text-slate-700">Vectores de Soporte:</span>
            <span className="font-bold text-amber-800 bg-amber-50 px-2 py-0.5 rounded-md border border-amber-200">
              {solution.supportVectors.length} de 30 ({Math.round((solution.supportVectors.length / 30) * 100)}%)
            </span>
          </div>

          {solution.numMarginViolations > 0 && (
            <div className="flex items-center gap-1 text-amber-700 font-medium">
              <AlertCircle className="w-3.5 h-3.5 text-amber-600" />
              <span>{solution.numMarginViolations} violaciones de margen</span>
            </div>
          )}
        </div>

        {/* Legend */}
        <div className="flex items-center gap-3 text-xs">
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-blue-600 border border-white shadow-xs"></span>
            <span className="text-slate-700 font-medium">Premium (+1)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full bg-amber-500 border border-white shadow-xs"></span>
            <span className="text-slate-700 font-medium">Estándar (-1)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-3 rounded-full border-2 border-amber-500 bg-amber-100"></span>
            <span className="text-amber-800 font-semibold">Vector Soporte</span>
          </div>
        </div>
      </div>

      {/* Main Interactive Canvas Area */}
      <div className="relative w-full aspect-[16/10] sm:aspect-[16/9] max-h-[560px] bg-white select-none">
        <svg
          ref={svgRef}
          viewBox={`0 0 ${width} ${height}`}
          onClick={handleSvgClick}
          className="w-full h-full cursor-crosshair"
        >
          <defs>
            {/* Soft grid pattern */}
            <pattern id="grid-pattern" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#f1f5f9" strokeWidth="1" />
            </pattern>

            {/* Gradient for decision regions */}
            <radialGradient id="support-glow" cx="50%" cy="50%" r="50%">
              <stop offset="0%" stopColor="#f59e0b" stopOpacity="0.4" />
              <stop offset="100%" stopColor="#f59e0b" stopOpacity="0" />
            </radialGradient>
          </defs>

          {/* Plot Background */}
          <rect
            x={padding.left}
            y={padding.top}
            width={plotWidth}
            height={plotHeight}
            fill="#fafbfc"
            stroke="#cbd5e1"
            strokeWidth="1.2"
          />

          {/* Background Grid */}
          <rect
            x={padding.left}
            y={padding.top}
            width={plotWidth}
            height={plotHeight}
            fill="url(#grid-pattern)"
          />

          {/* Decision Surface Heatmap (Soft color fields) */}
          {showDecisionSurface && (
            <g opacity="0.18">
              {mesh.xs.map((xVal, i) => {
                if (i >= mesh.xs.length - 1) return null;
                return mesh.ys.map((yVal, j) => {
                  if (j >= mesh.ys.length - 1) return null;
                  const fVal = mesh.grid[i][j];
                  const xPix = scaleX(xVal);
                  const yPix = scaleY(mesh.ys[j + 1]);
                  const cellW = scaleX(mesh.xs[i + 1]) - xPix;
                  const cellH = scaleY(yVal) - yPix;
                  const fill = fVal > 0 ? '#3b82f6' : '#f97316';
                  return (
                    <rect
                      key={`cell-${i}-${j}`}
                      x={xPix}
                      y={yPix}
                      width={Math.max(0, cellW)}
                      height={Math.max(0, cellH)}
                      fill={fill}
                    />
                  );
                });
              })}
            </g>
          )}

          {/* Margins: Positive and Negative Margin Lines */}
          {showMargins && (
            <g>
              {/* Positive Margin (+1) */}
              <path
                d={marginPlusPath}
                fill="none"
                stroke="#3b82f6"
                strokeWidth="2"
                strokeDasharray="6 4"
                opacity="0.85"
              />
              {/* Negative Margin (-1) */}
              <path
                d={marginMinusPath}
                fill="none"
                stroke="#f97316"
                strokeWidth="2"
                strokeDasharray="6 4"
                opacity="0.85"
              />
            </g>
          )}

          {/* Optimal Hyperplane Decision Boundary (f(x) = 0) */}
          {showHyperplane && (
            <path
              d={hyperplanePath}
              fill="none"
              stroke="#4338ca"
              strokeWidth="3.5"
              strokeLinecap="round"
              className="drop-shadow-xs"
            />
          )}

          {/* Slack Lines (xi_i for points violating the margin) */}
          {showSlackLines &&
            records.map((rec) => {
              const sv = svMap.get(rec.id);
              if (!sv || sv.slack <= 0.05) return null;
              const px = scaleX(rec[featureX]);
              const py = scaleY(rec[featureY]);
              return (
                <g key={`slack-${rec.id}`}>
                  <circle cx={px} cy={py} r="16" fill="none" stroke="#ef4444" strokeWidth="1.5" strokeDasharray="3 3" />
                  <text x={px + 10} y={py - 10} fill="#dc2626" fontSize="10" fontWeight="bold">
                    ξ={sv.slack.toFixed(2)}
                  </text>
                </g>
              );
            })}

          {/* 30 Housing Points */}
          {records.map((rec) => {
            const px = scaleX(rec[featureX]);
            const py = scaleY(rec[featureY]);
            const isSV = svMap.has(rec.id);
            const svInfo = svMap.get(rec.id);
            const isSelected = selectedHouseId === rec.id;
            const isHovered = hoveredRecord?.id === rec.id;
            const isPremium = rec.label === 1;

            return (
              <g
                key={`house-dot-${rec.id}`}
                className="cursor-pointer transition-transform duration-150"
                onClick={(e) => {
                  e.stopPropagation();
                  onSelectHouse(isSelected ? null : rec);
                }}
                onMouseEnter={(e) => {
                  setHoveredRecord(rec);
                  setHoverPos({ x: px, y: py });
                }}
                onMouseLeave={() => {
                  setHoveredRecord(null);
                  setHoverPos(null);
                }}
              >
                {/* Golden halo for Support Vectors */}
                {isSV && showSupportVectors && (
                  <g>
                    <circle cx={px} cy={py} r="18" fill="url(#support-glow)" />
                    <circle
                      cx={px}
                      cy={py}
                      r="12"
                      fill="none"
                      stroke="#d97706"
                      strokeWidth="2.5"
                      strokeDasharray={svInfo?.isMarginBound ? 'none' : '4 2'}
                      className="animate-pulse"
                    />
                  </g>
                )}

                {/* Selected Ring */}
                {isSelected && (
                  <circle cx={px} cy={py} r="15" fill="none" stroke="#6366f1" strokeWidth="2.5" />
                )}

                {/* Main House Dot */}
                <circle
                  cx={px}
                  cy={py}
                  r={isHovered || isSelected ? 8.5 : isSV ? 7 : 5.5}
                  fill={isPremium ? '#2563eb' : '#ea580c'}
                  stroke="#ffffff"
                  strokeWidth="2"
                  className="shadow-md"
                />

                {/* Small SV Badge */}
                {isSV && showSupportVectors && (
                  <circle cx={px} cy={py} r="2.5" fill="#fef08a" />
                )}
              </g>
            );
          })}

          {/* Probe Target Point (Interactive Click Tester) */}
          {probePoint && (
            <g className="transition-all duration-200">
              <circle
                cx={scaleX(probePoint.x)}
                cy={scaleY(probePoint.y)}
                r="18"
                fill="#10b981"
                fillOpacity="0.2"
                className="animate-ping"
              />
              <circle
                cx={scaleX(probePoint.x)}
                cy={scaleY(probePoint.y)}
                r="7"
                fill="#059669"
                stroke="#ffffff"
                strokeWidth="2.5"
              />
              <line
                x1={scaleX(probePoint.x) - 12}
                y1={scaleY(probePoint.y)}
                x2={scaleX(probePoint.x) + 12}
                y2={scaleY(probePoint.y)}
                stroke="#047857"
                strokeWidth="1.5"
              />
              <line
                x1={scaleX(probePoint.x)}
                y1={scaleY(probePoint.y) - 12}
                x2={scaleX(probePoint.x)}
                y2={scaleY(probePoint.y) + 12}
                stroke="#047857"
                strokeWidth="1.5"
              />
            </g>
          )}

          {/* Axes & Ticks */}
          {/* Axis X */}
          <line
            x1={padding.left}
            y1={padding.top + plotHeight}
            x2={width - padding.right}
            y2={padding.top + plotHeight}
            stroke="#64748b"
            strokeWidth="1.5"
          />
          {/* Axis Y */}
          <line
            x1={padding.left}
            y1={padding.top}
            x2={padding.left}
            y2={padding.top + plotHeight}
            stroke="#64748b"
            strokeWidth="1.5"
          />

          {/* X Ticks (5 ticks) */}
          {[0, 0.25, 0.5, 0.75, 1].map((ratio) => {
            const val = xMin + ratio * (xMax - xMin);
            const px = scaleX(val);
            return (
              <g key={`xtick-${ratio}`}>
                <line x1={px} y1={padding.top + plotHeight} x2={px} y2={padding.top + plotHeight + 5} stroke="#64748b" />
                <text
                  x={px}
                  y={padding.top + plotHeight + 18}
                  textAnchor="middle"
                  fontSize="11"
                  fill="#64748b"
                  fontFamily="monospace"
                >
                  {Math.round(val).toLocaleString()}
                </text>
              </g>
            );
          })}

          {/* Y Ticks (5 ticks) */}
          {[0, 0.25, 0.5, 0.75, 1].map((ratio) => {
            const val = yMin + ratio * (yMax - yMin);
            const py = scaleY(val);
            return (
              <g key={`ytick-${ratio}`}>
                <line x1={padding.left - 5} y1={py} x2={padding.left} y2={py} stroke="#64748b" />
                <text
                  x={padding.left - 8}
                  y={py + 4}
                  textAnchor="end"
                  fontSize="11"
                  fill="#64748b"
                  fontFamily="monospace"
                >
                  {Math.round(val).toLocaleString()}
                </text>
              </g>
            );
          })}

          {/* Axis Labels */}
          <text
            x={padding.left + plotWidth / 2}
            y={height - 18}
            textAnchor="middle"
            fontSize="12"
            fontWeight="bold"
            fill="#334155"
          >
            {metaX.name} ({metaX.unit}) →
          </text>
          <text
            x={22}
            y={padding.top + plotHeight / 2}
            textAnchor="middle"
            fontSize="12"
            fontWeight="bold"
            fill="#334155"
            transform={`rotate(-90, 22, ${padding.top + plotHeight / 2})`}
          >
            {metaY.name} ({metaY.unit}) →
          </text>
        </svg>

        {/* Floating Instruction / Probe Helper */}
        <div className="absolute top-2 left-20 bg-white/90 backdrop-blur-xs px-2.5 py-1 rounded-md text-[11px] text-slate-600 border border-slate-200 shadow-xs pointer-events-none flex items-center gap-1.5">
          <Crosshair className="w-3.5 h-3.5 text-emerald-600" />
          <span>Haz clic en el plano para probar la clasificación de una vivienda nueva</span>
        </div>

        {/* Hover House Tooltip */}
        {hoveredRecord && hoverPos && (
          <div
            className="absolute z-30 pointer-events-none bg-slate-900/95 backdrop-blur-md text-white rounded-lg p-3 shadow-xl border border-slate-700 text-xs w-64"
            style={{
              left: Math.min(width - 270, Math.max(10, hoverPos.x + 12)),
              top: Math.min(height - 140, Math.max(10, hoverPos.y - 60)),
            }}
          >
            <div className="flex items-center justify-between font-bold border-b border-slate-700 pb-1.5 mb-1.5">
              <span className="flex items-center gap-1">
                <Home className="w-3.5 h-3.5 text-indigo-400" />
                {hoveredRecord.city}, {hoveredRecord.state}
              </span>
              <span
                className={`px-1.5 py-0.2 rounded text-[10px] ${
                  hoveredRecord.label === 1
                    ? 'bg-blue-500/30 text-blue-300 border border-blue-400/40'
                    : 'bg-amber-500/30 text-amber-300 border border-amber-400/40'
                }`}
              >
                {hoveredRecord.labelName}
              </span>
            </div>
            <div className="space-y-1 text-slate-300 text-[11px]">
              <div className="flex justify-between">
                <span>{metaX.shortLabel}:</span>
                <span className="font-semibold text-white">{metaX.format(hoveredRecord[featureX])}</span>
              </div>
              <div className="flex justify-between">
                <span>{metaY.shortLabel}:</span>
                <span className="font-semibold text-white">{metaY.format(hoveredRecord[featureY])}</span>
              </div>
              <div className="flex justify-between">
                <span>Precio Real:</span>
                <span className="font-semibold text-emerald-300">${hoveredRecord.price_k}k USD</span>
              </div>
              <div className="border-t border-slate-700 pt-1 mt-1 flex justify-between items-center">
                <span>¿Vector de Soporte?</span>
                {svMap.has(hoveredRecord.id) ? (
                  <span className="text-amber-400 font-bold flex items-center gap-1">
                    <Sparkles className="w-3 h-3" /> ¡SÍ! (α={svMap.get(hoveredRecord.id)?.alpha.toFixed(2)})
                  </span>
                ) : (
                  <span className="text-slate-400 font-normal">No (α = 0)</span>
                )}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Live Probe Result Card */}
      {probePrediction && probePoint && (
        <div className="bg-emerald-50/70 border-t border-emerald-200 px-4 py-3 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold text-sm shadow-xs">
              <Crosshair className="w-4 h-4" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-bold text-emerald-950">Vivienda Simulada:</span>
                <span className="text-xs text-slate-700 font-medium">
                  {metaX.shortLabel}: <strong>{metaX.format(probePoint.x)}</strong> | {metaY.shortLabel}: <strong>{metaY.format(probePoint.y)}</strong>
                </span>
              </div>
              <p className="text-[11px] text-emerald-800">
                Resultado SVM: f(x) = <code className="font-bold">{probePrediction.fVal.toFixed(3)}</code> →{' '}
                {probePrediction.isPremium ? (
                  <span className="font-extrabold text-blue-700">Clasificada como Vivienda Premium (+1)</span>
                ) : (
                  <span className="font-extrabold text-amber-700">Clasificada como Vivienda Estándar (-1)</span>
                )}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <span
              className={`text-xs font-semibold px-2.5 py-1 rounded-full border ${
                probePrediction.inMargin
                  ? 'bg-amber-100 text-amber-900 border-amber-300'
                  : 'bg-emerald-100 text-emerald-900 border-emerald-300'
              }`}
            >
              {probePrediction.inMargin ? '⚠️ En Franja de Margen (|f(x)| < 1)' : '✅ Fuera de la Franja (|f(x)| ≥ 1)'}
            </span>
            <button
              onClick={() => onSetProbePoint(null)}
              className="text-xs text-slate-500 hover:text-slate-800 underline"
            >
              Limpiar punto
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
