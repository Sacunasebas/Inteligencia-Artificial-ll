import React, { useState, useMemo } from 'react';
import { SVMSolver } from '../ml/svmEngine';
import { HousingFeatureKey, SVMSolution } from '../types';
import { HOUSING_FEATURES } from '../data/housingData';
import { X, Sparkles, Home, CheckCircle2, AlertCircle, Compass, Calculator } from 'lucide-react';

interface PredictorDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  solver: SVMSolver;
  solution: SVMSolution;
  featureX: HousingFeatureKey;
  featureY: HousingFeatureKey;
  onSetProbePoint: (point: { x: number; y: number }) => void;
}

export const PredictorDrawer: React.FC<PredictorDrawerProps> = ({
  isOpen,
  onClose,
  solver,
  solution,
  featureX,
  featureY,
  onSetProbePoint,
}) => {
  if (!isOpen) return null;

  const [sqft, setSqft] = useState<number>(2300);
  const [medianIncome, setMedianIncome] = useState<number>(75);
  const [bedrooms, setBedrooms] = useState<number>(3);
  const [houseAge, setHouseAge] = useState<number>(15);
  const [priceK, setPriceK] = useState<number>(550);

  // Build feature array corresponding to current X and Y or all features
  const featureValues: Record<HousingFeatureKey, number> = {
    sqft,
    median_income_k: medianIncome,
    bedrooms,
    house_age: houseAge,
    price_k: priceK,
  };

  // Predict
  const prediction = useMemo(() => {
    const rawF = solver.predictRaw([featureValues[featureX], featureValues[featureY]]);
    const isPremium = rawF >= 0;
    const confidence = Math.min(99.9, Math.round((Math.abs(rawF) / (Math.abs(rawF) + 1)) * 100));
    const inMargin = Math.abs(rawF) < 1.0;

    return {
      rawF,
      isPremium,
      confidence,
      inMargin,
    };
  }, [solver, featureValues, featureX, featureY]);

  const handleApplyToCanvas = () => {
    onSetProbePoint({
      x: featureValues[featureX],
      y: featureValues[featureY],
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-lg w-full overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center">
              <Calculator className="w-4 h-4 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-sm">Simulador de Tasación con SVM</h3>
              <p className="text-[11px] text-slate-400">Evalúa una vivienda nueva en el mercado estadounidense</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 overflow-y-auto space-y-4">
          {/* Prediction Card */}
          <div
            className={`p-4 rounded-xl border text-center ${
              prediction.isPremium
                ? 'bg-blue-50 border-blue-200 text-blue-950'
                : 'bg-amber-50 border-amber-200 text-amber-950'
            }`}
          >
            <span className="text-[10px] font-bold uppercase tracking-wider block opacity-75">
              Predicción de la Máquina de Soporte Vectorial
            </span>
            <div className="text-xl font-extrabold my-1">
              {prediction.isPremium ? 'Vivienda Premium / Alto Valor (+1)' : 'Vivienda Estándar / Accesible (-1)'}
            </div>
            <div className="text-xs font-mono font-semibold">
              f(x) = {prediction.rawF.toFixed(3)} • Confianza: {prediction.confidence}%
            </div>
            <div className="mt-2 text-[11px]">
              {prediction.inMargin ? (
                <span className="inline-flex items-center gap-1 text-amber-800 bg-amber-100/70 px-2.5 py-0.5 rounded-full font-medium">
                  <AlertCircle className="w-3.5 h-3.5" /> Se encuentra dentro de la franja de duda (|f(x)| &lt; 1)
                </span>
              ) : (
                <span className="inline-flex items-center gap-1 text-emerald-800 bg-emerald-100/70 px-2.5 py-0.5 rounded-full font-medium">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Clara separación más allá del margen de seguridad
                </span>
              )}
            </div>
          </div>

          {/* Interactive Feature Sliders */}
          <div className="space-y-3">
            {/* Sqft */}
            <div>
              <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
                <span>Superficie de la Vivienda:</span>
                <span className="font-mono text-indigo-600">{sqft.toLocaleString()} sq ft</span>
              </div>
              <input
                type="range"
                min="900"
                max="4000"
                step="50"
                value={sqft}
                onChange={(e) => setSqft(parseInt(e.target.value))}
                className="w-full accent-indigo-600 h-1.5 bg-slate-200 rounded"
              />
            </div>

            {/* Income */}
            <div>
              <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
                <span>Ingreso Medio del Vecindario:</span>
                <span className="font-mono text-indigo-600">${medianIncome}k/año</span>
              </div>
              <input
                type="range"
                min="25"
                max="140"
                step="2"
                value={medianIncome}
                onChange={(e) => setMedianIncome(parseInt(e.target.value))}
                className="w-full accent-indigo-600 h-1.5 bg-slate-200 rounded"
              />
            </div>

            {/* Bedrooms */}
            <div>
              <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
                <span>Habitaciones:</span>
                <span className="font-mono text-indigo-600">{bedrooms} hab</span>
              </div>
              <input
                type="range"
                min="1"
                max="6"
                value={bedrooms}
                onChange={(e) => setBedrooms(parseInt(e.target.value))}
                className="w-full accent-indigo-600 h-1.5 bg-slate-200 rounded"
              />
            </div>

            {/* House Age */}
            <div>
              <div className="flex justify-between text-xs font-semibold text-slate-700 mb-1">
                <span>Antigüedad de la Construcción:</span>
                <span className="font-mono text-indigo-600">{houseAge} años</span>
              </div>
              <input
                type="range"
                min="1"
                max="65"
                value={houseAge}
                onChange={(e) => setHouseAge(parseInt(e.target.value))}
                className="w-full accent-indigo-600 h-1.5 bg-slate-200 rounded"
              />
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-medium text-slate-600 hover:text-slate-900"
          >
            Cerrar
          </button>
          <button
            type="button"
            onClick={handleApplyToCanvas}
            className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs shadow-xs transition-colors flex items-center gap-1.5"
          >
            <Compass className="w-3.5 h-3.5" />
            <span>Colocar en el Simulador 2D</span>
          </button>
        </div>
      </div>
    </div>
  );
};
