import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { HousingRecord, HousingFeatureKey, SVMHyperparameters, SVMSolution } from '../types';
import { HOUSING_FEATURES } from '../data/housingData';
import { SVMSolver } from '../ml/svmEngine';
import { Box, RotateCcw, Play, Pause, Eye, Compass, Info, Sparkles } from 'lucide-react';

interface Svm3DViewProps {
  records: HousingRecord[];
  featureX: HousingFeatureKey;
  featureY: HousingFeatureKey;
  featureZ: HousingFeatureKey;
  params: SVMHyperparameters;
  showHyperplane: boolean;
  showMargins: boolean;
  showSupportVectors: boolean;
  selectedHouseId: number | null;
  onSelectHouse: (record: HousingRecord | null) => void;
}

export const Svm3DView: React.FC<Svm3DViewProps> = ({
  records,
  featureX,
  featureY,
  featureZ,
  params,
  showHyperplane,
  showMargins,
  showSupportVectors,
  selectedHouseId,
  onSelectHouse,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [hoveredHouse, setHoveredHouse] = useState<HousingRecord | null>(null);
  const [isAutoRotating, setIsAutoRotating] = useState(false);
  const [cameraView, setCameraView] = useState<'iso' | 'top' | 'side'>('iso');

  const metaX = HOUSING_FEATURES[featureX];
  const metaY = HOUSING_FEATURES[featureY];
  const metaZ = HOUSING_FEATURES[featureZ];

  // Train 3D SVM
  const solver3D = useRef<SVMSolver | null>(null);
  const solution3D = useRef<SVMSolution | null>(null);

  // References for Three.js objects
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const houseMeshesRef = useRef<{ mesh: THREE.Mesh; record: HousingRecord }[]>([]);
  const planeMeshRef = useRef<THREE.Mesh | null>(null);
  const marginPlusMeshRef = useRef<THREE.Mesh | null>(null);
  const marginMinusMeshRef = useRef<THREE.Mesh | null>(null);
  const normalArrowRef = useRef<THREE.ArrowHelper | null>(null);
  const group3DRef = useRef<THREE.Group | null>(null);
  const animFrameId = useRef<number | null>(null);

  // Camera interaction state
  const isDragging = useRef(false);
  const previousMousePosition = useRef({ x: 0, y: 0 });
  const rotation = useRef({ x: 0.4, y: -0.6 });
  const zoom = useRef(16);

  // Train 3D SVM whenever features or params change
  useEffect(() => {
    const s = new SVMSolver(records, [featureX, featureY, featureZ], params);
    solver3D.current = s;
    solution3D.current = s.train(50);
  }, [records, featureX, featureY, featureZ, params]);

  // Set up Three.js Scene
  useEffect(() => {
    if (!mountRef.current) return;
    const container = mountRef.current;
    const width = container.clientWidth;
    const height = container.clientHeight || 500;

    // Scene
    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0xf8fafc);
    sceneRef.current = scene;

    // Camera
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.set(14, 12, 16);
    camera.lookAt(0, 0, 0);
    cameraRef.current = camera;

    // Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);
    rendererRef.current = renderer;

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.85);
    scene.add(ambientLight);

    const dirLight1 = new THREE.DirectionalLight(0xffffff, 0.9);
    dirLight1.position.set(20, 30, 20);
    scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0x93c5fd, 0.4);
    dirLight2.position.set(-20, -10, -20);
    scene.add(dirLight2);

    // Main 3D Model Group (to rotate around origin)
    const mainGroup = new THREE.Group();
    scene.add(mainGroup);
    group3DRef.current = mainGroup;

    // 3D Coordinate Grid / Bounding Box
    const boxSize = 10;
    const gridHelper = new THREE.GridHelper(boxSize, 10, 0x94a3b8, 0xe2e8f0);
    gridHelper.position.y = -boxSize / 2;
    mainGroup.add(gridHelper);

    // Axes Lines: Red (X), Green (Y), Blue (Z)
    const axesHelper = new THREE.AxesHelper(boxSize * 0.65);
    axesHelper.position.set(-boxSize / 2, -boxSize / 2, -boxSize / 2);
    mainGroup.add(axesHelper);

    // Compute min/max for normalization to [-4, 4] cube
    const getStats = (key: HousingFeatureKey) => {
      let min = Infinity, max = -Infinity;
      for (const r of records) {
        if (r[key] < min) min = r[key];
        if (r[key] > max) max = r[key];
      }
      return { min, max };
    };

    const statsX = getStats(featureX);
    const statsY = getStats(featureY);
    const statsZ = getStats(featureZ);

    const normCoord = (val: number, stats: { min: number; max: number }) => {
      return ((val - stats.min) / (stats.max - stats.min || 1) - 0.5) * 8;
    };

    // Support Vectors map
    const sol = solution3D.current;
    const svSet = new Set(sol?.supportVectors.map((sv) => sv.record.id) || []);

    // Create 30 Housing Spheres
    houseMeshesRef.current = [];
    records.forEach((record) => {
      const px = normCoord(record[featureX], statsX);
      const py = normCoord(record[featureY], statsY);
      const pz = normCoord(record[featureZ], statsZ);

      const isSV = svSet.has(record.id);
      const isPremium = record.label === 1;

      // Sphere geometry
      const radius = isSV ? 0.42 : 0.32;
      const sphereGeo = new THREE.SphereGeometry(radius, 24, 24);
      const sphereMat = new THREE.MeshStandardMaterial({
        color: isPremium ? 0x2563eb : 0xea580c,
        roughness: 0.25,
        metalness: 0.1,
      });

      const sphereMesh = new THREE.Mesh(sphereGeo, sphereMat);
      sphereMesh.position.set(px, py, pz);
      sphereMesh.castShadow = true;
      mainGroup.add(sphereMesh);

      // Support Vector glowing wireframe halo
      if (isSV) {
        const haloGeo = new THREE.RingGeometry(0.55, 0.7, 32);
        const haloMat = new THREE.MeshBasicMaterial({
          color: 0xf59e0b,
          side: THREE.DoubleSide,
          transparent: true,
          opacity: 0.8,
        });
        const haloMesh = new THREE.Mesh(haloGeo, haloMat);
        haloMesh.position.set(px, py, pz);
        haloMesh.rotation.x = Math.PI / 2;
        mainGroup.add(haloMesh);
      }

      // Stem line dropping down to base
      const lineGeo = new THREE.BufferGeometry().setFromPoints([
        new THREE.Vector3(px, py, pz),
        new THREE.Vector3(px, -boxSize / 2, pz),
      ]);
      const lineMat = new THREE.LineDashedMaterial({
        color: 0xcbd5e1,
        dashSize: 0.2,
        gapSize: 0.1,
      });
      const stem = new THREE.Line(lineGeo, lineMat);
      stem.computeLineDistances();
      mainGroup.add(stem);

      houseMeshesRef.current.push({ mesh: sphereMesh, record });
    });

    // Separating 3D Hyperplane Plane Mesh
    // Equation in normalized space: w1 * x + w2 * y + w3 * z + b = 0
    if (sol && sol.w && sol.w.length === 3) {
      const w1 = sol.w[0];
      const w2 = sol.w[1];
      const w3 = sol.w[2];
      const b = sol.b;
      const normal = new THREE.Vector3(w1, w2, w3).normalize();

      // Hyperplane mesh
      const planeGeo = new THREE.PlaneGeometry(12, 12, 16, 16);
      const planeMat = new THREE.MeshStandardMaterial({
        color: 0x4f46e5,
        transparent: true,
        opacity: 0.38,
        side: THREE.DoubleSide,
        roughness: 0.2,
        metalness: 0.1,
      });
      const planeMesh = new THREE.Mesh(planeGeo, planeMat);

      // Orient plane along normal vector
      const defaultNormal = new THREE.Vector3(0, 0, 1);
      const quaternion = new THREE.Quaternion().setFromUnitVectors(defaultNormal, normal);
      planeMesh.quaternion.copy(quaternion);

      // Distance from origin to plane along normal: d = -b / ||w||
      const wNorm = Math.sqrt(w1 * w1 + w2 * w2 + w3 * w3) || 1;
      const distFromOrigin = (-b / wNorm) * 2; // scaled
      planeMesh.position.copy(normal.clone().multiplyScalar(distFromOrigin));

      mainGroup.add(planeMesh);
      planeMeshRef.current = planeMesh;

      // Normal Vector Arrow (w)
      const arrow = new THREE.ArrowHelper(
        normal,
        planeMesh.position,
        3.5,
        0x4338ca,
        0.8,
        0.5
      );
      mainGroup.add(arrow);
      normalArrowRef.current = arrow;

      // Margin +1 plane
      const mPlusGeo = new THREE.PlaneGeometry(11, 11);
      const mPlusMat = new THREE.MeshBasicMaterial({
        color: 0x3b82f6,
        transparent: true,
        opacity: 0.18,
        side: THREE.DoubleSide,
        wireframe: true,
      });
      const mPlusMesh = new THREE.Mesh(mPlusGeo, mPlusMat);
      mPlusMesh.quaternion.copy(quaternion);
      mPlusMesh.position.copy(normal.clone().multiplyScalar(distFromOrigin + (1 / wNorm) * 2));
      mainGroup.add(mPlusMesh);
      marginPlusMeshRef.current = mPlusMesh;

      // Margin -1 plane
      const mMinusGeo = new THREE.PlaneGeometry(11, 11);
      const mMinusMat = new THREE.MeshBasicMaterial({
        color: 0xf97316,
        transparent: true,
        opacity: 0.18,
        side: THREE.DoubleSide,
        wireframe: true,
      });
      const mMinusMesh = new THREE.Mesh(mMinusGeo, mMinusMat);
      mMinusMesh.quaternion.copy(quaternion);
      mMinusMesh.position.copy(normal.clone().multiplyScalar(distFromOrigin - (1 / wNorm) * 2));
      mainGroup.add(mMinusMesh);
      marginMinusMeshRef.current = mMinusMesh;
    }

    // Mouse Interaction Handlers
    const onMouseDown = (e: MouseEvent) => {
      isDragging.current = true;
      previousMousePosition.current = { x: e.clientX, y: e.clientY };
    };

    const onMouseMove = (e: MouseEvent) => {
      if (!isDragging.current) {
        // Raycasting for hover tooltip
        const rect = container.getBoundingClientRect();
        const mouse = new THREE.Vector2(
          ((e.clientX - rect.left) / rect.width) * 2 - 1,
          -((e.clientY - rect.top) / rect.height) * 2 + 1
        );
        const raycaster = new THREE.Raycaster();
        raycaster.setFromCamera(mouse, camera);
        const intersects = raycaster.intersectObjects(
          houseMeshesRef.current.map((h) => h.mesh)
        );

        if (intersects.length > 0) {
          const hit = houseMeshesRef.current.find((h) => h.mesh === intersects[0].object);
          if (hit) setHoveredHouse(hit.record);
        } else {
          setHoveredHouse(null);
        }
        return;
      }

      const deltaX = e.clientX - previousMousePosition.current.x;
      const deltaY = e.clientY - previousMousePosition.current.y;

      rotation.current.y += deltaX * 0.008;
      rotation.current.x += deltaY * 0.008;
      // Clamp vertical rotation
      rotation.current.x = Math.max(-Math.PI / 2.2, Math.min(Math.PI / 2.2, rotation.current.x));

      previousMousePosition.current = { x: e.clientX, y: e.clientY };
    };

    const onMouseUp = () => {
      isDragging.current = false;
    };

    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      zoom.current += e.deltaY * 0.015;
      zoom.current = Math.max(7, Math.min(32, zoom.current));
    };

    container.addEventListener('mousedown', onMouseDown);
    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
    container.addEventListener('wheel', onWheel, { passive: false });

    // Touch Support for mobile / iframe
    const onTouchStart = (e: TouchEvent) => {
      if (e.touches.length === 1) {
        isDragging.current = true;
        previousMousePosition.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
      }
    };
    const onTouchMove = (e: TouchEvent) => {
      if (isDragging.current && e.touches.length === 1) {
        const deltaX = e.touches[0].clientX - previousMousePosition.current.x;
        const deltaY = e.touches[0].clientY - previousMousePosition.current.y;
        rotation.current.y += deltaX * 0.01;
        rotation.current.x += deltaY * 0.01;
        previousMousePosition.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
      }
    };
    const onTouchEnd = () => {
      isDragging.current = false;
    };

    container.addEventListener('touchstart', onTouchStart, { passive: true });
    container.addEventListener('touchmove', onTouchMove, { passive: true });
    container.addEventListener('touchend', onTouchEnd);

    // Animation Loop
    const animate = () => {
      animFrameId.current = requestAnimationFrame(animate);

      if (isAutoRotating) {
        rotation.current.y += 0.005;
      }

      // Update camera position based on spherical coordinates
      const r = zoom.current;
      camera.position.x = r * Math.sin(rotation.current.y) * Math.cos(rotation.current.x);
      camera.position.y = r * Math.sin(rotation.current.x);
      camera.position.z = r * Math.cos(rotation.current.y) * Math.cos(rotation.current.x);
      camera.lookAt(0, 0, 0);

      // Visibility toggles
      if (planeMeshRef.current) planeMeshRef.current.visible = showHyperplane;
      if (normalArrowRef.current) normalArrowRef.current.visible = showHyperplane;
      if (marginPlusMeshRef.current) marginPlusMeshRef.current.visible = showMargins;
      if (marginMinusMeshRef.current) marginMinusMeshRef.current.visible = showMargins;

      renderer.render(scene, camera);
    };

    animate();

    // Resize Handler
    const handleResize = () => {
      if (!container) return;
      const newWidth = container.clientWidth;
      const newHeight = container.clientHeight || 500;
      camera.aspect = newWidth / newHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(newWidth, newHeight);
    };

    window.addEventListener('resize', handleResize);

    // Cleanup
    return () => {
      if (animFrameId.current) cancelAnimationFrame(animFrameId.current);
      window.removeEventListener('resize', handleResize);
      container.removeEventListener('mousedown', onMouseDown);
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      container.removeEventListener('wheel', onWheel);
      container.removeEventListener('touchstart', onTouchStart);
      container.removeEventListener('touchmove', onTouchMove);
      container.removeEventListener('touchend', onTouchEnd);
      renderer.dispose();
    };
  }, [featureX, featureY, featureZ, records, params, showHyperplane, showMargins, showSupportVectors, isAutoRotating]);

  // Camera presets
  const applyView = (view: 'iso' | 'top' | 'side') => {
    setCameraView(view);
    if (view === 'iso') {
      rotation.current = { x: 0.45, y: -0.65 };
      zoom.current = 16;
    } else if (view === 'top') {
      rotation.current = { x: Math.PI / 2.1, y: 0 };
      zoom.current = 18;
    } else if (view === 'side') {
      rotation.current = { x: 0.05, y: -Math.PI / 2 };
      zoom.current = 16;
    }
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs flex flex-col relative">
      {/* 3D View Toolbar */}
      <div className="bg-slate-50 border-b border-slate-200 px-4 py-2.5 flex flex-wrap items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-md bg-indigo-600 text-white flex items-center justify-center font-bold">
            <Box className="w-3.5 h-3.5" />
          </div>
          <span className="font-bold text-slate-800">Espacio Vectorial Tridimensional (3D)</span>
          <span className="text-slate-400 hidden sm:inline">|</span>
          <span className="text-slate-500 hidden sm:inline">
            Arrastra para rotar en 360° • Rueda para zoom
          </span>
        </div>

        {/* View Angle and Rotation Controls */}
        <div className="flex items-center gap-2">
          <div className="inline-flex rounded-lg border border-slate-200 bg-white p-0.5 shadow-2xs">
            <button
              onClick={() => applyView('iso')}
              className={`px-2 py-1 rounded text-[11px] font-medium ${
                cameraView === 'iso' ? 'bg-indigo-600 text-white' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Isométrica
            </button>
            <button
              onClick={() => applyView('top')}
              className={`px-2 py-1 rounded text-[11px] font-medium ${
                cameraView === 'top' ? 'bg-indigo-600 text-white' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Vista Superior
            </button>
            <button
              onClick={() => applyView('side')}
              className={`px-2 py-1 rounded text-[11px] font-medium ${
                cameraView === 'side' ? 'bg-indigo-600 text-white' : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Lateral
            </button>
          </div>

          <button
            onClick={() => setIsAutoRotating(!isAutoRotating)}
            className={`flex items-center gap-1 px-2.5 py-1 rounded-lg border text-[11px] font-semibold transition-colors ${
              isAutoRotating
                ? 'bg-indigo-50 border-indigo-200 text-indigo-700'
                : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            {isAutoRotating ? <Pause className="w-3 h-3" /> : <Play className="w-3 h-3" />}
            <span>{isAutoRotating ? 'Pausar Giro' : 'Auto-Girar'}</span>
          </button>
        </div>
      </div>

      {/* Three.js Container */}
      <div
        ref={mountRef}
        className="w-full h-[520px] relative bg-gradient-to-b from-slate-50 to-slate-100 cursor-grab active:cursor-grabbing"
      />

      {/* 3D Coordinate Axis Key (Bottom Left) */}
      <div className="absolute bottom-4 left-4 bg-white/90 backdrop-blur-md rounded-lg p-2.5 border border-slate-200 shadow-sm text-xs space-y-1 pointer-events-none">
        <div className="font-bold text-slate-800 text-[11px] mb-1">Ejes del Hiperplano 3D:</div>
        <div className="flex items-center gap-2 text-red-600 font-semibold">
          <span className="w-2.5 h-2.5 rounded-full bg-red-500"></span>
          <span>Eje X: {metaX.name}</span>
        </div>
        <div className="flex items-center gap-2 text-emerald-600 font-semibold">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span>
          <span>Eje Y: {metaY.name}</span>
        </div>
        <div className="flex items-center gap-2 text-blue-600 font-semibold">
          <span className="w-2.5 h-2.5 rounded-full bg-blue-500"></span>
          <span>Eje Z: {metaZ.name}</span>
        </div>
      </div>

      {/* Hover Info Card */}
      {hoveredHouse && (
        <div className="absolute top-14 right-4 bg-slate-900/90 backdrop-blur-md text-white rounded-lg p-3 shadow-xl border border-slate-700 text-xs w-60 pointer-events-none z-30">
          <div className="font-bold text-sm border-b border-slate-700 pb-1 mb-1.5 flex justify-between items-center">
            <span>{hoveredHouse.city}, {hoveredHouse.state}</span>
            <span
              className={`text-[10px] px-1.5 py-0.5 rounded ${
                hoveredHouse.label === 1 ? 'bg-blue-500/40 text-blue-200' : 'bg-amber-500/40 text-amber-200'
              }`}
            >
              {hoveredHouse.labelName}
            </span>
          </div>
          <div className="space-y-1 text-slate-300 text-[11px]">
            <div>X ({metaX.shortLabel}): <strong className="text-white">{metaX.format(hoveredHouse[featureX])}</strong></div>
            <div>Y ({metaY.shortLabel}): <strong className="text-white">{metaY.format(hoveredHouse[featureY])}</strong></div>
            <div>Z ({metaZ.shortLabel}): <strong className="text-white">{metaZ.format(hoveredHouse[featureZ])}</strong></div>
            <div className="text-emerald-300 font-semibold">Precio: ${hoveredHouse.price_k}k USD</div>
          </div>
        </div>
      )}
    </div>
  );
};
