import React from 'react';
import { SVMHyperparameters, KernelType } from '../types';
import { Cpu, Eye, HelpCircle } from 'lucide-react';

interface SvmControlsProps {
  params: SVMHyperparameters;
  onChangeParams: (newParams: SVMHyperparameters) => void;
  showHyperplane: boolean;
  onToggleHyperplane: () => void;
  showMargins: boolean;
  onToggleMargins: () => void;
  showSupportVectors: boolean;
  onToggleSupportVectors: () => void;
  showSlackLines: boolean;
  onToggleSlackLines: () => void;
  showDecisionSurface: boolean;
  onToggleDecisionSurface: () => void;
  is3D: boolean;
}

export const SvmControls: React.FC<SvmControlsProps> = ({
  params,
  onChangeParams,
  showHyperplane,
  onToggleHyperplane,
  showMargins,
  onToggleMargins,
  showSupportVectors,
  onToggleSupportVectors,
  showSlackLines,
  onToggleSlackLines,
  showDecisionSurface,
  onToggleDecisionSurface,
  is3D,
}) => {
  const handleKernelChange = (k: KernelType) => {
    onChangeParams({ ...params, kernel: k });
  };

  const handleCChange = (val: number) => {
    onChangeParams({ ...params, c: val });
  };

  const handleGammaChange = (val: number) => {
    onChangeParams({ ...params, gamma: val });
  };

  const handleDegreeChange = (val: number) => {
    onChangeParams({ ...params, degree: val });
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between pb-2 border-b border-slate-100">
        <div className="flex items-center gap-2">
          <Cpu className="w-4 h-4 text-indigo-600" />
          <h2 className="text-sm font-bold text-slate-800">Hiperparámetros del Algoritmo SVM</h2>
        </div>
        <span className="text-xs px-2 py-0.5 rounded-full bg-slate-100 text-slate-600 font-medium">
          SMO Solver (Platt)
        </span>
      </div>

      {/* 1. Selector de Kernel */}
      <div>
        <div className="flex items-center justify-between mb-1.5">
          <label className="text-xs font-bold text-slate-700 flex items-center gap-1">
            <span>Función de Kernel:</span>
            <span className="font-semibold text-indigo-600">
              {params.kernel === 'linear' ? 'Lineal' : params.kernel === 'rbf' ? 'RBF (Gaussiano)' : 'Polinomial'}
            </span>
          </label>
        </div>
        <div className="grid grid-cols-3 gap-2">
          <button
            type="button"
            onClick={() => handleKernelChange('linear')}
            className={`px-3 py-2 rounded-lg text-xs font-semibold border transition-all text-center ${
              params.kernel === 'linear'
                ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
            }`}
          >
            Lineal
            <span className="block text-[10px] font-normal opacity-80">w · x + b = 0</span>
          </button>
          <button
            type="button"
            onClick={() => handleKernelChange('rbf')}
            className={`px-3 py-2 rounded-lg text-xs font-semibold border transition-all text-center ${
              params.kernel === 'rbf'
                ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
            }`}
          >
            RBF Gaussiano
            <span className="block text-[10px] font-normal opacity-80">e^(-γ||x-z||²)</span>
          </button>
          <button
            type="button"
            onClick={() => handleKernelChange('polynomial')}
            className={`px-3 py-2 rounded-lg text-xs font-semibold border transition-all text-center ${
              params.kernel === 'polynomial'
                ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
            }`}
          >
            Polinomial
            <span className="block text-[10px] font-normal opacity-80">(x·z + 1)^d</span>
          </button>
        </div>
      </div>

      {/* 2. Slider Parámetro C (Regularización) */}
      <div className="bg-slate-50/80 rounded-lg p-3 border border-slate-200/80">
        <div className="flex items-center justify-between mb-1">
          <label htmlFor="input-slider-c" className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
            <span>Parámetro C (Compromiso Margen / Error):</span>
            <span className="px-1.5 py-0.5 rounded bg-white text-indigo-700 border border-indigo-200 font-mono text-xs">
              C = {params.c < 1 ? params.c.toFixed(2) : params.c.toFixed(1)}
            </span>
          </label>
        </div>
        <input
          id="input-slider-c"
          type="range"
          min="0.05"
          max="30"
          step="0.05"
          value={params.c}
          onChange={(e) => handleCChange(parseFloat(e.target.value))}
          className="w-full accent-indigo-600 cursor-pointer h-1.5 bg-slate-200 rounded-lg"
        />
        <div className="flex justify-between text-[11px] text-slate-500 mt-1">
          <span className="text-amber-700 font-medium">Margen Blando (C bajo)</span>
          <span className="text-slate-400">Equilibrio</span>
          <span className="text-indigo-700 font-medium">Margen Estricto / Duro (C alto)</span>
        </div>
        <p className="text-[11px] text-slate-500 mt-1.5 leading-relaxed">
          {params.c < 0.8 ? (
            <span className="text-amber-700">
              💡 <strong>C bajo:</strong> Se prioriza una calle o margen más ancha, admitiendo algunas viviendas dentro del margen (tolerancia a holguras ξ_i).
            </span>
          ) : params.c > 10 ? (
            <span className="text-indigo-700">
              💡 <strong>C alto:</strong> Se penalizan fuertemente los errores. El margen se estrecha para evitar que ninguna casa quede mal clasificada.
            </span>
          ) : (
            <span>
              💡 <strong>C equilibrado:</strong> Busca el punto dulce entre máxima separación geométrica y generalización.
            </span>
          )}
        </p>
      </div>

      {/* Parámetros adicionales según Kernel */}
      {params.kernel === 'rbf' && (
        <div className="bg-indigo-50/50 rounded-lg p-3 border border-indigo-100">
          <div className="flex items-center justify-between mb-1">
            <label htmlFor="input-slider-gamma" className="text-xs font-bold text-indigo-900">
              Parámetro Gamma (γ = {params.gamma.toFixed(2)}):
            </label>
            <span className="text-[11px] text-indigo-600 font-medium">Radio de influencia</span>
          </div>
          <input
            id="input-slider-gamma"
            type="range"
            min="0.05"
            max="3.5"
            step="0.05"
            value={params.gamma}
            onChange={(e) => handleGammaChange(parseFloat(e.target.value))}
            className="w-full accent-indigo-600 cursor-pointer h-1.5 bg-indigo-200 rounded-lg"
          />
          <div className="flex justify-between text-[10px] text-indigo-700 mt-1">
            <span>Frontera suave (γ bajo)</span>
            <span>Frontera detallada (γ alto)</span>
          </div>
        </div>
      )}

      {params.kernel === 'polynomial' && (
        <div className="bg-purple-50/50 rounded-lg p-3 border border-purple-100">
          <div className="flex items-center justify-between mb-1">
            <label className="text-xs font-bold text-purple-900">
              Grado Polinomial (d = {params.degree}):
            </label>
          </div>
          <div className="flex gap-2">
            {[2, 3].map((deg) => (
              <button
                key={deg}
                type="button"
                onClick={() => handleDegreeChange(deg)}
                className={`flex-1 py-1.5 rounded text-xs font-semibold border ${
                  params.degree === deg
                    ? 'bg-purple-600 text-white border-purple-600'
                    : 'bg-white border-purple-200 text-purple-800'
                }`}
              >
                Grado {deg} {deg === 2 ? '(Cuadrático)' : '(Cúbico)'}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Capas visuales (Toggles) */}
      <div>
        <div className="flex items-center gap-1.5 text-xs font-bold text-slate-700 mb-2">
          <Eye className="w-3.5 h-3.5 text-slate-500" />
          <span>Capas y Componentes Visibles</span>
        </div>

        <div className="grid grid-cols-2 gap-2 text-xs">
          <label className="flex items-center gap-2 cursor-pointer p-1.5 rounded hover:bg-slate-50">
            <input
              type="checkbox"
              checked={showHyperplane}
              onChange={onToggleHyperplane}
              className="rounded accent-indigo-600 w-4 h-4"
            />
            <span className="font-medium text-slate-700">Hiperplano (f(x)=0)</span>
          </label>

          <label className="flex items-center gap-2 cursor-pointer p-1.5 rounded hover:bg-slate-50">
            <input
              type="checkbox"
              checked={showMargins}
              onChange={onToggleMargins}
              className="rounded accent-indigo-600 w-4 h-4"
            />
            <span className="font-medium text-slate-700">Márgenes (±1)</span>
          </label>

          <label className="flex items-center gap-2 cursor-pointer p-1.5 rounded hover:bg-slate-50">
            <input
              type="checkbox"
              checked={showSupportVectors}
              onChange={onToggleSupportVectors}
              className="rounded accent-indigo-600 w-4 h-4"
            />
            <span className="font-medium text-amber-700 font-semibold">Vectores de Soporte</span>
          </label>

          {!is3D && (
            <label className="flex items-center gap-2 cursor-pointer p-1.5 rounded hover:bg-slate-50">
              <input
                type="checkbox"
                checked={showSlackLines}
                onChange={onToggleSlackLines}
                className="rounded accent-indigo-600 w-4 h-4"
              />
              <span className="font-medium text-slate-700">Holguras (ξ_i)</span>
            </label>
          )}

          {!is3D && (
            <label className="flex items-center gap-2 cursor-pointer p-1.5 rounded hover:bg-slate-50">
              <input
                type="checkbox"
                checked={showDecisionSurface}
                onChange={onToggleDecisionSurface}
                className="rounded accent-indigo-600 w-4 h-4"
              />
              <span className="font-medium text-slate-700">Mapa de Decisión</span>
            </label>
          )}
        </div>
      </div>
    </div>
  );
};
