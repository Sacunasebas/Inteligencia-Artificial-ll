import React from 'react';
import { HousingFeatureKey } from '../types';
import { HOUSING_FEATURES } from '../data/housingData';
import { SlidersHorizontal, Box, Square, Sparkles } from 'lucide-react';

interface VariableSelectorProps {
  dimensionMode: '2D' | '3D';
  onDimensionChange: (dim: '2D' | '3D') => void;
  featureX: HousingFeatureKey;
  featureY: HousingFeatureKey;
  featureZ: HousingFeatureKey;
  onFeatureXChange: (key: HousingFeatureKey) => void;
  onFeatureYChange: (key: HousingFeatureKey) => void;
  onFeatureZChange: (key: HousingFeatureKey) => void;
}

export const VariableSelector: React.FC<VariableSelectorProps> = ({
  dimensionMode,
  onDimensionChange,
  featureX,
  featureY,
  featureZ,
  onFeatureXChange,
  onFeatureYChange,
  onFeatureZChange,
}) => {
  const featureList = Object.values(HOUSING_FEATURES);

  const applyPreset = (x: HousingFeatureKey, y: HousingFeatureKey, z?: HousingFeatureKey) => {
    onFeatureXChange(x);
    onFeatureYChange(y);
    if (z) {
      onFeatureZChange(z);
      onDimensionChange('3D');
    } else {
      onDimensionChange('2D');
    }
  };

  return (
    <div className="bg-white rounded-xl border border-slate-200 p-4 shadow-xs">
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-100">
        <div className="flex items-center gap-2">
          <SlidersHorizontal className="w-4 h-4 text-indigo-600" />
          <h2 className="text-sm font-bold text-slate-800">Variables de las Viviendas de EE.UU.</h2>
        </div>

        {/* 2D vs 3D Dimension toggle */}
        <div className="inline-flex p-0.5 rounded-lg bg-slate-100 border border-slate-200 text-xs font-semibold">
          <button
            id="toggle-dim-2d"
            onClick={() => onDimensionChange('2D')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-md transition-all ${
              dimensionMode === '2D'
                ? 'bg-white text-indigo-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Square className="w-3.5 h-3.5" />
            <span>2 Dimensiones (2D)</span>
          </button>
          <button
            id="toggle-dim-3d"
            onClick={() => onDimensionChange('3D')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-md transition-all ${
              dimensionMode === '3D'
                ? 'bg-white text-indigo-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Box className="w-3.5 h-3.5" />
            <span>3 Dimensiones (3D)</span>
          </button>
        </div>
      </div>

      {/* Dropdown Selectors */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 pt-3">
        {/* Axis X */}
        <div>
          <label htmlFor="select-feature-x" className="block text-xs font-semibold text-slate-600 mb-1">
            Eje X (Horizontal)
          </label>
          <select
            id="select-feature-x"
            value={featureX}
            onChange={(e) => onFeatureXChange(e.target.value as HousingFeatureKey)}
            className="w-full text-xs font-medium bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-slate-800"
          >
            {featureList.map((f) => (
              <option key={`x-${f.key}`} value={f.key} disabled={f.key === featureY || (dimensionMode === '3D' && f.key === featureZ)}>
                {f.name} ({f.unit})
              </option>
            ))}
          </select>
          <p className="text-[11px] text-slate-400 mt-0.5 truncate">{HOUSING_FEATURES[featureX].description}</p>
        </div>

        {/* Axis Y */}
        <div>
          <label htmlFor="select-feature-y" className="block text-xs font-semibold text-slate-600 mb-1">
            Eje Y (Vertical)
          </label>
          <select
            id="select-feature-y"
            value={featureY}
            onChange={(e) => onFeatureYChange(e.target.value as HousingFeatureKey)}
            className="w-full text-xs font-medium bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1.5 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 text-slate-800"
          >
            {featureList.map((f) => (
              <option key={`y-${f.key}`} value={f.key} disabled={f.key === featureX || (dimensionMode === '3D' && f.key === featureZ)}>
                {f.name} ({f.unit})
              </option>
            ))}
          </select>
          <p className="text-[11px] text-slate-400 mt-0.5 truncate">{HOUSING_FEATURES[featureY].description}</p>
        </div>

        {/* Axis Z (Only for 3D) */}
        {dimensionMode === '3D' ? (
          <div>
            <label htmlFor="select-feature-z" className="block text-xs font-semibold text-indigo-600 mb-1">
              Eje Z (Profundidad 3D)
            </label>
            <select
              id="select-feature-z"
              value={featureZ}
              onChange={(e) => onFeatureZChange(e.target.value as HousingFeatureKey)}
              className="w-full text-xs font-medium bg-indigo-50/50 border border-indigo-200 rounded-lg px-2.5 py-1.5 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 text-indigo-900"
            >
              {featureList.map((f) => (
                <option key={`z-${f.key}`} value={f.key} disabled={f.key === featureX || f.key === featureY}>
                  {f.name} ({f.unit})
                </option>
              ))}
            </select>
            <p className="text-[11px] text-indigo-500 mt-0.5 truncate">{HOUSING_FEATURES[featureZ].description}</p>
          </div>
        ) : (
          <div className="flex flex-col justify-end">
            <span className="text-[11px] text-slate-500 font-medium mb-1 flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-amber-500" /> Presets recomendados:
            </span>
            <div className="flex flex-wrap gap-1.5">
              <button
                type="button"
                onClick={() => applyPreset('sqft', 'median_income_k')}
                className="text-[11px] px-2 py-1 rounded bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 text-slate-600 transition-colors"
              >
                Superficie vs Ingreso
              </button>
              <button
                type="button"
                onClick={() => applyPreset('price_k', 'house_age')}
                className="text-[11px] px-2 py-1 rounded bg-slate-100 hover:bg-indigo-50 hover:text-indigo-700 text-slate-600 transition-colors"
              >
                Precio vs Antigüedad
              </button>
              <button
                type="button"
                onClick={() => applyPreset('sqft', 'median_income_k', 'house_age')}
                className="text-[11px] px-2 py-1 rounded bg-indigo-50 text-indigo-700 hover:bg-indigo-100 transition-colors flex items-center gap-1"
              >
                <Box className="w-2.5 h-2.5" /> Explorar en 3D
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
