import React from 'react';
import { Layers, BookOpen, Trophy, TableProperties, Sparkles, Home } from 'lucide-react';

export type TabMode = 'simulator' | 'pedagogy' | 'challenge' | 'dataset';

interface NavbarProps {
  currentTab: TabMode;
  onSelectTab: (tab: TabMode) => void;
  onOpenPredictor: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentTab, onSelectTab, onOpenPredictor }) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Title */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-600 to-blue-600 flex items-center justify-center text-white shadow-sm shadow-indigo-200">
              <Layers className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-extrabold text-lg tracking-tight text-slate-900">SVM Lab</span>
                <span className="px-2 py-0.5 text-xs font-semibold rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200/60">
                  30 Casas EE.UU.
                </span>
              </div>
              <p className="text-xs text-slate-500 hidden sm:block">
                Simulador de Máquinas de Soporte Vectorial en 2D & 3D
              </p>
            </div>
          </div>

          {/* Navigation Tabs */}
          <nav className="flex items-center gap-1 sm:gap-2">
            <button
              id="nav-tab-simulator"
              onClick={() => onSelectTab('simulator')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                currentTab === 'simulator'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Layers className="w-4 h-4" />
              <span>Simulador 2D/3D</span>
            </button>

            <button
              id="nav-tab-pedagogy"
              onClick={() => onSelectTab('pedagogy')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                currentTab === 'pedagogy'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <BookOpen className="w-4 h-4" />
              <span>Componentes</span>
            </button>

            <button
              id="nav-tab-challenge"
              onClick={() => onSelectTab('challenge')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                currentTab === 'challenge'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <Trophy className="w-4 h-4" />
              <span className="relative">
                Desafío
                <span className="hidden md:inline text-xs ml-1 font-normal opacity-90">Lúdico</span>
              </span>
            </button>

            <button
              id="nav-tab-dataset"
              onClick={() => onSelectTab('dataset')}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                currentTab === 'dataset'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <TableProperties className="w-4 h-4" />
              <span>Dataset (30)</span>
            </button>
          </nav>

          {/* Action Button: Live Predictor */}
          <div className="hidden lg:flex items-center gap-2">
            <button
              id="btn-open-predictor"
              onClick={onOpenPredictor}
              className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100 transition-colors"
            >
              <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
              <span>Probar Casa Nueva</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
