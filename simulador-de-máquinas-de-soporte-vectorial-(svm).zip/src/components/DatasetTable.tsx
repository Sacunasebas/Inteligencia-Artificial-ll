import React, { useState, useMemo } from 'react';
import { HousingRecord, SVMSolution } from '../types';
import { USA_HOUSING_DATASET_30 } from '../data/housingData';
import { Search, Sparkles, Filter, CheckCircle2, Home, ArrowUpDown, ExternalLink } from 'lucide-react';

interface DatasetTableProps {
  solution: SVMSolution;
  onSelectHouse: (record: HousingRecord) => void;
  selectedHouseId: number | null;
}

export const DatasetTable: React.FC<DatasetTableProps> = ({
  solution,
  onSelectHouse,
  selectedHouseId,
}) => {
  const [search, setSearch] = useState('');
  const [filterClass, setFilterClass] = useState<'all' | 'premium' | 'standard' | 'sv_only'>('all');
  const [sortField, setSortField] = useState<keyof HousingRecord>('id');
  const [sortAsc, setSortAsc] = useState(true);

  // Map of Support Vector details
  const svMap = useMemo(() => {
    const map = new Map<number, (typeof solution.supportVectors)[0]>();
    solution.supportVectors.forEach((sv) => {
      map.set(sv.record.id, sv);
    });
    return map;
  }, [solution]);

  // Filter and sort records
  const filteredRecords = useMemo(() => {
    return USA_HOUSING_DATASET_30.filter((r) => {
      const matchesSearch =
        r.city.toLowerCase().includes(search.toLowerCase()) ||
        r.state.toLowerCase().includes(search.toLowerCase()) ||
        r.neighborhoodType.toLowerCase().includes(search.toLowerCase());

      if (!matchesSearch) return false;

      if (filterClass === 'premium') return r.label === 1;
      if (filterClass === 'standard') return r.label === -1;
      if (filterClass === 'sv_only') return svMap.has(r.id);

      return true;
    }).sort((a, b) => {
      const valA = a[sortField];
      const valB = b[sortField];
      if (valA < valB) return sortAsc ? -1 : 1;
      if (valA > valB) return sortAsc ? 1 : -1;
      return 0;
    });
  }, [search, filterClass, sortField, sortAsc, svMap]);

  const handleSort = (field: keyof HousingRecord) => {
    if (sortField === field) {
      setSortAsc(!sortAsc);
    } else {
      setSortField(field);
      setSortAsc(true);
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs space-y-4">
      {/* Header & Stats */}
      <div className="p-5 border-b border-slate-100 flex flex-wrap items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-bold text-slate-900">Dataset de 30 Viviendas de Estados Unidos</h2>
            <span className="px-2 py-0.5 rounded-full text-xs font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200">
              30 Muestras Reales
            </span>
          </div>
          <p className="text-xs text-slate-500 mt-0.5">
            Observa cómo el algoritmo SVM etiqueta y selecciona los puntos frontera como <strong>Vectores de Soporte</strong>.
          </p>
        </div>

        {/* Quick Stats */}
        <div className="flex items-center gap-3 text-xs">
          <div className="bg-blue-50 text-blue-800 px-3 py-1.5 rounded-lg border border-blue-200 font-medium">
            15 Premium (+1)
          </div>
          <div className="bg-amber-50 text-amber-800 px-3 py-1.5 rounded-lg border border-amber-200 font-medium">
            15 Estándar (-1)
          </div>
          <div className="bg-yellow-50 text-yellow-800 px-3 py-1.5 rounded-lg border border-yellow-200 font-bold flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5 text-yellow-600" />
            <span>{solution.supportVectors.length} Vectores de Soporte</span>
          </div>
        </div>
      </div>

      {/* Toolbar: Search and Filters */}
      <div className="px-5 flex flex-wrap items-center justify-between gap-3">
        {/* Search */}
        <div className="relative min-w-[240px] flex-1 max-w-sm">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Buscar por ciudad, estado o vecindario..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full text-xs pl-9 pr-3 py-2 rounded-lg border border-slate-200 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
          />
        </div>

        {/* Filters */}
        <div className="flex items-center gap-1.5 text-xs">
          <span className="text-slate-400 font-medium mr-1 flex items-center gap-1">
            <Filter className="w-3.5 h-3.5" /> Filtrar:
          </span>
          <button
            onClick={() => setFilterClass('all')}
            className={`px-2.5 py-1 rounded-md font-medium transition-all ${
              filterClass === 'all' ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Todas (30)
          </button>
          <button
            onClick={() => setFilterClass('sv_only')}
            className={`px-2.5 py-1 rounded-md font-medium transition-all flex items-center gap-1 ${
              filterClass === 'sv_only' ? 'bg-amber-600 text-white' : 'bg-amber-50 text-amber-800 border border-amber-200 hover:bg-amber-100'
            }`}
          >
            <Sparkles className="w-3 h-3" /> Solo Vectores Soporte ({solution.supportVectors.length})
          </button>
          <button
            onClick={() => setFilterClass('premium')}
            className={`px-2.5 py-1 rounded-md font-medium transition-all ${
              filterClass === 'premium' ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Premium (+1)
          </button>
          <button
            onClick={() => setFilterClass('standard')}
            className={`px-2.5 py-1 rounded-md font-medium transition-all ${
              filterClass === 'standard' ? 'bg-orange-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            Estándar (-1)
          </button>
        </div>
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-50 text-slate-600 font-bold border-y border-slate-200">
            <tr>
              <th className="py-2.5 px-4 cursor-pointer hover:text-indigo-600" onClick={() => handleSort('id')}>
                <div className="flex items-center gap-1">
                  <span>#</span>
                  <ArrowUpDown className="w-3 h-3" />
                </div>
              </th>
              <th className="py-2.5 px-4 cursor-pointer hover:text-indigo-600" onClick={() => handleSort('city')}>
                <div className="flex items-center gap-1">
                  <span>Ubicación (EE.UU.)</span>
                  <ArrowUpDown className="w-3 h-3" />
                </div>
              </th>
              <th className="py-2.5 px-3 cursor-pointer hover:text-indigo-600" onClick={() => handleSort('sqft')}>
                <div className="flex items-center gap-1">
                  <span>Superficie</span>
                  <ArrowUpDown className="w-3 h-3" />
                </div>
              </th>
              <th className="py-2.5 px-3 cursor-pointer hover:text-indigo-600" onClick={() => handleSort('bedrooms')}>
                <div className="flex items-center gap-1">
                  <span>Hab.</span>
                  <ArrowUpDown className="w-3 h-3" />
                </div>
              </th>
              <th className="py-2.5 px-3 cursor-pointer hover:text-indigo-600" onClick={() => handleSort('median_income_k')}>
                <div className="flex items-center gap-1">
                  <span>Ingreso Medio</span>
                  <ArrowUpDown className="w-3 h-3" />
                </div>
              </th>
              <th className="py-2.5 px-3 cursor-pointer hover:text-indigo-600" onClick={() => handleSort('house_age')}>
                <div className="flex items-center gap-1">
                  <span>Antigüedad</span>
                  <ArrowUpDown className="w-3 h-3" />
                </div>
              </th>
              <th className="py-2.5 px-3 cursor-pointer hover:text-indigo-600" onClick={() => handleSort('price_k')}>
                <div className="flex items-center gap-1">
                  <span>Precio de Mercado</span>
                  <ArrowUpDown className="w-3 h-3" />
                </div>
              </th>
              <th className="py-2.5 px-3">Categoría Real</th>
              <th className="py-2.5 px-4">Rol en Algoritmo SVM</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
            {filteredRecords.map((rec) => {
              const isSV = svMap.has(rec.id);
              const svInfo = svMap.get(rec.id);
              const isSelected = selectedHouseId === rec.id;

              return (
                <tr
                  key={`row-${rec.id}`}
                  onClick={() => onSelectHouse(rec)}
                  className={`cursor-pointer transition-colors ${
                    isSelected
                      ? 'bg-indigo-50/90'
                      : isSV
                      ? 'bg-amber-50/40 hover:bg-amber-50/80'
                      : 'hover:bg-slate-50'
                  }`}
                >
                  <td className="py-2.5 px-4 font-mono text-slate-400">{rec.id}</td>
                  <td className="py-2.5 px-4">
                    <div className="font-bold text-slate-900">
                      {rec.city}, <span className="text-slate-500 font-normal">{rec.state}</span>
                    </div>
                    <div className="text-[11px] text-slate-400 truncate max-w-[170px]">
                      {rec.neighborhoodType}
                    </div>
                  </td>
                  <td className="py-2.5 px-3 font-mono">{rec.sqft.toLocaleString()} sq ft</td>
                  <td className="py-2.5 px-3 font-mono">{rec.bedrooms} hab</td>
                  <td className="py-2.5 px-3 font-mono">${rec.median_income_k}k/año</td>
                  <td className="py-2.5 px-3 font-mono">{rec.house_age} años</td>
                  <td className="py-2.5 px-3 font-mono font-bold text-slate-900">
                    ${rec.price_k}k USD
                  </td>
                  <td className="py-2.5 px-3">
                    <span
                      className={`inline-flex items-center px-2 py-0.5 rounded-full text-[11px] font-semibold ${
                        rec.label === 1
                          ? 'bg-blue-100 text-blue-800'
                          : 'bg-orange-100 text-orange-800'
                      }`}
                    >
                      {rec.label === 1 ? 'Premium (+1)' : 'Estándar (-1)'}
                    </span>
                  </td>
                  <td className="py-2.5 px-4">
                    {isSV ? (
                      <div className="flex items-center gap-1.5">
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-bold bg-amber-100 text-amber-900 border border-amber-300">
                          <Sparkles className="w-3 h-3 text-amber-600" />
                          <span>Vector Soporte (α = {svInfo?.alpha.toFixed(2)})</span>
                        </span>
                      </div>
                    ) : (
                      <span className="text-[11px] text-slate-400 font-normal">
                        Punto Regular (α = 0)
                      </span>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
};
