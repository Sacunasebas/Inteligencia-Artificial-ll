/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { Navbar, TabMode } from './components/Navbar';
import { VariableSelector } from './components/VariableSelector';
import { SvmControls } from './components/SvmControls';
import { Svm2DView } from './components/Svm2DView';
import { Svm3DView } from './components/Svm3DView';
import { ComponentsPedagogy } from './components/ComponentsPedagogy';
import { MiniGameChallenge } from './components/MiniGameChallenge';
import { DatasetTable } from './components/DatasetTable';
import { PredictorDrawer } from './components/PredictorDrawer';
import { USA_HOUSING_DATASET_30, HOUSING_FEATURES } from './data/housingData';
import { HousingFeatureKey, SVMHyperparameters, HousingRecord } from './types';
import { SVMSolver } from './ml/svmEngine';
import { Sparkles, Info, X, Home, ExternalLink, RefreshCw } from 'lucide-react';

export default function App() {
  const records = USA_HOUSING_DATASET_30;

  // Navigation and view state
  const [currentTab, setCurrentTab] = useState<TabMode>('simulator');
  const [dimensionMode, setDimensionMode] = useState<'2D' | '3D'>('2D');

  // Selected Features
  const [featureX, setFeatureX] = useState<HousingFeatureKey>('sqft');
  const [featureY, setFeatureY] = useState<HousingFeatureKey>('median_income_k');
  const [featureZ, setFeatureZ] = useState<HousingFeatureKey>('house_age');

  // SVM Hyperparameters
  const [params, setParams] = useState<SVMHyperparameters>({
    c: 2.0,
    kernel: 'linear',
    gamma: 0.5,
    degree: 2,
  });

  // Visual toggles
  const [showHyperplane, setShowHyperplane] = useState<boolean>(true);
  const [showMargins, setShowMargins] = useState<boolean>(true);
  const [showSupportVectors, setShowSupportVectors] = useState<boolean>(true);
  const [showSlackLines, setShowSlackLines] = useState<boolean>(true);
  const [showDecisionSurface, setShowDecisionSurface] = useState<boolean>(true);

  // Live tester & selected house
  const [probePoint, setProbePoint] = useState<{ x: number; y: number } | null>(null);
  const [selectedHouse, setSelectedHouse] = useState<HousingRecord | null>(null);
  const [isPredictorOpen, setIsPredictorOpen] = useState<boolean>(false);

  // Train 2D SVM Solver
  const { solver2D, solution2D } = useMemo(() => {
    const s = new SVMSolver(records, [featureX, featureY], params);
    const sol = s.train(45);
    return { solver2D: s, solution2D: sol };
  }, [records, featureX, featureY, params]);

  return (
    <div className="min-h-screen bg-slate-100/70 text-slate-800 flex flex-col font-['Plus_Jakarta_Sans',sans-serif]">
      {/* Navigation Header */}
      <Navbar
        currentTab={currentTab}
        onSelectTab={(t) => setCurrentTab(t)}
        onOpenPredictor={() => setIsPredictorOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8 space-y-6">
        {/* TAB 1: SIMULADOR 2D / 3D */}
        {currentTab === 'simulator' && (
          <div className="space-y-6">
            {/* Top Selector: Variables & Dimensions */}
            <VariableSelector
              dimensionMode={dimensionMode}
              onDimensionChange={setDimensionMode}
              featureX={featureX}
              featureY={featureY}
              featureZ={featureZ}
              onFeatureXChange={setFeatureX}
              onFeatureYChange={setFeatureY}
              onFeatureZChange={setFeatureZ}
            />

            {/* Grid Layout: Visual Canvas + Controls Panel */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              {/* Left Column: Visualizer (2D or 3D) */}
              <div className="lg:col-span-8 space-y-4">
                {dimensionMode === '2D' ? (
                  <Svm2DView
                    records={records}
                    featureX={featureX}
                    featureY={featureY}
                    solver={solver2D}
                    solution={solution2D}
                    params={params}
                    showHyperplane={showHyperplane}
                    showMargins={showMargins}
                    showSupportVectors={showSupportVectors}
                    showSlackLines={showSlackLines}
                    showDecisionSurface={showDecisionSurface}
                    probePoint={probePoint}
                    onSetProbePoint={setProbePoint}
                    selectedHouseId={selectedHouse?.id || null}
                    onSelectHouse={setSelectedHouse}
                  />
                ) : (
                  <Svm3DView
                    records={records}
                    featureX={featureX}
                    featureY={featureY}
                    featureZ={featureZ}
                    params={params}
                    showHyperplane={showHyperplane}
                    showMargins={showMargins}
                    showSupportVectors={showSupportVectors}
                    selectedHouseId={selectedHouse?.id || null}
                    onSelectHouse={setSelectedHouse}
                  />
                )}

                {/* Pedagogical Quick Note */}
                <div className="bg-indigo-50/70 border border-indigo-100 rounded-xl p-3.5 text-xs text-indigo-950 flex items-start gap-2.5">
                  <Sparkles className="w-4 h-4 text-indigo-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-indigo-900">¿Qué estás observando en pantalla?</span>
                    <p className="text-indigo-800/90 mt-0.5 leading-relaxed">
                      El SVM encuentra el hiperplano óptimo que maximiza la distancia (el margen) hacia las casas más difíciles de clasificar.
                      Los círculos con aura dorada son los <strong>Vectores de Soporte</strong>: los únicos datos necesarios para sostener la decisión.
                    </p>
                  </div>
                </div>
              </div>

              {/* Right Column: Parameters & Controls */}
              <div className="lg:col-span-4 space-y-4">
                <SvmControls
                  params={params}
                  onChangeParams={setParams}
                  showHyperplane={showHyperplane}
                  onToggleHyperplane={() => setShowHyperplane(!showHyperplane)}
                  showMargins={showMargins}
                  onToggleMargins={() => setShowMargins(!showMargins)}
                  showSupportVectors={showSupportVectors}
                  onToggleSupportVectors={() => setShowSupportVectors(!showSupportVectors)}
                  showSlackLines={showSlackLines}
                  onToggleSlackLines={() => setShowSlackLines(!showSlackLines)}
                  showDecisionSurface={showDecisionSurface}
                  onToggleDecisionSurface={() => setShowDecisionSurface(!showDecisionSurface)}
                  is3D={dimensionMode === '3D'}
                />
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: LABORATORIO PEDAGÓGICO DE COMPONENTES */}
        {currentTab === 'pedagogy' && <ComponentsPedagogy />}

        {/* TAB 3: DESAFÍO LÚDICO */}
        {currentTab === 'challenge' && <MiniGameChallenge />}

        {/* TAB 4: DATASET DE 30 VIVIENDAS */}
        {currentTab === 'dataset' && (
          <DatasetTable
            solution={solution2D}
            onSelectHouse={(h) => setSelectedHouse(h)}
            selectedHouseId={selectedHouse?.id || null}
          />
        )}
      </main>

      {/* Selected House Modal / Drawer */}
      {selectedHouse && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs">
          <div className="bg-white rounded-2xl border border-slate-200 shadow-2xl max-w-md w-full overflow-hidden">
            <div className="p-4 bg-slate-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Home className="w-4 h-4 text-indigo-400" />
                <span className="font-bold text-sm">
                  {selectedHouse.city}, {selectedHouse.state}
                </span>
              </div>
              <button
                onClick={() => setSelectedHouse(null)}
                className="p-1 rounded text-slate-400 hover:text-white hover:bg-slate-800"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-5 space-y-3 text-xs">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <span className="text-slate-500">Vecindario:</span>
                <span className="font-semibold text-slate-800">{selectedHouse.neighborhoodType}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Superficie Habitable:</span>
                <span className="font-bold text-slate-900">{selectedHouse.sqft.toLocaleString()} sq ft</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Habitaciones:</span>
                <span className="font-bold text-slate-900">{selectedHouse.bedrooms} dormitorios</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Ingreso Medio del Área:</span>
                <span className="font-bold text-slate-900">${selectedHouse.median_income_k}k USD / año</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Antigüedad de la Casa:</span>
                <span className="font-bold text-slate-900">{selectedHouse.house_age} años</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-slate-500">Precio Tasado:</span>
                <span className="font-bold text-emerald-700 font-mono text-sm">${selectedHouse.price_k}k USD</span>
              </div>

              <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                <span className="text-slate-500">Categoría Oficial:</span>
                <span
                  className={`px-2 py-0.5 rounded-full font-bold ${
                    selectedHouse.label === 1
                      ? 'bg-blue-100 text-blue-800'
                      : 'bg-amber-100 text-amber-800'
                  }`}
                >
                  {selectedHouse.labelName}
                </span>
              </div>
            </div>

            <div className="p-3 bg-slate-50 border-t border-slate-200 text-right">
              <button
                onClick={() => setSelectedHouse(null)}
                className="px-4 py-1.5 rounded-lg bg-slate-200 hover:bg-slate-300 text-slate-700 font-semibold text-xs transition-colors"
              >
                Cerrar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* New House Live Predictor Drawer */}
      <PredictorDrawer
        isOpen={isPredictorOpen}
        onClose={() => setIsPredictorOpen(false)}
        solver={solver2D}
        solution={solution2D}
        featureX={featureX}
        featureY={featureY}
        onSetProbePoint={(pt) => {
          setProbePoint(pt);
          setCurrentTab('simulator');
        }}
      />
    </div>
  );
}
