import { HousingRecord, HousingFeatureKey, SVMHyperparameters, SVMSolution, SupportVectorInfo, KernelType } from '../types';

export interface Scaler {
  mean: number[];
  std: number[];
}

export function computeScaler(data: number[][]): Scaler {
  const numFeatures = data[0].length;
  const mean: number[] = new Array(numFeatures).fill(0);
  const std: number[] = new Array(numFeatures).fill(0);

  for (let i = 0; i < data.length; i++) {
    for (let j = 0; j < numFeatures; j++) {
      mean[j] += data[i][j];
    }
  }
  for (let j = 0; j < numFeatures; j++) {
    mean[j] /= data.length;
  }

  for (let i = 0; i < data.length; i++) {
    for (let j = 0; j < numFeatures; j++) {
      std[j] += Math.pow(data[i][j] - mean[j], 2);
    }
  }
  for (let j = 0; j < numFeatures; j++) {
    std[j] = Math.sqrt(std[j] / data.length) || 1;
  }

  return { mean, std };
}

export function transform(vec: number[], scaler: Scaler): number[] {
  return vec.map((v, idx) => (v - scaler.mean[idx]) / scaler.std[idx]);
}

export function inverseTransform(vec: number[], scaler: Scaler): number[] {
  return vec.map((v, idx) => v * scaler.std[idx] + scaler.mean[idx]);
}

// Kernel computation
export function kernelFunction(x1: number[], x2: number[], params: SVMHyperparameters): number {
  if (params.kernel === 'linear') {
    let dot = 0;
    for (let i = 0; i < x1.length; i++) dot += x1[i] * x2[i];
    return dot;
  } else if (params.kernel === 'rbf') {
    let distSq = 0;
    for (let i = 0; i < x1.length; i++) {
      const diff = x1[i] - x2[i];
      distSq += diff * diff;
    }
    return Math.exp(-params.gamma * distSq);
  } else if (params.kernel === 'polynomial') {
    let dot = 0;
    for (let i = 0; i < x1.length; i++) dot += x1[i] * x2[i];
    return Math.pow(dot * 0.5 + 1, params.degree);
  }
  return 0;
}

// Sequential Minimal Optimization (SMO) Solver
export class SVMSolver {
  private X: number[][] = [];
  private y: number[] = [];
  private alpha: number[] = [];
  private b: number = 0;
  private params: SVMHyperparameters;
  private scaler: Scaler;
  private rawRecords: HousingRecord[];
  private featureKeys: HousingFeatureKey[];

  constructor(
    records: HousingRecord[],
    featureKeys: HousingFeatureKey[],
    params: SVMHyperparameters
  ) {
    this.rawRecords = records;
    this.featureKeys = featureKeys;
    this.params = params;

    // Extract raw features
    const rawX = records.map(r => featureKeys.map(k => r[k]));
    this.scaler = computeScaler(rawX);
    this.X = rawX.map(r => transform(r, this.scaler));
    this.y = records.map(r => r.label);
    this.alpha = new Array(records.length).fill(0);
  }

  public train(maxPasses: number = 40, tol: number = 1e-3): SVMSolution {
    const N = this.X.length;
    const C = this.params.c;
    this.alpha = new Array(N).fill(0);
    this.b = 0;

    // Precompute Kernel matrix
    const K: number[][] = [];
    for (let i = 0; i < N; i++) {
      K[i] = [];
      for (let j = 0; j < N; j++) {
        K[i][j] = kernelFunction(this.X[i], this.X[j], this.params);
      }
    }

    const predictRawIdx = (idx: number): number => {
      let sum = 0;
      for (let i = 0; i < N; i++) {
        if (this.alpha[i] > 1e-6) {
          sum += this.alpha[i] * this.y[i] * K[i][idx];
        }
      }
      return sum + this.b;
    };

    let passes = 0;
    const maxIters = maxPasses * N;
    let iters = 0;

    while (passes < maxPasses && iters < maxIters) {
      iters++;
      let numChangedAlphas = 0;

      for (let i = 0; i < N; i++) {
        const Ei = predictRawIdx(i) - this.y[i];
        const r = this.y[i] * Ei;

        // Check KKT conditions violation
        if ((r < -tol && this.alpha[i] < C) || (r > tol && this.alpha[i] > 0)) {
          // Select j != i (random heuristic)
          let j = Math.floor(Math.random() * (N - 1));
          if (j >= i) j++;

          const Ej = predictRawIdx(j) - this.y[j];
          const alphaIOld = this.alpha[i];
          const alphaJOld = this.alpha[j];

          // Compute bounds L and H for alpha[j]
          let L = 0;
          let H = C;
          if (this.y[i] !== this.y[j]) {
            L = Math.max(0, this.alpha[j] - this.alpha[i]);
            H = Math.min(C, C + this.alpha[j] - this.alpha[i]);
          } else {
            L = Math.max(0, this.alpha[i] + this.alpha[j] - C);
            H = Math.min(C, this.alpha[i] + this.alpha[j]);
          }

          if (Math.abs(L - H) < 1e-5) continue;

          // Compute eta = 2*K(i,j) - K(i,i) - K(j,j)
          const eta = 2 * K[i][j] - K[i][i] - K[j][j];
          if (eta >= 0) continue;

          // Update alpha[j]
          let newAlphaJ = alphaJOld - (this.y[j] * (Ei - Ej)) / eta;
          // Clip to [L, H]
          newAlphaJ = Math.min(H, Math.max(L, newAlphaJ));

          if (Math.abs(newAlphaJ - alphaJOld) < 1e-5) continue;

          // Update alpha[i]
          const newAlphaI = alphaIOld + this.y[i] * this.y[j] * (alphaJOld - newAlphaJ);

          // Update threshold b
          const b1 = this.b - Ei - this.y[i] * (newAlphaI - alphaIOld) * K[i][i] - this.y[j] * (newAlphaJ - alphaJOld) * K[i][j];
          const b2 = this.b - Ej - this.y[i] * (newAlphaI - alphaIOld) * K[i][j] - this.y[j] * (newAlphaJ - alphaJOld) * K[j][j];

          if (newAlphaI > 0 && newAlphaI < C) {
            this.b = b1;
          } else if (newAlphaJ > 0 && newAlphaJ < C) {
            this.b = b2;
          } else {
            this.b = (b1 + b2) / 2;
          }

          this.alpha[i] = newAlphaI;
          this.alpha[j] = newAlphaJ;
          numChangedAlphas++;
        }
      }

      if (numChangedAlphas === 0) {
        passes++;
      } else {
        passes = 0;
      }
    }

    // Compute weights w for linear kernel
    const d = this.featureKeys.length;
    const w: number[] = new Array(d).fill(0);
    if (this.params.kernel === 'linear') {
      for (let i = 0; i < N; i++) {
        if (this.alpha[i] > 1e-6) {
          for (let dim = 0; dim < d; dim++) {
            w[dim] += this.alpha[i] * this.y[i] * this.X[i][dim];
          }
        }
      }
    }

    // Identify Support Vectors
    const supportVectors: SupportVectorInfo[] = [];
    let numMarginViolations = 0;
    let totalSlack = 0;

    for (let i = 0; i < N; i++) {
      const a = this.alpha[i];
      if (a > 1e-4) {
        const rawF = this.predictNormalized(this.X[i]);
        const functionalMargin = this.y[i] * rawF;
        const slack = Math.max(0, 1 - functionalMargin);
        const isBound = Math.abs(a - C) < 1e-3;

        if (slack > 1e-3) {
          numMarginViolations++;
          totalSlack += slack;
        }

        // Geometric distance to hyperplane: |f(x)| / ||w|| (or |f(x)|)
        const wNorm = Math.sqrt(w.reduce((acc, v) => acc + v * v, 0)) || 1;
        const distanceToPlane = Math.abs(rawF) / wNorm;

        supportVectors.push({
          index: i,
          record: this.rawRecords[i],
          alpha: a,
          isMarginBound: isBound,
          slack,
          distanceToPlane
        });
      }
    }

    // Calculate accuracy on the dataset
    let correct = 0;
    for (let i = 0; i < N; i++) {
      const pred = this.predictRaw(this.rawRecords[i]);
      if ((pred >= 0 ? 1 : -1) === this.y[i]) {
        correct++;
      }
    }

    const accuracy = (correct / N) * 100;
    const wNorm = Math.sqrt(w.reduce((acc, v) => acc + v * v, 0)) || 1;
    const marginWidth = 2 / wNorm;

    return {
      w,
      b: this.b,
      marginWidth,
      supportVectors,
      accuracy,
      numMarginViolations,
      totalLoss: 0.5 * wNorm * wNorm + C * totalSlack
    };
  }

  // Predict on normalized feature vector
  public predictNormalized(normX: number[]): number {
    let sum = 0;
    for (let i = 0; i < this.X.length; i++) {
      if (this.alpha[i] > 1e-5) {
        const k = kernelFunction(this.X[i], normX, this.params);
        sum += this.alpha[i] * this.y[i] * k;
      }
    }
    return sum + this.b;
  }

  // Predict on raw record or raw feature array
  public predictRaw(recordOrFeatures: HousingRecord | number[]): number {
    let rawVec: number[];
    if (Array.isArray(recordOrFeatures)) {
      rawVec = recordOrFeatures;
    } else {
      rawVec = this.featureKeys.map(k => recordOrFeatures[k]);
    }
    const normX = transform(rawVec, this.scaler);
    return this.predictNormalized(normX);
  }

  public getScaler(): Scaler {
    return this.scaler;
  }

  public getAlpha(): number[] {
    return [...this.alpha];
  }
}

// Evaluates a 2D mesh grid for decision boundary and margin contouring
export function generate2DMesh(
  solver: SVMSolver,
  xMin: number,
  xMax: number,
  yMin: number,
  yMax: number,
  gridSize: number = 36
): {
  grid: number[][]; // values of f(x, y)
  xStep: number;
  yStep: number;
  xs: number[];
  ys: number[];
} {
  const xs: number[] = [];
  const ys: number[] = [];
  const xStep = (xMax - xMin) / (gridSize - 1);
  const yStep = (yMax - yMin) / (gridSize - 1);

  for (let i = 0; i < gridSize; i++) xs.push(xMin + i * xStep);
  for (let j = 0; j < gridSize; j++) ys.push(yMin + j * yStep);

  const grid: number[][] = [];
  for (let i = 0; i < gridSize; i++) {
    grid[i] = [];
    for (let j = 0; j < gridSize; j++) {
      grid[i][j] = solver.predictRaw([xs[i], ys[j]]);
    }
  }

  return { grid, xStep, yStep, xs, ys };
}
