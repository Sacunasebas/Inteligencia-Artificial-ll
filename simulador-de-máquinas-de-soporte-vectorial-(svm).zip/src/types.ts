export type HousingFeatureKey = 'sqft' | 'bedrooms' | 'median_income_k' | 'house_age' | 'price_k';

export interface HousingRecord {
  id: number;
  city: string;
  state: string;
  sqft: number;          // Superficie en pies cuadrados (ej: 950 - 3800)
  bedrooms: number;      // Habitaciones (1 - 5)
  median_income_k: number; // Ingreso medio del área en miles de USD ($32k - $125k)
  house_age: number;     // Antigüedad en años (3 - 62)
  price_k: number;       // Precio real en miles de USD ($210k - $980k)
  label: 1 | -1;         // +1: Premium / Alto Valor, -1: Accesible / Estándar
  labelName: 'Premium / Alto Valor' | 'Estándar / Accesible';
  neighborhoodType: string;
}

export type KernelType = 'linear' | 'rbf' | 'polynomial';

export interface SVMHyperparameters {
  c: number;          // Parámetro de penalización C (0.01 - 100)
  kernel: KernelType;
  gamma: number;      // Para RBF (0.01 - 5)
  degree: number;     // Para Polinomial (2 o 3)
}

export interface SupportVectorInfo {
  index: number;
  record: HousingRecord;
  alpha: number;      // Multiplicador de Lagrange
  isMarginBound: boolean; // Si está exactamente en el margen (0 < alpha < C) o si viola el margen (alpha == C)
  slack: number;      // Holgura xi_i >= 0
  distanceToPlane: number;
}

export interface SVMSolution {
  w: number[];        // Pesos [w1, w2] o [w1, w2, w3] en espacio lineal
  b: number;          // Sesgo / intercepto
  marginWidth: number; // 2 / ||w||
  supportVectors: SupportVectorInfo[];
  accuracy: number;   // Porcentaje de acierto en el dataset
  numMarginViolations: number;
  totalLoss: number;
}

export interface FeatureMeta {
  key: HousingFeatureKey;
  name: string;
  unit: string;
  shortLabel: string;
  description: string;
  min: number;
  max: number;
  format: (val: number) => string;
}
