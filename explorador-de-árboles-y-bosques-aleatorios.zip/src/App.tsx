/**
 * ML Decision Lab: Laboratorio Didáctico de Árboles de Decisión,
 * Árboles de Regresión y Random Forest.
 */

import React, { useState, useMemo, useEffect } from 'react';
import { ModelType, ClassificationHyperparams, RegressionHyperparams, RandomForestHyperparams, PedagogicalChallenge, TreeNode } from './types';
import { DATASET_METAS, generateDataset } from './algorithms/datasets';
import { DecisionTreeClassifier } from './algorithms/decisionTree';
import { DecisionTreeRegressor } from './algorithms/regressionTree';
import { RandomForestModel } from './algorithms/randomForest';
import { Navbar } from './components/Navbar';
import { TreeGraph } from './components/TreeGraph';
import { Classification2DView } from './components/Classification2DView';
import { RegressionPlot } from './components/RegressionPlot';
import { HyperparameterControls } from './components/HyperparameterControls';
import { MetricsCard } from './components/MetricsCard';
import { ForestEnsembleView } from './components/ForestEnsembleView';
import { PedagogicalGuide } from './components/PedagogicalGuide';
import { ChallengePanel } from './components/ChallengePanel';
import { PEDAGOGICAL_CHALLENGES } from './algorithms/challenges';
import { GitFork, TrendingUp, Trees, RefreshCw, Volume2, Sparkles, Layers, SlidersHorizontal, CheckCircle2 } from 'lucide-react';

export default function App() {
  // Current active main module
  const [currentModule, setCurrentModule] = useState<ModelType>('classification_tree');

  // Modal / drawer panels
  const [showGuide, setShowGuide] = useState<boolean>(false);
  const [showChallenges, setShowChallenges] = useState<boolean>(false);
  const [activeChallengeId, setActiveChallengeId] = useState<string | null>(null);

  // Selected dataset id
  const [classificationDatasetId, setClassificationDatasetId] = useState<string>('credit');
  const [regressionDatasetId, setRegressionDatasetId] = useState<string>('real_estate');

  // Noise level slider (didactic tool)
  const [noiseLevel, setNoiseLevel] = useState<number>(0.18);
  const [datasetSeed, setDatasetSeed] = useState<number>(42);

  // View mode tab for the visual workspace: 'both' | 'boundary' | 'tree'
  const [workspaceTab, setWorkspaceTab] = useState<'both' | 'boundary' | 'tree'>('both');

  // Hyperparameters
  const [classParams, setClassParams] = useState<ClassificationHyperparams>({
    maxDepth: 4,
    minSamplesSplit: 2,
    minSamplesLeaf: 3,
    criterion: 'gini',
  });

  const [regParams, setRegParams] = useState<RegressionHyperparams>({
    maxDepth: 4,
    minSamplesSplit: 2,
    minSamplesLeaf: 4,
    criterion: 'mse',
  });

  const [forestParams, setForestParams] = useState<RandomForestHyperparams>({
    nEstimators: 12,
    maxDepth: 5,
    minSamplesLeaf: 2,
    bootstrapRatio: 0.8,
    maxFeatures: 'all',
  });

  // Interactive node inspection & active decision path
  const [selectedTreeNode, setSelectedTreeNode] = useState<TreeNode | null>(null);
  const [activeDecisionPath, setActiveDecisionPath] = useState<string[]>([]);

  // 1. Generate Dataset
  const activeDatasetMeta = useMemo(() => {
    if (currentModule === 'regression_tree') {
      return DATASET_METAS[regressionDatasetId] || DATASET_METAS['real_estate'];
    } else {
      return DATASET_METAS[classificationDatasetId] || DATASET_METAS['credit'];
    }
  }, [currentModule, regressionDatasetId, classificationDatasetId]);

  const rawData = useMemo(() => {
    const datasetId = currentModule === 'regression_tree' ? regressionDatasetId : classificationDatasetId;
    return generateDataset(datasetId, 190, noiseLevel, datasetSeed);
  }, [currentModule, regressionDatasetId, classificationDatasetId, noiseLevel, datasetSeed]);

  const trainData = useMemo(() => rawData.filter(d => d.split === 'train'), [rawData]);
  const testData = useMemo(() => rawData.filter(d => d.split === 'test'), [rawData]);

  // 2. Train Models
  // Classification Tree
  const trainedClassificationTree = useMemo(() => {
    if (currentModule !== 'classification_tree') return null;
    const clf = new DecisionTreeClassifier(
      classParams,
      [activeDatasetMeta.feature1Name, activeDatasetMeta.feature2Name]
    );
    clf.fit(trainData);
    return clf;
  }, [currentModule, classParams, trainData, activeDatasetMeta]);

  // Regression Tree
  const trainedRegressionTree = useMemo(() => {
    if (currentModule !== 'regression_tree') return null;
    const reg = new DecisionTreeRegressor(
      regParams,
      [activeDatasetMeta.feature1Name, activeDatasetMeta.feature2Name]
    );
    reg.fit(trainData);
    return reg;
  }, [currentModule, regParams, trainData, activeDatasetMeta]);

  // Random Forest
  const trainedForest = useMemo(() => {
    if (currentModule !== 'random_forest') return null;
    const rf = new RandomForestModel(
      forestParams,
      [activeDatasetMeta.feature1Name, activeDatasetMeta.feature2Name]
    );
    rf.fit(trainData, datasetSeed + 100);
    return rf;
  }, [currentModule, forestParams, trainData, activeDatasetMeta, datasetSeed]);

  // 3. Compute Metrics
  const classMetrics = useMemo(() => {
    if (!trainedClassificationTree) return undefined;
    return trainedClassificationTree.evaluate(trainData, testData);
  }, [trainedClassificationTree, trainData, testData]);

  const regMetrics = useMemo(() => {
    if (!trainedRegressionTree) return undefined;
    return trainedRegressionTree.evaluate(trainData, testData);
  }, [trainedRegressionTree, trainData, testData]);

  const forestMetrics = useMemo(() => {
    if (!trainedForest) return undefined;
    return trainedForest.evaluate(trainData, testData);
  }, [trainedForest, trainData, testData]);

  // 4. Preset handlers
  const handleApplyPreset = (preset: 'underfit' | 'optimal' | 'overfit') => {
    if (currentModule === 'classification_tree') {
      if (preset === 'underfit') {
        setClassParams({ maxDepth: 1, minSamplesSplit: 20, minSamplesLeaf: 15, criterion: 'gini' });
      } else if (preset === 'optimal') {
        setClassParams({ maxDepth: 4, minSamplesSplit: 4, minSamplesLeaf: 4, criterion: 'gini' });
      } else {
        setClassParams({ maxDepth: 10, minSamplesSplit: 2, minSamplesLeaf: 1, criterion: 'gini' });
      }
    } else if (currentModule === 'regression_tree') {
      if (preset === 'underfit') {
        setRegParams({ maxDepth: 1, minSamplesSplit: 20, minSamplesLeaf: 15, criterion: 'mse' });
      } else if (preset === 'optimal') {
        setRegParams({ maxDepth: 4, minSamplesSplit: 4, minSamplesLeaf: 5, criterion: 'mse' });
      } else {
        setRegParams({ maxDepth: 9, minSamplesSplit: 2, minSamplesLeaf: 1, criterion: 'mse' });
      }
    } else {
      // Random forest
      if (preset === 'underfit') {
        setForestParams({ nEstimators: 1, maxDepth: 1, minSamplesLeaf: 15, bootstrapRatio: 0.6, maxFeatures: 'all' });
      } else if (preset === 'optimal') {
        setForestParams({ nEstimators: 18, maxDepth: 6, minSamplesLeaf: 2, bootstrapRatio: 0.8, maxFeatures: 'all' });
      } else {
        setForestParams({ nEstimators: 2, maxDepth: 10, minSamplesLeaf: 1, bootstrapRatio: 1.0, maxFeatures: 'all' });
      }
    }
  };

  // 5. Challenge Handlers
  const handleSelectChallenge = (challenge: PedagogicalChallenge) => {
    setCurrentModule(challenge.module);
    setActiveChallengeId(challenge.id);
    if (challenge.module === 'classification_tree') {
      setClassParams(challenge.initialParams);
      setClassificationDatasetId('credit');
    } else if (challenge.module === 'regression_tree') {
      setRegParams(challenge.initialParams);
      setRegressionDatasetId('real_estate');
    } else {
      setForestParams(challenge.initialParams);
      setClassificationDatasetId('moons');
    }
    setShowChallenges(false);
  };

  // Check if current active challenge is won
  const currentMetrics = currentModule === 'classification_tree' ? classMetrics : (currentModule === 'regression_tree' ? regMetrics : forestMetrics);
  const activeChallenge = PEDAGOGICAL_CHALLENGES.find(c => c.id === activeChallengeId);
  const isChallengeCompleted = activeChallenge && currentMetrics && activeChallenge.checkCompletion(currentMetrics);

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col selection:bg-emerald-100 selection:text-emerald-900">
      {/* Top Navbar */}
      <Navbar
        currentModule={currentModule}
        onChangeModule={(mod) => {
          setCurrentModule(mod);
          setSelectedTreeNode(null);
          setActiveDecisionPath([]);
        }}
        showChallenges={showChallenges}
        onToggleChallenges={() => {
          setShowChallenges(prev => !prev);
          setShowGuide(false);
        }}
        showGuide={showGuide}
        onToggleGuide={() => {
          setShowGuide(prev => !prev);
          setShowChallenges(false);
        }}
      />

      {/* Main Body */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 flex flex-col gap-6">
        {/* Guides or Challenges Modals / Drawers if opened */}
        {showGuide && (
          <PedagogicalGuide onClose={() => setShowGuide(false)} />
        )}

        {showChallenges && (
          <ChallengePanel
            currentModule={currentModule}
            onSelectChallenge={handleSelectChallenge}
            activeChallengeId={activeChallengeId}
            currentMetrics={currentMetrics}
            onClose={() => setShowChallenges(false)}
          />
        )}

        {/* Active Challenge Banner if a challenge is in progress */}
        {activeChallenge && (
          <div className={`p-4 rounded-2xl border flex flex-wrap items-center justify-between gap-3 transition-all ${
            isChallengeCompleted
              ? 'bg-emerald-500 text-white border-emerald-600 shadow-md'
              : 'bg-amber-50 border-amber-300 text-amber-950'
          }`}>
            <div className="flex items-center gap-3">
              <span className="text-xl">{isChallengeCompleted ? '🏆' : '🎯'}</span>
              <div>
                <div className="flex items-center gap-2">
                  <span className="font-bold text-sm">{activeChallenge.title}</span>
                  {isChallengeCompleted && (
                    <span className="px-2 py-0.5 rounded-full bg-white text-emerald-700 text-xs font-bold uppercase tracking-wider">
                      ¡Objetivo Logrado!
                    </span>
                  )}
                </div>
                <p className={`text-xs ${isChallengeCompleted ? 'text-emerald-100' : 'text-slate-600'}`}>
                  {activeChallenge.targetCondition}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowChallenges(true)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                  isChallengeCompleted
                    ? 'bg-white text-emerald-800 hover:bg-emerald-50'
                    : 'bg-amber-600 text-white hover:bg-amber-700'
                }`}
              >
                Ver Retos
              </button>
              <button
                onClick={() => setActiveChallengeId(null)}
                className={`px-2.5 py-1.5 rounded-lg text-xs font-medium ${
                  isChallengeCompleted ? 'text-emerald-100 hover:text-white' : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                Salir del Reto
              </button>
            </div>
          </div>
        )}

        {/* Dataset & Noise Controls Bar */}
        <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs flex flex-wrap items-center justify-between gap-4">
          {/* Dataset Selector */}
          <div className="flex flex-wrap items-center gap-3">
            <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
              Caso Práctico:
            </span>
            <div className="flex flex-wrap items-center gap-2">
              {currentModule === 'regression_tree' ? (
                <>
                  <button
                    onClick={() => setRegressionDatasetId('real_estate')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                      regressionDatasetId === 'real_estate'
                        ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    🏡 Inmobiliaria (Precio Casas)
                  </button>
                  <button
                    onClick={() => setRegressionDatasetId('energy')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                      regressionDatasetId === 'energy'
                        ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    ⚡ Consumo Eléctrico
                  </button>
                </>
              ) : (
                <>
                  <button
                    onClick={() => setClassificationDatasetId('credit')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                      classificationDatasetId === 'credit'
                        ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    💳 Crédito Bancario
                  </button>
                  <button
                    onClick={() => setClassificationDatasetId('medical')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                      classificationDatasetId === 'medical'
                        ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    🩺 Diagnóstico Cardiovascular
                  </button>
                  <button
                    onClick={() => setClassificationDatasetId('moons')}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                      classificationDatasetId === 'moons'
                        ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    🌙 Patrón Lunas No-Lineal
                  </button>
                </>
              )}
            </div>
          </div>

          {/* Noise Slider & Regenerate */}
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-700 font-medium">Nivel de Ruido:</span>
              <input
                type="range"
                min={0.05}
                max={0.40}
                step={0.05}
                value={noiseLevel}
                onChange={(e) => setNoiseLevel(Number(e.target.value))}
                className="w-24 accent-slate-700 h-1.5 bg-slate-200 rounded-lg cursor-pointer"
                title="Aumentar el ruido permite ver cómo un árbol no podado memoriza anomalías"
              />
              <span className="text-xs font-mono text-slate-700 w-8">
                {(noiseLevel * 100).toFixed(0)}%
              </span>
            </div>

            <button
              onClick={() => setDatasetSeed(prev => prev + 1)}
              className="p-1.5 rounded-lg text-slate-700 hover:text-slate-900 hover:bg-slate-100 border border-slate-200 transition-colors"
              title="Regenerar datos aleatorios"
            >
              <RefreshCw className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Workspace Layout: Grid with Controls & Metrics on Left/Right, Visualizers in Main */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left Column: Hyperparameters and Metrics (5 cols on lg) */}
          <div className="lg:col-span-4 flex flex-col gap-6">
            <HyperparameterControls
              modelType={currentModule}
              classParams={classParams}
              regParams={regParams}
              forestParams={forestParams}
              onChangeClassParams={setClassParams}
              onChangeRegParams={setRegParams}
              onChangeForestParams={setForestParams}
              onApplyPreset={handleApplyPreset}
            />

            <MetricsCard
              modelType={currentModule}
              classMetrics={classMetrics}
              regMetrics={regMetrics}
              forestMetrics={forestMetrics}
            />
          </div>

          {/* Right Column: Interactive Visualizations (8 cols on lg) */}
          <div className="lg:col-span-8 flex flex-col gap-6">
            {/* Classification Module */}
            {currentModule === 'classification_tree' && trainedClassificationTree && (
              <>
                {/* Visualizer Tabs: Both | Boundary | Tree */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 p-1 bg-white rounded-xl border border-slate-200 shadow-2xs">
                    <button
                      onClick={() => setWorkspaceTab('both')}
                      className={`px-3 py-1 rounded-lg text-xs font-medium transition-all ${
                        workspaceTab === 'both' ? 'bg-slate-900 text-white font-semibold' : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      Ambas Vistas
                    </button>
                    <button
                      onClick={() => setWorkspaceTab('boundary')}
                      className={`px-3 py-1 rounded-lg text-xs font-medium transition-all ${
                        workspaceTab === 'boundary' ? 'bg-slate-900 text-white font-semibold' : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      Frontera 2D
                    </button>
                    <button
                      onClick={() => setWorkspaceTab('tree')}
                      className={`px-3 py-1 rounded-lg text-xs font-medium transition-all ${
                        workspaceTab === 'tree' ? 'bg-slate-900 text-white font-semibold' : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      Grafo del Árbol
                    </button>
                  </div>

                  <span className="text-xs text-slate-500 hidden sm:inline">
                    Pasa el cursor o haz click en el mapa para ver la ruta en el árbol
                  </span>
                </div>

                {/* Main Visualizers */}
                {(workspaceTab === 'both' || workspaceTab === 'boundary') && (
                  <Classification2DView
                    datasetMeta={activeDatasetMeta}
                    data={rawData}
                    predictFn={(x1, x2) => trainedClassificationTree.predictPoint(x1, x2)}
                    selectedNode={selectedTreeNode}
                    onHoverPoint={(info) => {
                      if (info?.path) {
                        setActiveDecisionPath(info.path);
                      } else {
                        setActiveDecisionPath([]);
                      }
                    }}
                    modelTitle={`Frontera Ortogonal de Decisión (${activeDatasetMeta.name})`}
                  />
                )}

                {(workspaceTab === 'both' || workspaceTab === 'tree') && (
                  <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs flex flex-col gap-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <GitFork className="w-4 h-4 text-emerald-600" />
                        <h3 className="font-bold text-slate-900 text-sm">
                          Estructura Jerárquica del Árbol de Decisión
                        </h3>
                      </div>
                      {selectedTreeNode && (
                        <button
                          onClick={() => setSelectedTreeNode(null)}
                          className="text-xs text-slate-500 hover:text-slate-800 underline"
                        >
                          Limpiar selección
                        </button>
                      )}
                    </div>

                    <TreeGraph
                      root={trainedClassificationTree.root}
                      selectedNodeId={selectedTreeNode?.id}
                      onSelectNode={setSelectedTreeNode}
                      activePath={activeDecisionPath}
                      type="classification"
                      classColors={{
                        0: activeDatasetMeta.targetClasses?.[0]?.color || '#ef4444',
                        1: activeDatasetMeta.targetClasses?.[1]?.color || '#10b981',
                      }}
                    />
                  </div>
                )}
              </>
            )}

            {/* Regression Module */}
            {currentModule === 'regression_tree' && trainedRegressionTree && (
              <>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 p-1 bg-white rounded-xl border border-slate-200 shadow-2xs">
                    <button
                      onClick={() => setWorkspaceTab('both')}
                      className={`px-3 py-1 rounded-lg text-xs font-medium transition-all ${
                        workspaceTab === 'both' ? 'bg-slate-900 text-white font-semibold' : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      Ambas Vistas
                    </button>
                    <button
                      onClick={() => setWorkspaceTab('boundary')}
                      className={`px-3 py-1 rounded-lg text-xs font-medium transition-all ${
                        workspaceTab === 'boundary' ? 'bg-slate-900 text-white font-semibold' : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      Curva Escalonada
                    </button>
                    <button
                      onClick={() => setWorkspaceTab('tree')}
                      className={`px-3 py-1 rounded-lg text-xs font-medium transition-all ${
                        workspaceTab === 'tree' ? 'bg-slate-900 text-white font-semibold' : 'text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      Grafo del Árbol
                    </button>
                  </div>
                </div>

                {(workspaceTab === 'both' || workspaceTab === 'boundary') && (
                  <RegressionPlot
                    datasetMeta={activeDatasetMeta}
                    data={rawData}
                    predictFn={(x1, x2) => trainedRegressionTree.predictPoint(x1, x2)}
                    root={trainedRegressionTree.root}
                    onHoverPoint={(info) => {
                      if (info?.path) {
                        setActiveDecisionPath(info.path);
                      } else {
                        setActiveDecisionPath([]);
                      }
                    }}
                  />
                )}

                {(workspaceTab === 'both' || workspaceTab === 'tree') && (
                  <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs flex flex-col gap-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <TrendingUp className="w-4 h-4 text-blue-600" />
                        <h3 className="font-bold text-slate-900 text-sm">
                          Grafo del Árbol de Regresión (Valores Medios y Partición de Varianza)
                        </h3>
                      </div>
                    </div>

                    <TreeGraph
                      root={trainedRegressionTree.root}
                      selectedNodeId={selectedTreeNode?.id}
                      onSelectNode={setSelectedTreeNode}
                      activePath={activeDecisionPath}
                      type="regression"
                    />
                  </div>
                )}
              </>
            )}

            {/* Random Forest Module */}
            {currentModule === 'random_forest' && trainedForest && (
              <>
                {/* Continuous probability gradient heatmap */}
                <Classification2DView
                  datasetMeta={activeDatasetMeta}
                  data={rawData}
                  predictFn={(x1, x2) => {
                    const { prob1 } = trainedForest.predictProb(x1, x2);
                    return {
                      predictedClass: prob1 >= 0.5 ? 1 : 0,
                      prob: prob1,
                    };
                  }}
                  modelTitle={`Frontera de Consenso Suave del Bosque (${forestParams.nEstimators} Árboles)`}
                  showProbabilityGradient={true}
                />

                {/* Individual Tree Inspection Gallery */}
                <ForestEnsembleView
                  forest={trainedForest}
                  trainData={trainData}
                  testData={testData}
                  datasetMeta={activeDatasetMeta}
                />
              </>
            )}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="mt-12 py-6 border-t border-slate-200 bg-white text-center text-xs text-slate-700">
        <div className="max-w-7xl mx-auto px-4 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-900">ML Decision Lab</span>
            <span>— Laboratorio Didáctico de Aprendizaje Automático</span>
          </div>
          <div className="flex items-center gap-4 text-slate-700">
            <span>Árbol de Decisión (CART)</span>
            <span>•</span>
            <span>Árbol de Regresión</span>
            <span>•</span>
            <span>Random Forest (Bagging)</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
