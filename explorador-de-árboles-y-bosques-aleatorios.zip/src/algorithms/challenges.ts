import { PedagogicalChallenge } from '../types';

export const PEDAGOGICAL_CHALLENGES: PedagogicalChallenge[] = [
  {
    id: 'dt-overfit-cure',
    title: 'Reto 1: Curar el Sobreajuste en Clasificación',
    module: 'classification_tree',
    description: 'El modelo actual tiene max_depth=9 y min_samples_leaf=1. Ha memorizado cada anomalía de entrenamiento, pero falla en datos nuevos (brecha de sobreajuste > 12%). Modifica los hiperparámetros para regularizarlo.',
    initialParams: {
      maxDepth: 9,
      minSamplesSplit: 2,
      minSamplesLeaf: 1,
      criterion: 'gini',
    },
    targetCondition: 'Logra Test Accuracy ≥ 83% con Brecha de Sobreajuste ≤ 6%',
    checkCompletion: (metrics: any) => {
      return metrics.testAccuracy >= 83 && metrics.overfittingGap <= 6;
    },
    hint: 'Prueba limitando max_depth entre 3 y 5, e incrementando min_samples_leaf a 4 o 6 para podar ramas espurias.',
    solutionExplanation: 'Al fijar max_depth=4 y min_samples_leaf=5, evitamos que el árbol cree rectángulos microscópicos alrededor de puntos atípicos, mejorando la generalización real.',
  },
  {
    id: 'reg-smoothing',
    title: 'Reto 2: Regularizar los Escalones de Regresión',
    module: 'regression_tree',
    description: 'El árbol de regresión tiene max_depth=8 y predice escalones diminutos para cada punto de ruido en el precio de casas. Regularízalo para obtener una estimación limpia de la tendencia.',
    initialParams: {
      maxDepth: 8,
      minSamplesSplit: 2,
      minSamplesLeaf: 1,
      criterion: 'mse',
    },
    targetCondition: 'Logra R² en Test ≥ 0.80 con Brecha de Sobreajuste (Test MSE - Train MSE) ≤ 350',
    checkCompletion: (metrics: any) => {
      return metrics.testR2 >= 0.80 && metrics.overfittingGap <= 350;
    },
    hint: 'Reduce max_depth a 3 o 4, o sube min_samples_leaf a 6 u 8 para que cada escalón promedie varias casas.',
    solutionExplanation: 'En regresión, un min_samples_leaf adecuado actúa como un filtro suavizador que descarta el ruido estocástico del mercado.',
  },
  {
    id: 'rf-variance-kill',
    title: 'Reto 3: La Sabiduría de la Multitud en Random Forest',
    module: 'random_forest',
    description: 'Configura un bosque de árboles para demostrar empíricamente cómo el ensamble supera a un árbol individual mediante votación colectiva y descorrelación.',
    initialParams: {
      nEstimators: 2,
      maxDepth: 6,
      minSamplesLeaf: 1,
      bootstrapRatio: 0.8,
      maxFeatures: 'all',
    },
    targetCondition: 'Alcanza Test Accuracy ≥ 88% con al menos 12 árboles y una Ganancia sobre árbol individual ≥ +2.0%',
    checkCompletion: (metrics: any) => {
      return metrics.totalTrees >= 12 && metrics.testAccuracy >= 88 && metrics.accuracyGain >= 2.0;
    },
    hint: 'Aumenta n_estimators a 15-20 y asegura que maxDepth esté en 4-6 para que cada árbol tenga suficiente capacidad pero difieran entre sí.',
    solutionExplanation: 'Gracias al muestreo con reemplazo (bootstrap), cada árbol comete errores en zonas distintas; el promedio de votos anula los errores individuales.',
  }
];
