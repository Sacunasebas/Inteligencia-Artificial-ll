import { DataPoint2D, RandomForestHyperparams, ForestMetrics, TreeNode } from '../types';
import { DecisionTreeClassifier } from './decisionTree';

export interface TreeInForest {
  index: number;
  classifier: DecisionTreeClassifier;
  oobIndices: number[];
  treeDepth: number;
  leafCount: number;
}

export class RandomForestModel {
  public trees: TreeInForest[] = [];
  public hyperparams: RandomForestHyperparams;
  private featureNames: [string, string];

  constructor(hyperparams: RandomForestHyperparams, featureNames: [string, string] = ['X₁', 'X₂']) {
    this.hyperparams = hyperparams;
    this.featureNames = featureNames;
  }

  public fit(trainData: DataPoint2D[], seed: number = 101): void {
    this.trees = [];
    const n = trainData.length;
    const sampleSize = Math.max(10, Math.floor(n * this.hyperparams.bootstrapRatio));

    // Simple pseudo random generator
    let s = seed % 2147483647;
    const rnd = () => {
      s = (s * 16807) % 2147483647;
      return (s - 1) / 2147483646;
    };

    for (let t = 0; t < this.hyperparams.nEstimators; t++) {
      // Bootstrap sampling with replacement
      const bootstrapIndices: number[] = [];
      const inBagSet = new Set<number>();

      for (let i = 0; i < sampleSize; i++) {
        const picked = Math.floor(rnd() * n);
        bootstrapIndices.push(picked);
        inBagSet.add(picked);
      }

      // Out of bag indices
      const oobIndices: number[] = [];
      for (let i = 0; i < n; i++) {
        if (!inBagSet.has(i)) {
          oobIndices.push(i);
        }
      }

      const bootstrapData = bootstrapIndices.map(idx => trainData[idx]);

      // Tree hyperparams
      const treeClf = new DecisionTreeClassifier({
        maxDepth: this.hyperparams.maxDepth,
        minSamplesSplit: 2,
        minSamplesLeaf: this.hyperparams.minSamplesLeaf,
        criterion: 'gini',
      }, this.featureNames);

      treeClf.fit(bootstrapData);

      // Measure depth and leaves
      let treeDepth = 0;
      let leafCount = 0;
      const countNodes = (n: TreeNode | null) => {
        if (!n) return;
        if (n.depth > treeDepth) treeDepth = n.depth;
        if (n.isLeaf) leafCount++;
        else {
          countNodes(n.leftChild || null);
          countNodes(n.rightChild || null);
        }
      };
      countNodes(treeClf.root);

      this.trees.push({
        index: t,
        classifier: treeClf,
        oobIndices,
        treeDepth,
        leafCount,
      });
    }
  }

  // Predict probability of class 1 for a single point
  public predictProb(x1: number, x2: number): { prob1: number; votes: { [cls: number]: number }; treePredictions: number[] } {
    if (this.trees.length === 0) return { prob1: 0.5, votes: { 0: 0, 1: 0 }, treePredictions: [] };

    let sumProb1 = 0;
    const votes: { [cls: number]: number } = { 0: 0, 1: 0 };
    const treePredictions: number[] = [];

    for (const tree of this.trees) {
      const pred = tree.classifier.predictPoint(x1, x2);
      const vote = pred.predictedClass;
      treePredictions.push(vote);
      votes[vote] = (votes[vote] || 0) + 1;
      sumProb1 += (vote === 1 ? pred.prob : (1 - pred.prob));
    }

    const prob1 = sumProb1 / this.trees.length;
    return { prob1, votes, treePredictions };
  }

  public predictPoint(x1: number, x2: number): number {
    const { votes } = this.predictProb(x1, x2);
    return (votes[1] || 0) >= (votes[0] || 0) ? 1 : 0;
  }

  public evaluate(trainData: DataPoint2D[], testData: DataPoint2D[]): ForestMetrics {
    // Forest accuracy on train
    let trainCorrect = 0;
    for (const pt of trainData) {
      if (this.predictPoint(pt.x1, pt.x2) === pt.y) trainCorrect++;
    }
    const trainAccuracy = trainData.length > 0 ? (trainCorrect / trainData.length) * 100 : 0;

    // Forest accuracy on test
    let testCorrect = 0;
    for (const pt of testData) {
      if (this.predictPoint(pt.x1, pt.x2) === pt.y) testCorrect++;
    }
    const testAccuracy = testData.length > 0 ? (testCorrect / testData.length) * 100 : 0;

    // Single tree baseline comparison (Tree 0)
    let singleTreeTestAccuracy = 0;
    if (this.trees.length > 0) {
      let singleCorrect = 0;
      for (const pt of testData) {
        if (this.trees[0].classifier.predictPoint(pt.x1, pt.x2).predictedClass === pt.y) singleCorrect++;
      }
      singleTreeTestAccuracy = testData.length > 0 ? (singleCorrect / testData.length) * 100 : 0;
    }

    // OOB evaluation
    let oobCorrect = 0;
    let oobEvaluated = 0;
    for (let i = 0; i < trainData.length; i++) {
      const pt = trainData[i];
      let oobVotes1 = 0;
      let oobVotesTotal = 0;

      for (const tree of this.trees) {
        if (tree.oobIndices.includes(i)) {
          const vote = tree.classifier.predictPoint(pt.x1, pt.x2).predictedClass;
          if (vote === 1) oobVotes1++;
          oobVotesTotal++;
        }
      }

      if (oobVotesTotal > 0) {
        oobEvaluated++;
        const oobPred = oobVotes1 >= (oobVotesTotal / 2) ? 1 : 0;
        if (oobPred === pt.y) oobCorrect++;
      }
    }
    const oobScore = oobEvaluated > 0 ? (oobCorrect / oobEvaluated) * 100 : 0;

    const totalTrees = this.trees.length;
    const avgDepth = totalTrees > 0 
      ? Math.round((this.trees.reduce((acc, t) => acc + t.treeDepth, 0) / totalTrees) * 10) / 10 
      : 0;

    const accuracyGain = Math.round((testAccuracy - singleTreeTestAccuracy) * 10) / 10;

    // Diagnosis
    let status: 'low_trees' | 'high_trees_optimal' | 'overfitted_individual' = 'high_trees_optimal';
    let title = 'Ensamble Robusto y Estable';
    let message = `El bosque de ${totalTrees} árboles promedia las decisiones individuales, reduciendo la varianza y alcanzando un ${testAccuracy.toFixed(1)}% de precisión en test.`;

    if (totalTrees <= 3) {
      status = 'low_trees';
      title = 'Pocos Árboles (Baja Diversidad)';
      message = 'Con tan pocos estimadores, el bosque todavía sufre la inestabilidad de los árboles individuales. El efecto de la ley de grandes números es limitado.';
    } else if (accuracyGain > 3) {
      status = 'high_trees_optimal';
      title = 'Superación Notoria sobre Árbol Solitario';
      message = `El ensamble supera al mejor árbol individual en +${accuracyGain}% de precisión en test gracias a la descorrelación de errores.`;
    }

    return {
      trainAccuracy: Math.round(trainAccuracy * 10) / 10,
      testAccuracy: Math.round(testAccuracy * 10) / 10,
      singleTreeTestAccuracy: Math.round(singleTreeTestAccuracy * 10) / 10,
      accuracyGain,
      oobScore: Math.round(oobScore * 10) / 10,
      totalTrees,
      avgDepth,
      diagnosis: { status, title, message },
    };
  }
}
