import { DataPoint2D, ClassificationHyperparams, ClassificationMetrics, TreeNode } from '../types';

export class DecisionTreeClassifier {
  public root: TreeNode | null = null;
  public hyperparams: ClassificationHyperparams;
  private featureNames: [string, string];

  constructor(hyperparams: ClassificationHyperparams, featureNames: [string, string] = ['X₁', 'X₂']) {
    this.hyperparams = hyperparams;
    this.featureNames = featureNames;
  }

  // Calculate Gini impurity
  private calculateGini(classCounts: { [cls: number]: number }, total: number): number {
    if (total === 0) return 0;
    let sumSq = 0;
    for (const cls in classCounts) {
      const p = classCounts[cls] / total;
      sumSq += p * p;
    }
    return 1 - sumSq;
  }

  // Calculate Entropy
  private calculateEntropy(classCounts: { [cls: number]: number }, total: number): number {
    if (total === 0) return 0;
    let entropy = 0;
    for (const cls in classCounts) {
      const p = classCounts[cls] / total;
      if (p > 0) {
        entropy -= p * Math.log2(p);
      }
    }
    return entropy;
  }

  private calculateImpurity(classCounts: { [cls: number]: number }, total: number): number {
    return this.hyperparams.criterion === 'entropy'
      ? this.calculateEntropy(classCounts, total)
      : this.calculateGini(classCounts, total);
  }

  private getClassCounts(data: DataPoint2D[], indices: number[]): { [cls: number]: number } {
    const counts: { [cls: number]: number } = { 0: 0, 1: 0 };
    for (const idx of indices) {
      const pt = data[idx];
      counts[pt.y] = (counts[pt.y] || 0) + 1;
    }
    return counts;
  }

  public fit(trainData: DataPoint2D[]): TreeNode {
    const indices = trainData.map((_, i) => i);
    let nodeIdCounter = 0;

    const buildNode = (currIndices: number[], depth: number): TreeNode => {
      const totalSamples = currIndices.length;
      const classCounts = this.getClassCounts(trainData, currIndices);
      const impurity = this.calculateImpurity(classCounts, totalSamples);

      // Determine majority class
      const predictedClass = (classCounts[1] || 0) >= (classCounts[0] || 0) ? 1 : 0;
      const classProbabilities = {
        0: totalSamples > 0 ? (classCounts[0] || 0) / totalSamples : 0,
        1: totalSamples > 0 ? (classCounts[1] || 0) / totalSamples : 0,
      };

      const isPure = (classCounts[0] === 0 || classCounts[1] === 0);
      const maxDepthReached = depth >= this.hyperparams.maxDepth;
      const notEnoughSamplesToSplit = totalSamples < this.hyperparams.minSamplesSplit;

      if (isPure || maxDepthReached || notEnoughSamplesToSplit) {
        return {
          id: `node-${nodeIdCounter++}`,
          isLeaf: true,
          depth,
          samples: totalSamples,
          trainIndices: currIndices,
          classCounts,
          impurity: Math.round(impurity * 1000) / 1000,
          predictedClass,
          classProbabilities,
        };
      }

      // Greedy search for best split
      let bestGain = -Infinity;
      let bestFeature: 0 | 1 = 0;
      let bestThreshold = 0;
      let bestLeftIndices: number[] = [];
      let bestRightIndices: number[] = [];

      const features: (0 | 1)[] = [0, 1];

      for (const feature of features) {
        // Collect and sort unique values along this feature
        const values = currIndices.map(idx => feature === 0 ? trainData[idx].x1 : trainData[idx].x2);
        const uniqueSortedValues = Array.from(new Set(values)).sort((a, b) => a - b);

        if (uniqueSortedValues.length < 2) continue;

        // Evaluate midpoints
        for (let i = 0; i < uniqueSortedValues.length - 1; i++) {
          const threshold = (uniqueSortedValues[i] + uniqueSortedValues[i + 1]) / 2;

          const left: number[] = [];
          const right: number[] = [];

          for (const idx of currIndices) {
            const val = feature === 0 ? trainData[idx].x1 : trainData[idx].x2;
            if (val <= threshold) {
              left.push(idx);
            } else {
              right.push(idx);
            }
          }

          // Enforce min_samples_leaf constraint
          if (left.length < this.hyperparams.minSamplesLeaf || right.length < this.hyperparams.minSamplesLeaf) {
            continue;
          }

          const leftCounts = this.getClassCounts(trainData, left);
          const rightCounts = this.getClassCounts(trainData, right);
          const leftImpurity = this.calculateImpurity(leftCounts, left.length);
          const rightImpurity = this.calculateImpurity(rightCounts, right.length);

          const weightedChildImpurity = (left.length / totalSamples) * leftImpurity + (right.length / totalSamples) * rightImpurity;
          const gain = impurity - weightedChildImpurity;

          if (gain > bestGain) {
            bestGain = gain;
            bestFeature = feature;
            bestThreshold = threshold;
            bestLeftIndices = left;
            bestRightIndices = right;
          }
        }
      }

      // If no valid split satisfied constraints or gave positive gain
      if (bestGain <= 0 || bestLeftIndices.length === 0 || bestRightIndices.length === 0) {
        return {
          id: `node-${nodeIdCounter++}`,
          isLeaf: true,
          depth,
          samples: totalSamples,
          trainIndices: currIndices,
          classCounts,
          impurity: Math.round(impurity * 1000) / 1000,
          predictedClass,
          classProbabilities,
        };
      }

      // Build internal node and recurse
      const node: TreeNode = {
        id: `node-${nodeIdCounter++}`,
        isLeaf: false,
        depth,
        samples: totalSamples,
        trainIndices: currIndices,
        classCounts,
        impurity: Math.round(impurity * 1000) / 1000,
        predictedClass,
        classProbabilities,
        featureIndex: bestFeature,
        featureName: this.featureNames[bestFeature],
        threshold: Math.round(bestThreshold * 100) / 100,
      };

      node.leftChild = buildNode(bestLeftIndices, depth + 1);
      node.rightChild = buildNode(bestRightIndices, depth + 1);

      return node;
    };

    this.root = buildNode(indices, 0);
    this.calculateTreeLayout(this.root);
    return this.root;
  }

  public predictPoint(x1: number, x2: number, node: TreeNode | null = this.root): { predictedClass: number; prob: number; path: string[] } {
    const path: string[] = [];
    let curr = node;

    while (curr) {
      path.push(curr.id);
      if (curr.isLeaf || curr.featureIndex === undefined || curr.threshold === undefined) {
        return {
          predictedClass: curr.predictedClass ?? 0,
          prob: curr.classProbabilities ? curr.classProbabilities[curr.predictedClass ?? 0] : 1,
          path,
        };
      }

      const val = curr.featureIndex === 0 ? x1 : x2;
      if (val <= curr.threshold) {
        curr = curr.leftChild || null;
      } else {
        curr = curr.rightChild || null;
      }
    }

    return { predictedClass: 0, prob: 0.5, path };
  }

  public evaluate(trainData: DataPoint2D[], testData: DataPoint2D[]): ClassificationMetrics {
    let trainCorrect = 0;
    for (const pt of trainData) {
      const pred = this.predictPoint(pt.x1, pt.x2).predictedClass;
      if (pred === pt.y) trainCorrect++;
    }
    const trainAccuracy = trainData.length > 0 ? (trainCorrect / trainData.length) * 100 : 0;

    let testCorrect = 0;
    let tp = 0, fp = 0, fn = 0, tn = 0;

    for (const pt of testData) {
      const pred = this.predictPoint(pt.x1, pt.x2).predictedClass;
      if (pred === pt.y) testCorrect++;

      if (pred === 1 && pt.y === 1) tp++;
      else if (pred === 1 && pt.y === 0) fp++;
      else if (pred === 0 && pt.y === 1) fn++;
      else if (pred === 0 && pt.y === 0) tn++;
    }
    const testAccuracy = testData.length > 0 ? (testCorrect / testData.length) * 100 : 0;
    const overfittingGap = Math.max(0, trainAccuracy - testAccuracy);

    // Tree stats
    let maxDepth = 0;
    let leafCount = 0;
    let totalNodes = 0;

    const traverse = (n: TreeNode | null) => {
      if (!n) return;
      totalNodes++;
      if (n.depth > maxDepth) maxDepth = n.depth;
      if (n.isLeaf) {
        leafCount++;
      } else {
        traverse(n.leftChild || null);
        traverse(n.rightChild || null);
      }
    };
    traverse(this.root);

    // Didactic diagnosis
    let status: 'underfitting' | 'optimal' | 'mild_overfit' | 'severe_overfit' = 'optimal';
    let title = 'Modelo Equilibrado';
    let message = 'Buen balance entre ajuste y capacidad de generalización en datos nuevos.';
    let advice = 'El árbol captura las reglas principales sin memorizar el ruido de entrenamiento.';

    if (trainAccuracy < 72 && testAccuracy < 70) {
      status = 'underfitting';
      title = 'Subajuste (Underfitting / Alto Sesgo)';
      message = 'El árbol es demasiado simple (poca profundidad o restricciones muy severas) y no logra capturar la estructura real.';
      advice = 'Aumenta `max_depth` o disminuye `min_samples_leaf` para permitir divisiones significativas.';
    } else if (overfittingGap > 15 || (trainAccuracy > 96 && testAccuracy < 80)) {
      status = 'severe_overfit';
      title = 'Sobreajuste Severo (Overfitting / Alta Varianza)';
      message = `El árbol memorizó datos de entrenamiento (${trainAccuracy.toFixed(1)}%), pero su rendimiento cae en prueba (${testAccuracy.toFixed(1)}%).`;
      advice = 'Disminuye `max_depth`, incrementa `min_samples_leaf` a ≥ 5 o `min_samples_split` para podar ramas espurias.';
    } else if (overfittingGap > 7) {
      status = 'mild_overfit';
      title = 'Ligero Sobreajuste (Mild Overfitting)';
      message = 'Existe una pequeña brecha entre entrenamiento y prueba. Hay ramas que aíslan muestras ruidosas.';
      advice = 'Prueba subiendo ligeramente `min_samples_leaf` (ej. a 3 o 4) para suavizar las fronteras de decisión.';
    }

    return {
      trainAccuracy: Math.round(trainAccuracy * 10) / 10,
      testAccuracy: Math.round(testAccuracy * 10) / 10,
      overfittingGap: Math.round(overfittingGap * 10) / 10,
      confusionMatrix: { tp, fp, fn, tn },
      treeDepth: maxDepth,
      leafCount,
      totalNodes,
      diagnosis: { status, title, message, advice },
    };
  }

  // Layout assignment for SVG rendering
  private calculateTreeLayout(root: TreeNode | null) {
    if (!root) return;

    let leafIndex = 0;
    const assignX = (node: TreeNode) => {
      if (node.isLeaf || (!node.leftChild && !node.rightChild)) {
        node.x = leafIndex * 120 + 60;
        leafIndex++;
      } else {
        if (node.leftChild) assignX(node.leftChild);
        if (node.rightChild) assignX(node.rightChild);
        const leftX = node.leftChild?.x ?? 0;
        const rightX = node.rightChild?.x ?? leftX;
        node.x = (leftX + rightX) / 2;
      }
      node.y = node.depth * 95 + 40;
    };

    assignX(root);
  }
}
