import { DataPoint2D, RegressionHyperparams, RegressionMetrics, TreeNode } from '../types';

export class DecisionTreeRegressor {
  public root: TreeNode | null = null;
  public hyperparams: RegressionHyperparams;
  private featureNames: [string, string];

  constructor(hyperparams: RegressionHyperparams, featureNames: [string, string] = ['Superficie (m²)', 'Antigüedad (años)']) {
    this.hyperparams = hyperparams;
    this.featureNames = featureNames;
  }

  private calculateMse(data: DataPoint2D[], indices: number[]): { mse: number; mean: number } {
    const n = indices.length;
    if (n === 0) return { mse: 0, mean: 0 };
    let sum = 0;
    for (const idx of indices) {
      sum += data[idx].y;
    }
    const mean = sum / n;
    let sumSqDiff = 0;
    for (const idx of indices) {
      const diff = data[idx].y - mean;
      sumSqDiff += diff * diff;
    }
    return { mse: sumSqDiff / n, mean };
  }

  private calculateMae(data: DataPoint2D[], indices: number[]): { mse: number; mean: number } {
    const n = indices.length;
    if (n === 0) return { mse: 0, mean: 0 };
    // Median for MAE
    const sortedY = indices.map(idx => data[idx].y).sort((a, b) => a - b);
    const median = sortedY[Math.floor(n / 2)];
    let sumAbs = 0;
    for (const idx of indices) {
      sumAbs += Math.abs(data[idx].y - median);
    }
    return { mse: sumAbs / n, mean: median };
  }

  private getImpurityAndPred(data: DataPoint2D[], indices: number[]): { impurity: number; prediction: number } {
    if (this.hyperparams.criterion === 'mae') {
      const { mse, mean } = this.calculateMae(data, indices);
      return { impurity: mse, prediction: mean };
    } else {
      const { mse, mean } = this.calculateMse(data, indices);
      return { impurity: mse, prediction: mean };
    }
  }

  public fit(trainData: DataPoint2D[]): TreeNode {
    const indices = trainData.map((_, i) => i);
    let nodeIdCounter = 0;

    const buildNode = (currIndices: number[], depth: number): TreeNode => {
      const totalSamples = currIndices.length;
      const { impurity, prediction } = this.getImpurityAndPred(trainData, currIndices);

      const maxDepthReached = depth >= this.hyperparams.maxDepth;
      const notEnoughSamplesToSplit = totalSamples < this.hyperparams.minSamplesSplit;
      const zeroVariance = impurity <= 1e-4;

      if (zeroVariance || maxDepthReached || notEnoughSamplesToSplit) {
        return {
          id: `reg-node-${nodeIdCounter++}`,
          isLeaf: true,
          depth,
          samples: totalSamples,
          trainIndices: currIndices,
          predictedValue: Math.round(prediction * 10) / 10,
          mse: Math.round(impurity * 10) / 10,
        };
      }

      // Search best split
      let bestVarianceReduction = -Infinity;
      let bestFeature: 0 | 1 = 0;
      let bestThreshold = 0;
      let bestLeftIndices: number[] = [];
      let bestRightIndices: number[] = [];

      const features: (0 | 1)[] = [0, 1];

      for (const feature of features) {
        const values = currIndices.map(idx => feature === 0 ? trainData[idx].x1 : trainData[idx].x2);
        const uniqueSortedValues = Array.from(new Set(values)).sort((a, b) => a - b);

        if (uniqueSortedValues.length < 2) continue;

        for (let i = 0; i < uniqueSortedValues.length - 1; i++) {
          const threshold = (uniqueSortedValues[i] + uniqueSortedValues[i + 1]) / 2;

          const left: number[] = [];
          const right: number[] = [];

          for (const idx of currIndices) {
            const val = feature === 0 ? trainData[idx].x1 : trainData[idx].x2;
            if (val <= threshold) {
              left.push(idx);
            } else {
              right.push(idx);
            }
          }

          if (left.length < this.hyperparams.minSamplesLeaf || right.length < this.hyperparams.minSamplesLeaf) {
            continue;
          }

          const leftStats = this.getImpurityAndPred(trainData, left);
          const rightStats = this.getImpurityAndPred(trainData, right);

          const weightedChildImpurity = (left.length / totalSamples) * leftStats.impurity + (right.length / totalSamples) * rightStats.impurity;
          const varianceReduction = impurity - weightedChildImpurity;

          if (varianceReduction > bestVarianceReduction) {
            bestVarianceReduction = varianceReduction;
            bestFeature = feature;
            bestThreshold = threshold;
            bestLeftIndices = left;
            bestRightIndices = right;
          }
        }
      }

      if (bestVarianceReduction <= 1e-4 || bestLeftIndices.length === 0 || bestRightIndices.length === 0) {
        return {
          id: `reg-node-${nodeIdCounter++}`,
          isLeaf: true,
          depth,
          samples: totalSamples,
          trainIndices: currIndices,
          predictedValue: Math.round(prediction * 10) / 10,
          mse: Math.round(impurity * 10) / 10,
        };
      }

      const node: TreeNode = {
        id: `reg-node-${nodeIdCounter++}`,
        isLeaf: false,
        depth,
        samples: totalSamples,
        trainIndices: currIndices,
        predictedValue: Math.round(prediction * 10) / 10,
        mse: Math.round(impurity * 10) / 10,
        featureIndex: bestFeature,
        featureName: this.featureNames[bestFeature],
        threshold: Math.round(bestThreshold * 10) / 10,
      };

      node.leftChild = buildNode(bestLeftIndices, depth + 1);
      node.rightChild = buildNode(bestRightIndices, depth + 1);

      return node;
    };

    this.root = buildNode(indices, 0);
    this.calculateTreeLayout(this.root);
    return this.root;
  }

  public predictPoint(x1: number, x2: number, node: TreeNode | null = this.root): { predictedValue: number; path: string[] } {
    const path: string[] = [];
    let curr = node;

    while (curr) {
      path.push(curr.id);
      if (curr.isLeaf || curr.featureIndex === undefined || curr.threshold === undefined) {
        return {
          predictedValue: curr.predictedValue ?? 0,
          path,
        };
      }

      const val = curr.featureIndex === 0 ? x1 : x2;
      if (val <= curr.threshold) {
        curr = curr.leftChild || null;
      } else {
        curr = curr.rightChild || null;
      }
    }

    return { predictedValue: 0, path };
  }

  public evaluate(trainData: DataPoint2D[], testData: DataPoint2D[]): RegressionMetrics {
    // Train stats
    let trainSumSq = 0;
    let trainYSum = 0;
    for (const pt of trainData) {
      const pred = this.predictPoint(pt.x1, pt.x2).predictedValue;
      const diff = pt.y - pred;
      trainSumSq += diff * diff;
      trainYSum += pt.y;
    }
    const trainMse = trainData.length > 0 ? trainSumSq / trainData.length : 0;
    const trainRmse = Math.sqrt(trainMse);

    const trainYMean = trainData.length > 0 ? trainYSum / trainData.length : 0;
    let trainTotSq = 0;
    for (const pt of trainData) {
      const diff = pt.y - trainYMean;
      trainTotSq += diff * diff;
    }
    const trainR2 = trainTotSq > 0 ? 1 - (trainSumSq / trainTotSq) : 0;

    // Test stats
    let testSumSq = 0;
    let testYSum = 0;
    for (const pt of testData) {
      const pred = this.predictPoint(pt.x1, pt.x2).predictedValue;
      const diff = pt.y - pred;
      testSumSq += diff * diff;
      testYSum += pt.y;
    }
    const testMse = testData.length > 0 ? testSumSq / testData.length : 0;
    const testRmse = Math.sqrt(testMse);

    const testYMean = testData.length > 0 ? testYSum / testData.length : 0;
    let testTotSq = 0;
    for (const pt of testData) {
      const diff = pt.y - testYMean;
      testTotSq += diff * diff;
    }
    const testR2 = testTotSq > 0 ? 1 - (testSumSq / testTotSq) : 0;

    const overfittingGap = Math.max(0, testMse - trainMse);

    let maxDepth = 0;
    let leafCount = 0;
    const traverse = (n: TreeNode | null) => {
      if (!n) return;
      if (n.depth > maxDepth) maxDepth = n.depth;
      if (n.isLeaf) {
        leafCount++;
      } else {
        traverse(n.leftChild || null);
        traverse(n.rightChild || null);
      }
    };
    traverse(this.root);

    // Diagnosis
    let status: 'underfitting' | 'optimal' | 'mild_overfit' | 'severe_overfit' = 'optimal';
    let title = 'Regresión Equilibrada';
    let message = 'El árbol modela la tendencia real sin memorizar los puntos ruidosos ni los valores atípicos.';
    let advice = 'Los escalones de predicción son coherentes y tienen suficiente soporte estadístico.';

    if (trainR2 < 0.65 && testR2 < 0.60) {
      status = 'underfitting';
      title = 'Subajuste (Bajo R² / Pocos Escalones)';
      message = 'El árbol realiza muy pocos cortes y no logra aproximar la curva o superficie de regresión.';
      advice = 'Incrementa `max_depth` a 3-5 para permitir que el árbol descubra subdivisiones no lineales.';
    } else if (trainR2 - testR2 > 0.20 || (trainR2 > 0.95 && testR2 < 0.75)) {
      status = 'severe_overfit';
      title = 'Sobreajuste Severo (Memorización de Ruido)';
      message = `R² en Train es muy alto (${(trainR2 * 100).toFixed(1)}%), pero el error MSE se dispara en Test. El árbol creó escalones individuales para cada punto ruidoso.`;
      advice = 'Aumenta `min_samples_leaf` a 5-8 para forzar que cada escalón promedie varias muestras, o reduce `max_depth`.';
    } else if (trainR2 - testR2 > 0.08) {
      status = 'mild_overfit';
      title = 'Ligera Discrepancia';
      message = 'Hay cierta sensibilidad a datos atípicos o escalones estrechos.';
      advice = 'Ajusta `min_samples_split` o aumenta `min_samples_leaf` ligeramente para regularizar la curva.';
    }

    return {
      trainMse: Math.round(trainMse * 10) / 10,
      testMse: Math.round(testMse * 10) / 10,
      trainR2: Math.round(trainR2 * 100) / 100,
      testR2: Math.round(testR2 * 100) / 100,
      trainRmse: Math.round(trainRmse * 10) / 10,
      testRmse: Math.round(testRmse * 10) / 10,
      overfittingGap: Math.round(overfittingGap * 10) / 10,
      treeDepth: maxDepth,
      leafCount,
      diagnosis: { status, title, message, advice },
    };
  }

  private calculateTreeLayout(root: TreeNode | null) {
    if (!root) return;
    let leafIndex = 0;
    const assignX = (node: TreeNode) => {
      if (node.isLeaf || (!node.leftChild && !node.rightChild)) {
        node.x = leafIndex * 120 + 60;
        leafIndex++;
      } else {
        if (node.leftChild) assignX(node.leftChild);
        if (node.rightChild) assignX(node.rightChild);
        const leftX = node.leftChild?.x ?? 0;
        const rightX = node.rightChild?.x ?? leftX;
        node.x = (leftX + rightX) / 2;
      }
      node.y = node.depth * 95 + 40;
    };
    assignX(root);
  }
}
