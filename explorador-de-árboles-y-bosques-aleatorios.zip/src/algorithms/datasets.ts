import { DataPoint2D, DatasetMeta } from '../types';

// Pseudo-random deterministic generator with seed
function pseudoRandom(seed: number) {
  let s = seed % 2147483647;
  if (s <= 0) s += 2147483646;
  return function() {
    s = (s * 16807) % 2147483647;
    return (s - 1) / 2147483646;
  };
}

export const DATASET_METAS: { [id: string]: DatasetMeta } = {
  credit: {
    id: 'credit',
    name: 'Aprobación de Crédito Bancario',
    category: 'classification',
    description: 'Predice si un solicitante debe recibir un préstamo según su ingreso y su puntaje de solvencia.',
    feature1Name: 'Ingreso Mensual',
    feature1Unit: 'k$',
    feature1Range: [1, 12],
    feature2Name: 'Score Crediticio',
    feature2Unit: 'pts',
    feature2Range: [350, 850],
    targetName: 'Aprobación de Crédito',
    targetClasses: {
      0: { label: 'Rechazado', color: '#ef4444', badge: 'bg-rose-100 text-rose-800 border-rose-200' },
      1: { label: 'Aprobado', color: '#10b981', badge: 'bg-emerald-100 text-emerald-800 border-emerald-200' },
    },
  },
  medical: {
    id: 'medical',
    name: 'Diagnóstico de Riesgo Cardiovascular',
    category: 'classification',
    description: 'Identifica pacientes con riesgo elevado en función de su colesterol y presión arterial sistólica.',
    feature1Name: 'Colesterol Total',
    feature1Unit: 'mg/dL',
    feature1Range: [130, 320],
    feature2Name: 'Presión Sistólica',
    feature2Unit: 'mmHg',
    feature2Range: [95, 185],
    targetName: 'Nivel de Riesgo',
    targetClasses: {
      0: { label: 'Riesgo Normal', color: '#3b82f6', badge: 'bg-blue-100 text-blue-800 border-blue-200' },
      1: { label: 'Alto Riesgo', color: '#f97316', badge: 'bg-amber-100 text-amber-800 border-amber-200' },
    },
  },
  moons: {
    id: 'moons',
    name: 'Patrón No-Lineal (Lunas con Ruido)',
    category: 'classification',
    description: 'Dos clases entrelazadas no separables linealmente. Demuestra la partición ortogonal del plano.',
    feature1Name: 'Coordenada X₁',
    feature1Unit: 'u',
    feature1Range: [-2.5, 3.5],
    feature2Name: 'Coordenada X₂',
    feature2Unit: 'u',
    feature2Range: [-2.0, 2.5],
    targetName: 'Clase Asignada',
    targetClasses: {
      0: { label: 'Clase Alfa (Azul)', color: '#6366f1', badge: 'bg-indigo-100 text-indigo-800 border-indigo-200' },
      1: { label: 'Clase Beta (Naranja)', color: '#f59e0b', badge: 'bg-amber-100 text-amber-800 border-amber-200' },
    },
  },
  real_estate: {
    id: 'real_estate',
    name: 'Valoración Inmobiliaria (Precio de Viviendas)',
    category: 'regression',
    description: 'Estima el precio de mercado de una propiedad en miles de euros según su superficie y antigüedad.',
    feature1Name: 'Superficie Construida',
    feature1Unit: 'm²',
    feature1Range: [40, 240],
    feature2Name: 'Antigüedad',
    feature2Unit: 'años',
    feature2Range: [0, 45],
    targetName: 'Precio de Mercado',
    targetUnit: 'k€',
  },
  energy: {
    id: 'energy',
    name: 'Consumo Eléctrico de Climatización',
    category: 'regression',
    description: 'Modela la demanda energética según la temperatura exterior y la tasa de ocupación del edificio.',
    feature1Name: 'Temperatura Exterior',
    feature1Unit: '°C',
    feature1Range: [-5, 38],
    feature2Name: 'Ocupación',
    feature2Unit: '%',
    feature2Range: [10, 100],
    targetName: 'Demanda Eléctrica',
    targetUnit: 'kW/h',
  }
};

export function generateDataset(datasetId: string, totalPoints: number = 180, noiseLevel: number = 0.15, seed: number = 42): DataPoint2D[] {
  const rng = pseudoRandom(seed);
  const points: DataPoint2D[] = [];

  const trainFraction = 0.70;

  if (datasetId === 'credit') {
    // x1: income (1 to 12 k$), x2: credit score (350 to 850)
    for (let i = 0; i < totalPoints; i++) {
      const income = 1 + rng() * 11;
      const score = 350 + rng() * 500;
      
      // True boundary: high score or high income
      // Base score function
      const latent = (income - 2.5) * 45 + (score - 520) * 1.0;
      const noise = (rng() - 0.5) * 150 * noiseLevel;
      const isApproved = (latent + noise) > 120 ? 1 : 0;

      const split = rng() < trainFraction ? 'train' : 'test';
      points.push({
        id: i,
        x1: Math.round(income * 10) / 10,
        x2: Math.round(score),
        y: isApproved,
        split,
      });
    }
  } else if (datasetId === 'medical') {
    // x1: Colesterol [130 to 320], x2: Presión Sistólica [95 to 185]
    for (let i = 0; i < totalPoints; i++) {
      const col = 130 + rng() * 190;
      const pres = 95 + rng() * 90;
      
      // Risk condition: either both elevated, or one very high
      const riskScore = ((col - 200) / 40) + ((pres - 130) / 20) + (rng() - 0.5) * 2.5 * noiseLevel;
      const isHighRisk = riskScore > 0.4 ? 1 : 0;

      const split = rng() < trainFraction ? 'train' : 'test';
      points.push({
        id: i,
        x1: Math.round(col),
        x2: Math.round(pres),
        y: isHighRisk,
        split,
      });
    }
  } else if (datasetId === 'moons') {
    // Non-linear interleaving moons
    const nPerMoon = Math.floor(totalPoints / 2);
    for (let i = 0; i < nPerMoon; i++) {
      // Moon 0: upper semicircle
      const theta = rng() * Math.PI;
      const x1 = Math.cos(theta) + (rng() - 0.5) * noiseLevel * 1.5;
      const x2 = Math.sin(theta) + (rng() - 0.5) * noiseLevel * 1.5;
      const split = rng() < trainFraction ? 'train' : 'test';
      points.push({
        id: i,
        x1: Math.round(x1 * 100) / 100,
        x2: Math.round(x2 * 100) / 100,
        y: 0,
        split,
      });
    }
    for (let i = 0; i < nPerMoon; i++) {
      // Moon 1: lower inverted semicircle shifted
      const theta = rng() * Math.PI;
      const x1 = 1 - Math.cos(theta) + (rng() - 0.5) * noiseLevel * 1.5;
      const x2 = 1 - Math.sin(theta) - 0.5 + (rng() - 0.5) * noiseLevel * 1.5;
      const split = rng() < trainFraction ? 'train' : 'test';
      points.push({
        id: nPerMoon + i,
        x1: Math.round(x1 * 100) / 100,
        x2: Math.round(x2 * 100) / 100,
        y: 1,
        split,
      });
    }
  } else if (datasetId === 'real_estate') {
    // Regression: x1 = sqm [40 to 240], x2 = age [0 to 45]
    for (let i = 0; i < totalPoints; i++) {
      const sqm = 40 + rng() * 200;
      const age = rng() * 45;
      
      // Base non-linear pricing + penalty for age + location cluster effect
      const baseM2Rate = 2.4; // 2400 eur/m2
      const luxuryBoost = sqm > 160 ? (sqm - 160) * 0.8 : 0;
      const ageDepreciation = age * 2.2;
      const basePrice = 45 + sqm * baseM2Rate + luxuryBoost - ageDepreciation;
      
      // Add realistic noise and a couple of outliers to illustrate hyperparameter tuning
      const noise = (rng() - 0.5) * 55 * (noiseLevel * 2.0);
      const price = Math.max(65, Math.round(basePrice + noise));

      const split = rng() < trainFraction ? 'train' : 'test';
      points.push({
        id: i,
        x1: Math.round(sqm),
        x2: Math.round(age),
        y: price,
        split,
      });
    }
  } else if (datasetId === 'energy') {
    // Regression: x1 = temp [-5 to 38], x2 = occupancy [10 to 100]
    for (let i = 0; i < totalPoints; i++) {
      const temp = -5 + rng() * 43;
      const occ = 10 + rng() * 90;
      
      // U-shaped curve with temp (heating below 18C, cooling above 24C)
      const hvacLoad = temp < 18 
        ? Math.pow(18 - temp, 1.35) * 4.5 
        : (temp > 24 ? Math.pow(temp - 24, 1.4) * 6.2 : 15);
      
      const occLoad = occ * 0.75;
      const baseLoad = 40;
      const noise = (rng() - 0.5) * 35 * noiseLevel;
      const kw = Math.max(25, Math.round(baseLoad + hvacLoad + occLoad + noise));

      const split = rng() < trainFraction ? 'train' : 'test';
      points.push({
        id: i,
        x1: Math.round(temp * 10) / 10,
        x2: Math.round(occ),
        y: kw,
        split,
      });
    }
  }

  return points;
}
