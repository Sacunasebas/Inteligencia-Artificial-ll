import React, { useState, useRef } from 'react';
import { TreeNode } from '../types';
import { ZoomIn, ZoomOut, RotateCcw, Info } from 'lucide-react';

interface TreeGraphProps {
  root: TreeNode | null;
  selectedNodeId?: string | null;
  onSelectNode?: (node: TreeNode | null) => void;
  activePath?: string[];
  type?: 'classification' | 'regression';
  classColors?: { [key: number]: string };
}

export const TreeGraph: React.FC<TreeGraphProps> = ({
  root,
  selectedNodeId,
  onSelectNode,
  activePath = [],
  type = 'classification',
  classColors = { 0: '#ef4444', 1: '#10b981' },
}) => {
  const [zoom, setZoom] = useState<number>(0.9);
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: 20, y: 10 });
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const dragStart = useRef<{ x: number; y: number }>({ x: 0, y: 0 });

  if (!root) {
    return (
      <div className="flex items-center justify-center h-64 bg-slate-50 border border-dashed border-slate-200 rounded-xl text-slate-700 text-sm">
        Entrenando árbol...
      </div>
    );
  }

  // Traverse all nodes and edges to render
  const nodes: TreeNode[] = [];
  const edges: { from: TreeNode; to: TreeNode; label: string }[] = [];

  const traverse = (node: TreeNode) => {
    nodes.push(node);
    if (node.leftChild) {
      edges.push({ from: node, to: node.leftChild, label: 'Sí (≤)' });
      traverse(node.leftChild);
    }
    if (node.rightChild) {
      edges.push({ from: node, to: node.rightChild, label: 'No (>)' });
      traverse(node.rightChild);
    }
  };
  traverse(root);

  // Compute bounding box
  const minX = Math.min(...nodes.map(n => n.x ?? 0), 0);
  const maxX = Math.max(...nodes.map(n => n.x ?? 0), 600);
  const maxY = Math.max(...nodes.map(n => n.y ?? 0), 400);

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    dragStart.current = { x: e.clientX - pan.x, y: e.clientY - pan.y };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDragging) return;
    setPan({
      x: e.clientX - dragStart.current.x,
      y: e.clientY - dragStart.current.y,
    });
  };

  const handleMouseUp = () => setIsDragging(false);

  return (
    <div className="relative w-full bg-slate-900 rounded-2xl border border-slate-800 overflow-hidden shadow-xs flex flex-col h-[400px]">
      {/* Top Header & Controls */}
      <div className="absolute top-3 left-3 right-3 flex items-center justify-between z-10 pointer-events-none">
        <div className="bg-slate-800/90 backdrop-blur-md px-3 py-1.5 rounded-lg border border-slate-700/70 text-xs text-slate-200 pointer-events-auto flex items-center gap-2">
          <Info className="w-3.5 h-3.5 text-emerald-400" />
          <span>Haz click en un nodo para inspeccionar sus datos y partición</span>
        </div>

        <div className="flex items-center gap-1.5 bg-slate-800/90 backdrop-blur-md p-1 rounded-lg border border-slate-700/70 pointer-events-auto">
          <button
            onClick={() => setZoom(prev => Math.min(prev + 0.15, 1.8))}
            className="p-1.5 hover:bg-slate-700 text-slate-300 rounded-md transition-colors"
            title="Acercar (+)"
          >
            <ZoomIn className="w-4 h-4" />
          </button>
          <button
            onClick={() => setZoom(prev => Math.max(prev - 0.15, 0.4))}
            className="p-1.5 hover:bg-slate-700 text-slate-300 rounded-md transition-colors"
            title="Alejar (-)"
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          <button
            onClick={() => {
              setZoom(0.9);
              setPan({ x: 20, y: 10 });
            }}
            className="p-1.5 hover:bg-slate-700 text-slate-300 rounded-md transition-colors"
            title="Restablecer vista"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* SVG Canvas with Interactive Drag and Pan */}
      <div
        className="w-full h-full cursor-grab active:cursor-grabbing select-none"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      >
        <svg
          className="w-full h-full"
          style={{
            touchAction: 'none',
          }}
        >
          <g
            transform={`translate(${pan.x}, ${pan.y}) scale(${zoom})`}
            style={{ transition: 'transform 0.1s ease-out' }}
          >
            {/* Draw Edges */}
            {edges.map((edge, idx) => {
              const fromX = edge.from.x ?? 0;
              const fromY = (edge.from.y ?? 0) + 38;
              const toX = edge.to.x ?? 0;
              const toY = (edge.to.y ?? 0) - 38;

              const isPathActive = activePath.includes(edge.from.id) && activePath.includes(edge.to.id);

              return (
                <g key={`edge-${idx}`}>
                  <path
                    d={`M ${fromX} ${fromY} C ${fromX} ${(fromY + toY) / 2}, ${toX} ${(fromY + toY) / 2}, ${toX} ${toY}`}
                    fill="none"
                    stroke={isPathActive ? '#10b981' : '#475569'}
                    strokeWidth={isPathActive ? 3 : 1.5}
                    strokeDasharray={isPathActive ? 'none' : 'none'}
                    className="transition-all duration-300"
                  />
                  {/* Branch condition badge */}
                  <rect
                    x={(fromX + toX) / 2 - 18}
                    y={(fromY + toY) / 2 - 8}
                    width={36}
                    height={16}
                    rx={4}
                    fill="#1e293b"
                    stroke={isPathActive ? '#10b981' : '#334155'}
                    strokeWidth={1}
                  />
                  <text
                    x={(fromX + toX) / 2}
                    y={(fromY + toY) / 2 + 3}
                    textAnchor="middle"
                    fontSize={9}
                    fontWeight="bold"
                    fill={isPathActive ? '#34d399' : '#94a3b8'}
                  >
                    {edge.label}
                  </text>
                </g>
              );
            })}

            {/* Draw Nodes */}
            {nodes.map(node => {
              const nx = node.x ?? 0;
              const ny = node.y ?? 0;
              const isSelected = selectedNodeId === node.id;
              const isPath = activePath.includes(node.id);

              const nodeWidth = 110;
              const nodeHeight = 68;

              // Node background color logic
              let headerBg = '#334155';
              let badgeColor = '#94a3b8';

              if (type === 'classification') {
                if (node.isLeaf) {
                  headerBg = node.predictedClass === 1 ? '#065f46' : '#991b1b';
                  badgeColor = node.predictedClass === 1 ? '#34d399' : '#f87171';
                } else {
                  headerBg = '#1e293b';
                  badgeColor = '#60a5fa';
                }
              } else {
                // Regression
                if (node.isLeaf) {
                  headerBg = '#1e3a8a';
                  badgeColor = '#93c5fd';
                } else {
                  headerBg = '#1e293b';
                  badgeColor = '#38bdf8';
                }
              }

              return (
                <g
                  key={node.id}
                  transform={`translate(${nx - nodeWidth / 2}, ${ny - nodeHeight / 2})`}
                  className="cursor-pointer transition-transform hover:scale-105"
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelectNode?.(node);
                  }}
                >
                  {/* Outer container rect */}
                  <rect
                    width={nodeWidth}
                    height={nodeHeight}
                    rx={8}
                    fill="#0f172a"
                    stroke={isSelected ? '#f59e0b' : isPath ? '#10b981' : '#334155'}
                    strokeWidth={isSelected ? 2.5 : isPath ? 2 : 1}
                    filter="drop-shadow(0 2px 4px rgba(0,0,0,0.4))"
                  />

                  {/* Header bar */}
                  <path
                    d={`M 0 8 Q 0 0 8 0 L ${nodeWidth - 8} 0 Q ${nodeWidth} 0 ${nodeWidth} 8 L ${nodeWidth} 22 L 0 22 Z`}
                    fill={headerBg}
                  />

                  {/* Header title */}
                  <text
                    x={nodeWidth / 2}
                    y={15}
                    textAnchor="middle"
                    fontSize={10}
                    fontWeight="bold"
                    fill="#f8fafc"
                  >
                    {node.isLeaf ? '🍃 Hoja' : `🔀 ${node.featureName ?? 'Corte'}`}
                  </text>

                  {/* Condition or Prediction */}
                  {!node.isLeaf ? (
                    <>
                      <text
                        x={nodeWidth / 2}
                        y={36}
                        textAnchor="middle"
                        fontSize={10}
                        fontWeight="semibold"
                        fill="#cbd5e1"
                      >
                        ≤ {node.threshold}
                      </text>
                      <text
                        x={nodeWidth / 2}
                        y={49}
                        textAnchor="middle"
                        fontSize={8.5}
                        fill="#94a3b8"
                      >
                        {type === 'classification' ? `Impureza: ${node.impurity}` : `MSE: ${node.mse}`}
                      </text>
                      <text
                        x={nodeWidth / 2}
                        y={61}
                        textAnchor="middle"
                        fontSize={8.5}
                        fill="#64748b"
                      >
                        Muestras: {node.samples}
                      </text>
                    </>
                  ) : (
                    <>
                      <text
                        x={nodeWidth / 2}
                        y={36}
                        textAnchor="middle"
                        fontSize={10}
                        fontWeight="bold"
                        fill={badgeColor}
                      >
                        {type === 'classification'
                          ? (node.predictedClass === 1 ? 'Clase 1' : 'Clase 0')
                          : `ŷ = ${node.predictedValue}`}
                      </text>
                      <text
                        x={nodeWidth / 2}
                        y={49}
                        textAnchor="middle"
                        fontSize={8.5}
                        fill="#94a3b8"
                      >
                        {type === 'classification'
                          ? `[${node.classCounts?.[0] ?? 0}, ${node.classCounts?.[1] ?? 0}]`
                          : `MSE: ${node.mse}`}
                      </text>
                      <text
                        x={nodeWidth / 2}
                        y={61}
                        textAnchor="middle"
                        fontSize={8.5}
                        fill="#64748b"
                      >
                        Muestras: {node.samples}
                      </text>
                    </>
                  )}
                </g>
              );
            })}
          </g>
        </svg>
      </div>

      {/* Legend footer inside visualizer */}
      <div className="bg-slate-950/80 border-t border-slate-800 px-4 py-2 flex items-center justify-between text-[11px] text-slate-400">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-xs bg-slate-700 border border-slate-600 inline-block" />
            <span>Nodo Decisión (Corte)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-xs bg-emerald-700 border border-emerald-500 inline-block" />
            <span>Hoja Terminal (Predicción)</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 inline-block" />
            <span>Ruta Activa (Decision Path)</span>
          </div>
        </div>
        <div>
          Total Nodos: <span className="text-slate-200 font-semibold">{nodes.length}</span> (Hojas: {nodes.filter(n => n.isLeaf).length})
        </div>
      </div>
    </div>
  );
};
