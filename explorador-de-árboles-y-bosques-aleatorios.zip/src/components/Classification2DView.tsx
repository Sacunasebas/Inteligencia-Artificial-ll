import React, { useRef, useEffect, useState } from 'react';
import { DataPoint2D, DatasetMeta, TreeNode } from '../types';
import { Target, Layers, Crosshair } from 'lucide-react';

interface Classification2DViewProps {
  datasetMeta: DatasetMeta;
  data: DataPoint2D[];
  predictFn: (x1: number, x2: number) => { predictedClass: number; prob?: number; path?: string[] };
  onHoverPoint?: (info: { x1: number; x2: number; pred: number; prob: number; path: string[] } | null) => void;
  selectedNode?: TreeNode | null;
  modelTitle?: string;
  showProbabilityGradient?: boolean;
}

export const Classification2DView: React.FC<Classification2DViewProps> = ({
  datasetMeta,
  data,
  predictFn,
  onHoverPoint,
  selectedNode,
  modelTitle = 'Espacio de Características y Frontera de Decisión',
  showProbabilityGradient = false,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [showTestPoints, setShowTestPoints] = useState<boolean>(true);
  const [cursorPos, setCursorPos] = useState<{ x1: number; x2: number; pred: number; prob: number } | null>(null);

  const [minX, maxX] = datasetMeta.feature1Range;
  const [minY, maxY] = datasetMeta.feature2Range;

  // Grid resolution for boundary heatmap
  const GRID_SIZE = 60;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    // Coordinate mapping helpers
    const toCanvasX = (x1: number) => ((x1 - minX) / (maxX - minX)) * width;
    const toCanvasY = (x2: number) => height - ((x2 - minY) / (maxY - minY)) * height;
    const fromCanvasX = (cx: number) => minX + (cx / width) * (maxX - minX);
    const fromCanvasY = (cy: number) => minY + ((height - cy) / height) * (maxY - minY);

    // 1. Draw Decision Boundary Heatmap
    const cellW = width / GRID_SIZE;
    const cellH = height / GRID_SIZE;

    const class0Color = datasetMeta.targetClasses?.[0]?.color || '#ef4444';
    const class1Color = datasetMeta.targetClasses?.[1]?.color || '#10b981';

    for (let i = 0; i < GRID_SIZE; i++) {
      for (let j = 0; j < GRID_SIZE; j++) {
        const x1 = fromCanvasX((i + 0.5) * cellW);
        const x2 = fromCanvasY((j + 0.5) * cellH);
        const res = predictFn(x1, x2);

        let fillStyle = '';
        if (showProbabilityGradient && res.prob !== undefined) {
          // Continuous smooth gradient for Random Forest probabilities
          const p1 = res.prob;
          // Interpolate between soft red and soft green/blue
          if (p1 >= 0.5) {
            const alpha = 0.08 + (p1 - 0.5) * 0.45;
            fillStyle = `rgba(16, 185, 129, ${alpha})`;
          } else {
            const alpha = 0.08 + (0.5 - p1) * 0.45;
            fillStyle = `rgba(239, 68, 68, ${alpha})`;
          }
        } else {
          // Sharp orthogonal regions for Decision Tree
          fillStyle = res.predictedClass === 1
            ? 'rgba(16, 185, 129, 0.15)'
            : 'rgba(239, 68, 68, 0.15)';
        }

        ctx.fillStyle = fillStyle;
        ctx.fillRect(i * cellW, j * cellH, cellW + 0.5, cellH + 0.5);
      }
    }

    // 2. Grid lines
    ctx.strokeStyle = '#e2e8f0';
    ctx.lineWidth = 1;
    const steps = 5;
    for (let s = 1; s < steps; s++) {
      const gx = (s / steps) * width;
      const gy = (s / steps) * height;
      ctx.beginPath();
      ctx.moveTo(gx, 0);
      ctx.lineTo(gx, height);
      ctx.stroke();

      ctx.beginPath();
      ctx.moveTo(0, gy);
      ctx.lineTo(width, gy);
      ctx.stroke();
    }

    // 3. Highlight selected node split line if applicable
    if (selectedNode && !selectedNode.isLeaf && selectedNode.threshold !== undefined && selectedNode.featureIndex !== undefined) {
      ctx.strokeStyle = '#f59e0b';
      ctx.lineWidth = 2.5;
      ctx.setLineDash([6, 4]);

      if (selectedNode.featureIndex === 0) {
        const lineX = toCanvasX(selectedNode.threshold);
        ctx.beginPath();
        ctx.moveTo(lineX, 0);
        ctx.lineTo(lineX, height);
        ctx.stroke();
      } else {
        const lineY = toCanvasY(selectedNode.threshold);
        ctx.beginPath();
        ctx.moveTo(0, lineY);
        ctx.lineTo(width, lineY);
        ctx.stroke();
      }
      ctx.setLineDash([]);
    }

    // 4. Draw Data Points (Train and Test)
    const pointsToDraw = showTestPoints ? data : data.filter(p => p.split === 'train');

    for (const pt of pointsToDraw) {
      const px = toCanvasX(pt.x1);
      const py = toCanvasY(pt.x2);
      const isTrain = pt.split === 'train';
      const ptColor = pt.y === 1 ? class1Color : class0Color;

      ctx.beginPath();
      if (isTrain) {
        // Solid circle
        ctx.arc(px, py, 4.5, 0, Math.PI * 2);
        ctx.fillStyle = ptColor;
        ctx.fill();
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 1.2;
        ctx.stroke();
      } else {
        // Test point: donut ring / diamond shape
        ctx.arc(px, py, 5.5, 0, Math.PI * 2);
        ctx.fillStyle = '#ffffff';
        ctx.fill();
        ctx.strokeStyle = ptColor;
        ctx.lineWidth = 2.5;
        ctx.stroke();
        // tiny center dot
        ctx.beginPath();
        ctx.arc(px, py, 1.5, 0, Math.PI * 2);
        ctx.fillStyle = ptColor;
        ctx.fill();
      }
    }
  }, [data, predictFn, showTestPoints, selectedNode, showProbabilityGradient, minX, maxX, minY, maxY, datasetMeta]);

  // Handle Canvas Mouse Move
  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const cx = e.clientX - rect.left;
    const cy = e.clientY - rect.top;

    const width = canvas.width;
    const height = canvas.height;

    const x1 = minX + (cx / width) * (maxX - minX);
    const x2 = minY + ((height - cy) / height) * (maxY - minY);

    const res = predictFn(x1, x2);
    const prob = res.prob ?? (res.predictedClass === 1 ? 0.95 : 0.05);

    const info = {
      x1: Math.round(x1 * 10) / 10,
      x2: Math.round(x2 * 10) / 10,
      pred: res.predictedClass,
      prob,
    };
    setCursorPos(info);
    onHoverPoint?.({ ...info, path: res.path || [] });
  };

  const handleMouseLeave = () => {
    setCursorPos(null);
    onHoverPoint?.(null);
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs flex flex-col">
      {/* Title & Filter bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
        <div className="flex items-center gap-2">
          <Layers className="w-4 h-4 text-emerald-600" />
          <h3 className="font-bold text-slate-900 text-sm">{modelTitle}</h3>
        </div>

        <div className="flex items-center gap-3">
          {/* Test points toggle */}
          <label className="flex items-center gap-1.5 text-xs text-slate-600 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={showTestPoints}
              onChange={(e) => setShowTestPoints(e.target.checked)}
              className="rounded-sm text-emerald-600 focus:ring-emerald-500 w-3.5 h-3.5"
            />
            <span>Mostrar datos de Test (anillos)</span>
          </label>
        </div>
      </div>

      {/* Canvas Container */}
      <div className="relative w-full aspect-square max-h-[380px] bg-slate-50 rounded-xl overflow-hidden border border-slate-200">
        <canvas
          ref={canvasRef}
          width={400}
          height={400}
          onMouseMove={handleMouseMove}
          onMouseLeave={handleMouseLeave}
          className="w-full h-full cursor-crosshair block"
        />

        {/* Live Hover inspector card in corner */}
        {cursorPos && (
          <div className="absolute top-2 right-2 bg-slate-900/90 backdrop-blur-md text-white px-2.5 py-1.5 rounded-lg text-xs shadow-lg border border-slate-700 pointer-events-none flex flex-col gap-0.5">
            <div className="flex items-center gap-1 font-semibold text-slate-200">
              <Crosshair className="w-3 h-3 text-emerald-400" />
              <span>Punto Seleccionado</span>
            </div>
            <div className="text-[11px] text-slate-300">
              {datasetMeta.feature1Name}: <span className="font-mono text-white">{cursorPos.x1}</span> {datasetMeta.feature1Unit}
            </div>
            <div className="text-[11px] text-slate-300">
              {datasetMeta.feature2Name}: <span className="font-mono text-white">{cursorPos.x2}</span> {datasetMeta.feature2Unit}
            </div>
            <div className="mt-1 pt-1 border-t border-slate-800 flex items-center justify-between gap-3 font-semibold text-[11px]">
              <span>Predicción:</span>
              <span className={cursorPos.pred === 1 ? 'text-emerald-400' : 'text-rose-400'}>
                {datasetMeta.targetClasses?.[cursorPos.pred]?.label ?? `Clase ${cursorPos.pred}`}
              </span>
            </div>
            {cursorPos.prob !== undefined && (
              <div className="text-[10px] text-slate-400 text-right">
                Confianza: {(cursorPos.prob * 100).toFixed(0)}%
              </div>
            )}
          </div>
        )}

        {/* Axis Labels */}
        <div className="absolute bottom-1 right-2 text-[10px] font-medium text-slate-700 bg-white/85 px-1.5 py-0.5 rounded-xs pointer-events-none">
          {datasetMeta.feature1Name} ({datasetMeta.feature1Unit}) →
        </div>
        <div className="absolute top-2 left-2 text-[10px] font-medium text-slate-700 bg-white/85 px-1.5 py-0.5 rounded-xs pointer-events-none">
          ↑ {datasetMeta.feature2Name} ({datasetMeta.feature2Unit})
        </div>
      </div>

      {/* Legend */}
      <div className="mt-3 pt-2.5 border-t border-slate-100 flex flex-wrap items-center justify-between text-xs text-slate-600 gap-2">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            <span
              className="w-3 h-3 rounded-full inline-block"
              style={{ backgroundColor: datasetMeta.targetClasses?.[0]?.color || '#ef4444' }}
            />
            <span>{datasetMeta.targetClasses?.[0]?.label || 'Clase 0'}</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span
              className="w-3 h-3 rounded-full inline-block"
              style={{ backgroundColor: datasetMeta.targetClasses?.[1]?.color || '#10b981' }}
            />
            <span>{datasetMeta.targetClasses?.[1]?.label || 'Clase 1'}</span>
          </div>
        </div>

        <div className="flex items-center gap-3 text-slate-700">
          <div className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded-full bg-slate-400 inline-block" />
            <span>Train (Punto)</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded-full border-2 border-slate-400 bg-white inline-block" />
            <span>Test (Anillo)</span>
          </div>
        </div>
      </div>
    </div>
  );
};
