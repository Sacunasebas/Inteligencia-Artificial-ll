import React, { useRef, useEffect, useState } from 'react';
import { DataPoint2D, DatasetMeta, TreeNode } from '../types';
import { TrendingUp, Layers, Crosshair, HelpCircle } from 'lucide-react';

interface RegressionPlotProps {
  datasetMeta: DatasetMeta;
  data: DataPoint2D[];
  predictFn: (x1: number, x2: number) => { predictedValue: number; path?: string[] };
  root: TreeNode | null;
  onHoverPoint?: (info: { x1: number; y: number; pred: number; diff: number; path?: string[] } | null) => void;
}

export const RegressionPlot: React.FC<RegressionPlotProps> = ({
  datasetMeta,
  data,
  predictFn,
  root,
  onHoverPoint,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [showTestPoints, setShowTestPoints] = useState<boolean>(true);
  const [showSplitLines, setShowSplitLines] = useState<boolean>(true);
  const [hoverData, setHoverData] = useState<{ x1: number; pred: number } | null>(null);

  const [minX, maxX] = datasetMeta.feature1Range;
  // Compute Y range from data
  const yValues = data.map(d => d.y);
  const minY = Math.min(...yValues) * 0.85;
  const maxY = Math.max(...yValues) * 1.08;

  // Extract all split thresholds on feature 0 (X1)
  const x1Splits: number[] = [];
  const findSplits = (node: TreeNode | null) => {
    if (!node) return;
    if (!node.isLeaf && node.featureIndex === 0 && node.threshold !== undefined) {
      x1Splits.push(node.threshold);
    }
    findSplits(node.leftChild || null);
    findSplits(node.rightChild || null);
  };
  findSplits(root);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    const padding = { top: 25, right: 25, bottom: 40, left: 55 };

    const plotW = width - padding.left - padding.right;
    const plotH = height - padding.top - padding.bottom;

    // Coordinate mapping
    const toCanvasX = (x: number) => padding.left + ((x - minX) / (maxX - minX)) * plotW;
    const toCanvasY = (y: number) => padding.top + plotH - ((y - minY) / (maxY - minY)) * plotH;
    const fromCanvasX = (cx: number) => minX + ((cx - padding.left) / plotW) * (maxX - minX);

    // Clear
    ctx.clearRect(0, 0, width, height);

    // Background
    ctx.fillStyle = '#f8fafc';
    ctx.fillRect(padding.left, padding.top, plotW, plotH);

    // Grid lines
    ctx.strokeStyle = '#e2e8f0';
    ctx.lineWidth = 1;
    const xTicks = 6;
    for (let i = 0; i <= xTicks; i++) {
      const val = minX + (i / xTicks) * (maxX - minX);
      const cx = toCanvasX(val);
      ctx.beginPath();
      ctx.moveTo(cx, padding.top);
      ctx.lineTo(cx, padding.top + plotH);
      ctx.stroke();

      // Label
      ctx.fillStyle = '#64748b';
      ctx.font = '10px JetBrains Mono, monospace';
      ctx.textAlign = 'center';
      ctx.fillText(Math.round(val).toString(), cx, padding.top + plotH + 16);
    }

    const yTicks = 5;
    for (let j = 0; j <= yTicks; j++) {
      const val = minY + (j / yTicks) * (maxY - minY);
      const cy = toCanvasY(val);
      ctx.beginPath();
      ctx.moveTo(padding.left, cy);
      ctx.lineTo(padding.left + plotW, cy);
      ctx.stroke();

      // Label
      ctx.fillStyle = '#64748b';
      ctx.font = '10px JetBrains Mono, monospace';
      ctx.textAlign = 'right';
      ctx.fillText(Math.round(val).toString(), padding.left - 8, cy + 3.5);
    }

    // Vertical Split Boundary Lines (Particiones del espacio)
    if (showSplitLines) {
      ctx.strokeStyle = '#cbd5e1';
      ctx.lineWidth = 1.5;
      ctx.setLineDash([4, 4]);
      for (const splitVal of x1Splits) {
        const sx = toCanvasX(splitVal);
        ctx.beginPath();
        ctx.moveTo(sx, padding.top);
        ctx.lineTo(sx, padding.top + plotH);
        ctx.stroke();
      }
      ctx.setLineDash([]);
    }

    // Step-Function Predictions Line (Curva Escalonada del Árbol de Regresión)
    // Evaluate across fine horizontal resolution
    const numEvalPoints = 300;
    // We fix feature 2 (e.g. Antigüedad or Ocupación) at its median value to inspect feature 1
    const medianX2 = (datasetMeta.feature2Range[0] + datasetMeta.feature2Range[1]) / 2;

    const curvePoints: { x: number; y: number }[] = [];
    for (let p = 0; p <= numEvalPoints; p++) {
      const evalX1 = minX + (p / numEvalPoints) * (maxX - minX);
      const pred = predictFn(evalX1, medianX2).predictedValue;
      curvePoints.push({ x: toCanvasX(evalX1), y: toCanvasY(pred) });
    }

    // Draw stepped prediction function
    ctx.strokeStyle = '#2563eb';
    ctx.lineWidth = 3;
    ctx.beginPath();
    for (let i = 0; i < curvePoints.length; i++) {
      if (i === 0) {
        ctx.moveTo(curvePoints[i].x, curvePoints[i].y);
      } else {
        ctx.lineTo(curvePoints[i].x, curvePoints[i].y);
      }
    }
    ctx.stroke();

    // Data Points
    const pointsToDraw = showTestPoints ? data : data.filter(p => p.split === 'train');
    for (const pt of pointsToDraw) {
      const px = toCanvasX(pt.x1);
      const py = toCanvasY(pt.y);
      const isTrain = pt.split === 'train';

      ctx.beginPath();
      if (isTrain) {
        ctx.arc(px, py, 4, 0, Math.PI * 2);
        ctx.fillStyle = '#0f172a';
        ctx.fill();
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 1.2;
        ctx.stroke();
      } else {
        ctx.arc(px, py, 5, 0, Math.PI * 2);
        ctx.fillStyle = '#ffffff';
        ctx.fill();
        ctx.strokeStyle = '#f59e0b';
        ctx.lineWidth = 2.2;
        ctx.stroke();
      }
    }

    // Outer frame border
    ctx.strokeStyle = '#94a3b8';
    ctx.lineWidth = 1;
    ctx.strokeRect(padding.left, padding.top, plotW, plotH);
  }, [data, predictFn, root, showTestPoints, showSplitLines, minX, maxX, minY, maxY, datasetMeta, x1Splits]);

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const cx = e.clientX - rect.left;
    const padding = { top: 25, right: 25, bottom: 40, left: 55 };
    const plotW = canvas.width - padding.left - padding.right;

    if (cx < padding.left || cx > padding.left + plotW) {
      setHoverData(null);
      return;
    }

    const x1 = minX + ((cx - padding.left) / plotW) * (maxX - minX);
    const medianX2 = (datasetMeta.feature2Range[0] + datasetMeta.feature2Range[1]) / 2;
    const res = predictFn(x1, medianX2);

    const info = {
      x1: Math.round(x1 * 10) / 10,
      pred: Math.round(res.predictedValue * 10) / 10,
    };
    setHoverData(info);
    onHoverPoint?.({
      x1: info.x1,
      y: 0,
      pred: info.pred,
      diff: 0,
      path: res.path,
    });
  };

  const handleMouseLeave = () => {
    setHoverData(null);
    onHoverPoint?.(null);
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs flex flex-col">
      {/* Title and Controls */}
      <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
        <div className="flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-blue-600" />
          <h3 className="font-bold text-slate-900 text-sm">
            Curva Escalonada de Regresión: {datasetMeta.targetName} vs {datasetMeta.feature1Name}
          </h3>
        </div>

        <div className="flex items-center gap-4">
          <label className="flex items-center gap-1.5 text-xs text-slate-600 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={showSplitLines}
              onChange={(e) => setShowSplitLines(e.target.checked)}
              className="rounded-sm text-blue-600 focus:ring-blue-500 w-3.5 h-3.5"
            />
            <span>Líneas de corte (Splits)</span>
          </label>

          <label className="flex items-center gap-1.5 text-xs text-slate-600 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={showTestPoints}
              onChange={(e) => setShowTestPoints(e.target.checked)}
              className="rounded-sm text-blue-600 focus:ring-blue-500 w-3.5 h-3.5"
            />
            <span>Datos Test (anillos)</span>
          </label>
        </div>
      </div>

      {/* Canvas */}
      <div className="relative w-full aspect-[4/3] max-h-[380px] bg-slate-50 rounded-xl overflow-hidden border border-slate-200">
        <canvas
          ref={canvasRef}
          width={520}
          height={380}
          onMouseMove={handleMouseMove}
          onMouseLeave={handleMouseLeave}
          className="w-full h-full cursor-crosshair block"
        />

        {/* Hover Inspector Card */}
        {hoverData && (
          <div className="absolute top-3 right-3 bg-slate-900/90 backdrop-blur-md text-white px-3 py-1.5 rounded-lg text-xs shadow-lg border border-slate-700 pointer-events-none">
            <div className="text-[11px] text-slate-300">
              {datasetMeta.feature1Name}: <span className="font-mono text-white">{hoverData.x1}</span> {datasetMeta.feature1Unit}
            </div>
            <div className="font-semibold text-blue-300 mt-0.5">
              Predicción escalón ŷ: <span className="font-mono text-white">{hoverData.pred}</span> {datasetMeta.targetUnit}
            </div>
          </div>
        )}

        {/* Axis Labels */}
        <div className="absolute bottom-1 right-4 text-[10px] font-medium text-slate-700 bg-white/85 px-1.5 py-0.5 rounded-xs pointer-events-none">
          {datasetMeta.feature1Name} ({datasetMeta.feature1Unit}) →
        </div>
        <div className="absolute top-2 left-3 text-[10px] font-medium text-slate-700 bg-white/85 px-1.5 py-0.5 rounded-xs pointer-events-none">
          ↑ {datasetMeta.targetName} ({datasetMeta.targetUnit})
        </div>
      </div>

      {/* Didactic explanation badge below chart */}
      <div className="mt-3 p-2.5 bg-blue-50/70 rounded-xl border border-blue-100 flex items-start gap-2.5 text-xs text-blue-900">
        <HelpCircle className="w-4 h-4 text-blue-600 shrink-0 mt-0.5" />
        <div>
          <span className="font-bold">¿Por qué la predicción es escalonada?</span> A diferencia de una regresión lineal, el árbol agrupa los datos en particiones rectangulares y predice el promedio <span className="font-mono bg-blue-100 px-1 py-0.5 rounded-xs">ȳ</span> de cada segmento. Si aumentas la profundidad excesivamente, el árbol creará escalones diminutos para perseguir puntos ruidosos (sobreajuste).
        </div>
      </div>
    </div>
  );
};
