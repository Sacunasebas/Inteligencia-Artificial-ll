import React from 'react';
import { PEDAGOGICAL_CHALLENGES } from '../algorithms/challenges';
import { PedagogicalChallenge, ModelType } from '../types';
import { Trophy, CheckCircle, HelpCircle, ArrowRight, Sparkles, X } from 'lucide-react';

interface ChallengePanelProps {
  currentModule: ModelType;
  onSelectChallenge: (challenge: PedagogicalChallenge) => void;
  activeChallengeId: string | null;
  currentMetrics: any;
  onClose: () => void;
}

export const ChallengePanel: React.FC<ChallengePanelProps> = ({
  currentModule,
  onSelectChallenge,
  activeChallengeId,
  currentMetrics,
  onClose,
}) => {
  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-md flex flex-col gap-6 max-w-4xl mx-auto my-4 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-100 pb-4">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-amber-500 text-white">
            <Trophy className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-bold text-slate-900 text-lg">Retos Prácticos de Ajuste Fino</h2>
            <p className="text-xs text-slate-700">
              Ponte a prueba resolviendo problemas reales de sobreajuste y regularización
            </p>
          </div>
        </div>

        <button
          onClick={onClose}
          className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
          title="Cerrar retos"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Challenge Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {PEDAGOGICAL_CHALLENGES.map((challenge) => {
          const isActive = activeChallengeId === challenge.id;
          const isCompleted = isActive && currentMetrics && challenge.checkCompletion(currentMetrics);

          return (
            <div
              key={challenge.id}
              className={`p-4 rounded-xl border flex flex-col justify-between gap-3 transition-all ${
                isCompleted
                  ? 'bg-emerald-50/80 border-emerald-300 ring-2 ring-emerald-500/20'
                  : isActive
                  ? 'bg-amber-50/70 border-amber-300 ring-2 ring-amber-500/20'
                  : 'bg-slate-50 border-slate-200 hover:border-slate-300'
              }`}
            >
              <div className="flex flex-col gap-2">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-slate-200/70 text-slate-700">
                    {challenge.module === 'classification_tree'
                      ? 'Clasificación'
                      : challenge.module === 'regression_tree'
                      ? 'Regresión'
                      : 'Random Forest'}
                  </span>
                  {isCompleted && (
                    <span className="flex items-center gap-1 text-[11px] font-bold text-emerald-700">
                      <CheckCircle className="w-4 h-4 text-emerald-600" />
                      Completado
                    </span>
                  )}
                </div>

                <h3 className="font-bold text-slate-900 text-sm">{challenge.title}</h3>
                <p className="text-xs text-slate-600 leading-relaxed">
                  {challenge.description}
                </p>

                {/* Target objective */}
                <div className="mt-1 p-2 rounded-lg bg-white border border-slate-200/80 text-[11px] text-slate-800 font-medium">
                  🎯 <strong>Objetivo:</strong> {challenge.targetCondition}
                </div>
              </div>

              {/* Action Button & Hint */}
              <div className="flex flex-col gap-2 pt-2 border-t border-slate-200/60">
                <button
                  onClick={() => onSelectChallenge(challenge)}
                  className={`w-full py-2 px-3 rounded-lg text-xs font-semibold flex items-center justify-center gap-2 transition-all ${
                    isActive
                      ? (isCompleted
                        ? 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-xs'
                        : 'bg-amber-600 text-white hover:bg-amber-700 shadow-xs')
                      : 'bg-slate-900 text-white hover:bg-slate-800'
                  }`}
                >
                  <span>{isActive ? (isCompleted ? '¡Completado! Reiniciar' : 'En Curso...') : 'Aceptar Reto'}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>

                {isActive && (
                  <div className="text-[11px] text-slate-500 bg-white/70 p-2 rounded-md border border-slate-200 flex items-start gap-1.5">
                    <HelpCircle className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5" />
                    <span><strong>Pista:</strong> {challenge.hint}</span>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
