import React from 'react';
import { BookOpen, AlertTriangle, CheckCircle2, Sliders, Trees, TrendingUp, GitFork, X } from 'lucide-react';

interface PedagogicalGuideProps {
  onClose: () => void;
}

export const PedagogicalGuide: React.FC<PedagogicalGuideProps> = ({ onClose }) => {
  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-6 shadow-md flex flex-col gap-6 max-w-5xl mx-auto my-4 animate-in fade-in duration-200">
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-100 pb-4">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-xl bg-slate-900 text-emerald-400">
            <BookOpen className="w-5 h-5" />
          </div>
          <div>
            <h2 className="font-bold text-slate-900 text-lg">
              Guía Didáctica: Hiperparámetros, Sesgo y Varianza
            </h2>
            <p className="text-xs text-slate-700">
              Aprende a controlar la complejidad de los modelos basados en árboles
            </p>
          </div>
        </div>

        <button
          onClick={onClose}
          className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
          title="Cerrar guía"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* 1. The Core Concept: Bias-Variance Tradeoff */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="p-4 rounded-xl bg-amber-50/70 border border-amber-200 flex flex-col gap-2">
          <div className="flex items-center gap-2 font-bold text-amber-900 text-sm">
            <AlertTriangle className="w-4 h-4 text-amber-600" />
            <span>Subajuste (Alto Sesgo / Underfitting)</span>
          </div>
          <p className="text-xs text-slate-700 leading-relaxed">
            Ocurre cuando el modelo es <strong>demasiado restrictivo</strong>. Por ejemplo, con <code className="bg-amber-100 px-1 py-0.5 rounded-xs">max_depth = 1</code>, el árbol solo puede hacer una única pregunta binaria, ignorando patrones complejos o relaciones diagonales.
          </p>
          <div className="text-[11px] font-semibold text-amber-900 mt-1">
            Síntoma: Rendimiento bajo tanto en Entrenamiento como en Prueba.
          </div>
        </div>

        <div className="p-4 rounded-xl bg-rose-50/70 border border-rose-200 flex flex-col gap-2">
          <div className="flex items-center gap-2 font-bold text-rose-900 text-sm">
            <AlertTriangle className="w-4 h-4 text-rose-600" />
            <span>Sobreajuste (Alta Varianza / Overfitting)</span>
          </div>
          <p className="text-xs text-slate-700 leading-relaxed">
            Ocurre cuando el modelo es <strong>demasiado libre</strong>. Con <code className="bg-rose-100 px-1 py-0.5 rounded-xs">max_depth = 10</code> y <code className="bg-rose-100 px-1 py-0.5 rounded-xs">min_samples_leaf = 1</code>, el árbol crea pequeñas islas y rectángulos aislados para envolver cada punto ruidoso.
          </p>
          <div className="text-[11px] font-semibold text-rose-900 mt-1">
            Síntoma: 100% de precisión en Entrenamiento pero caída drástica en Prueba.
          </div>
        </div>
      </div>

      {/* 2. Master Comparison Table of Hyperparameters */}
      <div className="space-y-3">
        <h3 className="font-bold text-slate-900 text-sm flex items-center gap-2">
          <Sliders className="w-4 h-4 text-emerald-600" />
          <span>Tabla Maestra de Impacto de Hiperparámetros</span>
        </h3>

        <div className="overflow-x-auto border border-slate-200 rounded-xl">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-700 font-bold">
              <tr>
                <th className="p-3">Hiperparámetro</th>
                <th className="p-3">Si lo AUMENTAS (+)</th>
                <th className="p-3">Si lo DISMINUYES (-)</th>
                <th className="p-3">Recomendación Práctica</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-600">
              <tr>
                <td className="p-3 font-mono font-bold text-slate-900">max_depth</td>
                <td className="p-3 text-rose-700">Mayor complejidad, riesgo de sobreajuste.</td>
                <td className="p-3 text-amber-700">Mayor simplicidad, riesgo de subajuste.</td>
                <td className="p-3 font-medium text-slate-800">Limita a 3–5 en árboles simples para mantener interpretabilidad humana.</td>
              </tr>
              <tr>
                <td className="p-3 font-mono font-bold text-slate-900">min_samples_leaf</td>
                <td className="p-3 text-emerald-700">Regulariza el modelo; suaviza fronteras y escalones.</td>
                <td className="p-3 text-rose-700">Permite hojas con 1 sola muestra (alta varianza ante ruido).</td>
                <td className="p-3 font-medium text-slate-800">Fíjalo en ≥ 4 o el 1%–5% del tamaño de tu dataset.</td>
              </tr>
              <tr>
                <td className="p-3 font-mono font-bold text-slate-900">min_samples_split</td>
                <td className="p-3 text-emerald-700">Evita que se dividan nodos pequeños.</td>
                <td className="p-3 text-rose-700">Fomenta ramificación profunda hasta agotar datos.</td>
                <td className="p-3 font-medium text-slate-800">Usualmente entre 5 y 20.</td>
              </tr>
              <tr>
                <td className="p-3 font-mono font-bold text-slate-900">n_estimators (Bosque)</td>
                <td className="p-3 text-emerald-700">Reduce la varianza sin causar sobreajuste (estabilidad).</td>
                <td className="p-3 text-amber-700">Predicción inestable dependiente de pocos árboles.</td>
                <td className="p-3 font-medium text-slate-800">Más siempre es mejor (100–300 en producción), acotado solo por tiempo de cómputo.</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* 3. The 3 Models Compared */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Classification Tree */}
        <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 flex flex-col gap-2 text-xs">
          <div className="flex items-center gap-2 font-bold text-slate-900">
            <GitFork className="w-4 h-4 text-emerald-600" />
            <span>Árbol de Decisión</span>
          </div>
          <p className="text-slate-600">
            Genera <strong>reglas if-then-else ortogonales</strong> particionando el espacio con líneas paralelas a los ejes. Es el modelo más explicable de la IA.
          </p>
          <div className="text-[11px] text-slate-500 font-mono bg-white p-2 rounded-md border border-slate-200">
            Impureza: Gini o Entropía
          </div>
        </div>

        {/* Regression Tree */}
        <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 flex flex-col gap-2 text-xs">
          <div className="flex items-center gap-2 font-bold text-slate-900">
            <TrendingUp className="w-4 h-4 text-blue-600" />
            <span>Árbol de Regresión</span>
          </div>
          <p className="text-slate-600">
            Aproxima funciones continuas mediante <strong>escalones planos constantes</strong> (<span className="font-mono">ȳ</span> promedio de la hoja). No extrapola más allá del rango visto.
          </p>
          <div className="text-[11px] text-slate-500 font-mono bg-white p-2 rounded-md border border-slate-200">
            Criterio: Reducción de MSE / Varianza
          </div>
        </div>

        {/* Random Forest */}
        <div className="p-4 rounded-xl border border-slate-200 bg-slate-50 flex flex-col gap-2 text-xs">
          <div className="flex items-center gap-2 font-bold text-slate-900">
            <Trees className="w-4 h-4 text-indigo-600" />
            <span>Random Forest (Ensamble)</span>
          </div>
          <p className="text-slate-600">
            Combina <strong>Bagging</strong> (muestras con reemplazo) con selección aleatoria de variables. Suaviza la frontera ortogonal convirtiéndola en un mapa de probabilidades continuo.
          </p>
          <div className="text-[11px] text-slate-500 font-mono bg-white p-2 rounded-md border border-slate-200">
            Mecanismo: Votación de consenso
          </div>
        </div>
      </div>
    </div>
  );
};
