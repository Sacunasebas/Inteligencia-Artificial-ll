import React from 'react';
import { ClassificationMetrics, RegressionMetrics, ForestMetrics, ModelType } from '../types';
import { Activity, AlertCircle, CheckCircle2, AlertTriangle, ArrowUpRight, BarChart2 } from 'lucide-react';

interface MetricsCardProps {
  modelType: ModelType;
  classMetrics?: ClassificationMetrics;
  regMetrics?: RegressionMetrics;
  forestMetrics?: ForestMetrics;
}

export const MetricsCard: React.FC<MetricsCardProps> = ({
  modelType,
  classMetrics,
  regMetrics,
  forestMetrics,
}) => {
  // Diagnosis styling
  const getStatusBadge = (status?: string) => {
    switch (status) {
      case 'optimal':
      case 'high_trees_optimal':
        return {
          icon: <CheckCircle2 className="w-4 h-4 text-emerald-600" />,
          bg: 'bg-emerald-50 border-emerald-200 text-emerald-900',
          pill: 'bg-emerald-100 text-emerald-800',
        };
      case 'mild_overfit':
        return {
          icon: <AlertTriangle className="w-4 h-4 text-amber-600" />,
          bg: 'bg-amber-50 border-amber-200 text-amber-900',
          pill: 'bg-amber-100 text-amber-800',
        };
      case 'severe_overfit':
        return {
          icon: <AlertCircle className="w-4 h-4 text-rose-600" />,
          bg: 'bg-rose-50 border-rose-200 text-rose-900',
          pill: 'bg-rose-100 text-rose-800',
        };
      case 'underfitting':
      case 'low_trees':
      default:
        return {
          icon: <AlertCircle className="w-4 h-4 text-blue-600" />,
          bg: 'bg-blue-50 border-blue-200 text-blue-900',
          pill: 'bg-blue-100 text-blue-800',
        };
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col gap-4">
      {/* Title */}
      <div className="flex items-center justify-between border-b border-slate-100 pb-3">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-slate-100 text-slate-700">
            <Activity className="w-4 h-4" />
          </div>
          <h3 className="font-bold text-slate-900 text-sm">Rendimiento & Diagnóstico Pedagógico</h3>
        </div>
      </div>

      {/* CLASSIFICATION METRICS */}
      {modelType === 'classification_tree' && classMetrics && (
        <div className="flex flex-col gap-4">
          {/* Key Metric Blocks */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {/* Train Accuracy */}
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
              <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
                Train Accuracy
              </span>
              <div className="mt-1 flex items-baseline gap-1">
                <span className="text-2xl font-bold font-mono text-slate-900">
                  {classMetrics.trainAccuracy}%
                </span>
              </div>
              <span className="text-[10px] text-slate-400">Datos aprendidos</span>
            </div>

            {/* Test Accuracy */}
            <div className="bg-emerald-50/70 p-3 rounded-xl border border-emerald-100">
              <span className="text-[11px] font-semibold text-emerald-800 uppercase tracking-wider block">
                Test Accuracy
              </span>
              <div className="mt-1 flex items-baseline gap-1">
                <span className="text-2xl font-bold font-mono text-emerald-700">
                  {classMetrics.testAccuracy}%
                </span>
              </div>
              <span className="text-[10px] text-emerald-600 font-medium">Generalización real</span>
            </div>

            {/* Overfitting Gap */}
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 col-span-2 sm:col-span-1">
              <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
                Brecha Sobreajuste
              </span>
              <div className="mt-1 flex items-baseline gap-1">
                <span className={`text-2xl font-bold font-mono ${
                  classMetrics.overfittingGap > 12 ? 'text-rose-600' : (classMetrics.overfittingGap > 6 ? 'text-amber-600' : 'text-slate-800')
                }`}>
                  {classMetrics.overfittingGap}%
                </span>
              </div>
              <span className="text-[10px] text-slate-500">Train - Test</span>
            </div>
          </div>

          {/* Diagnostic Alert Box */}
          {(() => {
            const badge = getStatusBadge(classMetrics.diagnosis.status);
            return (
              <div className={`p-3.5 rounded-xl border ${badge.bg} flex flex-col gap-1.5 text-xs`}>
                <div className="flex items-center gap-2 font-bold">
                  {badge.icon}
                  <span>{classMetrics.diagnosis.title}</span>
                </div>
                <p className="text-slate-700 leading-relaxed">
                  {classMetrics.diagnosis.message}
                </p>
                <div className="mt-1 pt-1.5 border-t border-black/10 text-[11px] font-medium text-slate-800">
                  💡 <strong>Recomendación:</strong> {classMetrics.diagnosis.advice}
                </div>
              </div>
            );
          })()}

          {/* Confusion Matrix & Node Count */}
          <div className="pt-2 border-t border-slate-100 grid grid-cols-2 gap-3 text-xs">
            <div className="space-y-1">
              <span className="font-semibold text-slate-700 block">Matriz de Confusión (Test):</span>
              <div className="grid grid-cols-2 gap-1 font-mono text-center text-[11px]">
                <div className="bg-emerald-50 border border-emerald-200 p-1.5 rounded-md" title="Verdaderos Positivos">
                  VP: {classMetrics.confusionMatrix.tp}
                </div>
                <div className="bg-rose-50 border border-rose-200 p-1.5 rounded-md" title="Falsos Positivos">
                  FP: {classMetrics.confusionMatrix.fp}
                </div>
                <div className="bg-rose-50 border border-rose-200 p-1.5 rounded-md" title="Falsos Negativos">
                  FN: {classMetrics.confusionMatrix.fn}
                </div>
                <div className="bg-slate-100 border border-slate-200 p-1.5 rounded-md" title="Verdaderos Negativos">
                  VN: {classMetrics.confusionMatrix.tn}
                </div>
              </div>
            </div>

            <div className="space-y-1 flex flex-col justify-center text-slate-600 text-[11px]">
              <div className="flex justify-between">
                <span>Profundidad real alcanzada:</span>
                <span className="font-bold text-slate-900">{classMetrics.treeDepth} niveles</span>
              </div>
              <div className="flex justify-between">
                <span>Total de hojas terminales:</span>
                <span className="font-bold text-slate-900">{classMetrics.leafCount} hojas</span>
              </div>
              <div className="flex justify-between">
                <span>Nodos en total:</span>
                <span className="font-bold text-slate-900">{classMetrics.totalNodes} nodos</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* REGRESSION METRICS */}
      {modelType === 'regression_tree' && regMetrics && (
        <div className="flex flex-col gap-4">
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {/* Train R2 */}
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
              <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
                Train R²
              </span>
              <div className="mt-1 flex items-baseline gap-1">
                <span className="text-2xl font-bold font-mono text-slate-900">
                  {regMetrics.trainR2.toFixed(2)}
                </span>
              </div>
              <span className="text-[10px] text-slate-400">Varianza explicada</span>
            </div>

            {/* Test R2 */}
            <div className="bg-blue-50/70 p-3 rounded-xl border border-blue-100">
              <span className="text-[11px] font-semibold text-blue-800 uppercase tracking-wider block">
                Test R²
              </span>
              <div className="mt-1 flex items-baseline gap-1">
                <span className="text-2xl font-bold font-mono text-blue-700">
                  {regMetrics.testR2.toFixed(2)}
                </span>
              </div>
              <span className="text-[10px] text-blue-600 font-medium">Capacidad predictiva</span>
            </div>

            {/* Test RMSE */}
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-100 col-span-2 sm:col-span-1">
              <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
                Test RMSE
              </span>
              <div className="mt-1 flex items-baseline gap-1">
                <span className="text-2xl font-bold font-mono text-slate-900">
                  {regMetrics.testRmse}
                </span>
              </div>
              <span className="text-[10px] text-slate-500">Error en unidades reales</span>
            </div>
          </div>

          {/* Diagnostic Box */}
          {(() => {
            const badge = getStatusBadge(regMetrics.diagnosis.status);
            return (
              <div className={`p-3.5 rounded-xl border ${badge.bg} flex flex-col gap-1.5 text-xs`}>
                <div className="flex items-center gap-2 font-bold">
                  {badge.icon}
                  <span>{regMetrics.diagnosis.title}</span>
                </div>
                <p className="text-slate-700 leading-relaxed">
                  {regMetrics.diagnosis.message}
                </p>
                <div className="mt-1 pt-1.5 border-t border-black/10 text-[11px] font-medium text-slate-800">
                  💡 <strong>Recomendación:</strong> {regMetrics.diagnosis.advice}
                </div>
              </div>
            );
          })()}

          {/* Detailed MSE breakdown */}
          <div className="pt-2 border-t border-slate-100 grid grid-cols-2 gap-3 text-[11px] text-slate-600">
            <div>
              <span>MSE Entrenamiento: </span>
              <span className="font-mono font-bold text-slate-900">{regMetrics.trainMse}</span>
            </div>
            <div>
              <span>MSE Prueba (Test): </span>
              <span className="font-mono font-bold text-slate-900">{regMetrics.testMse}</span>
            </div>
            <div>
              <span>Hojas (Escalones constantes): </span>
              <span className="font-bold text-slate-900">{regMetrics.leafCount}</span>
            </div>
            <div>
              <span>Profundidad efectiva: </span>
              <span className="font-bold text-slate-900">{regMetrics.treeDepth}</span>
            </div>
          </div>
        </div>
      )}

      {/* RANDOM FOREST METRICS */}
      {modelType === 'random_forest' && forestMetrics && (
        <div className="flex flex-col gap-4">
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            {/* Forest Test Accuracy */}
            <div className="bg-indigo-50/70 p-3 rounded-xl border border-indigo-100">
              <span className="text-[11px] font-semibold text-indigo-800 uppercase tracking-wider block">
                Test Bosque (Ensemble)
              </span>
              <div className="mt-1 flex items-baseline gap-1">
                <span className="text-2xl font-bold font-mono text-indigo-700">
                  {forestMetrics.testAccuracy}%
                </span>
              </div>
              <span className="text-[10px] text-indigo-600 font-medium">Votación mayoritaria</span>
            </div>

            {/* Single Tree Baseline */}
            <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">
              <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider block">
                Árbol Solitario (Test)
              </span>
              <div className="mt-1 flex items-baseline gap-1">
                <span className="text-2xl font-bold font-mono text-slate-900">
                  {forestMetrics.singleTreeTestAccuracy}%
                </span>
              </div>
              <span className="text-[10px] text-slate-400">Sin ensamble</span>
            </div>

            {/* Boost Gain */}
            <div className="bg-emerald-50/70 p-3 rounded-xl border border-emerald-100 col-span-2 sm:col-span-1">
              <span className="text-[11px] font-semibold text-emerald-800 uppercase tracking-wider block">
                Ganancia Ensamble
              </span>
              <div className="mt-1 flex items-baseline gap-1">
                <span className="text-2xl font-bold font-mono text-emerald-700">
                  {forestMetrics.accuracyGain > 0 ? `+${forestMetrics.accuracyGain}%` : `${forestMetrics.accuracyGain}%`}
                </span>
              </div>
              <span className="text-[10px] text-emerald-600 font-medium">Reducción de varianza</span>
            </div>
          </div>

          {/* OOB Score & Diagnosis */}
          {(() => {
            const badge = getStatusBadge(forestMetrics.diagnosis.status);
            return (
              <div className={`p-3.5 rounded-xl border ${badge.bg} flex flex-col gap-1.5 text-xs`}>
                <div className="flex items-center gap-2 font-bold">
                  {badge.icon}
                  <span>{forestMetrics.diagnosis.title}</span>
                </div>
                <p className="text-slate-700 leading-relaxed">
                  {forestMetrics.diagnosis.message}
                </p>
              </div>
            );
          })()}

          <div className="pt-2 border-t border-slate-100 grid grid-cols-2 gap-3 text-[11px] text-slate-600">
            <div>
              <span>Out-Of-Bag (OOB) Score: </span>
              <span className="font-mono font-bold text-slate-900">{forestMetrics.oobScore}%</span>
            </div>
            <div>
              <span>Árboles construidos: </span>
              <span className="font-bold text-slate-900">{forestMetrics.totalTrees}</span>
            </div>
            <div>
              <span>Profundidad promedio: </span>
              <span className="font-bold text-slate-900">{forestMetrics.avgDepth}</span>
            </div>
            <div>
              <span>Train Accuracy Bosque: </span>
              <span className="font-mono font-bold text-slate-900">{forestMetrics.trainAccuracy}%</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
