import React, { useState } from 'react';
import { RandomForestModel, TreeInForest } from '../algorithms/randomForest';
import { DataPoint2D, DatasetMeta } from '../types';
import { Trees, GitBranch, Vote, Check, Sparkles, Eye } from 'lucide-react';
import { TreeGraph } from './TreeGraph';

interface ForestEnsembleViewProps {
  forest: RandomForestModel;
  trainData: DataPoint2D[];
  testData: DataPoint2D[];
  datasetMeta: DatasetMeta;
}

export const ForestEnsembleView: React.FC<ForestEnsembleViewProps> = ({
  forest,
  trainData,
  testData,
  datasetMeta,
}) => {
  const [selectedTreeIdx, setSelectedTreeIdx] = useState<number>(0);

  const selectedTree: TreeInForest | undefined = forest.trees[selectedTreeIdx];

  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col gap-5">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3.5">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-indigo-50 text-indigo-700">
            <Trees className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-bold text-slate-900 text-sm">Explorador de Árboles del Bosque (Ensemble)</h3>
            <p className="text-xs text-slate-700">
              Examina cómo cada árbol individual fue entrenado con una muestra bootstrap diferente
            </p>
          </div>
        </div>
      </div>

      {/* Tree Selector Badges */}
      <div className="flex flex-col gap-2">
        <span className="text-xs font-semibold text-slate-700">
          Selecciona un árbol individual para inspeccionar su estructura interna:
        </span>
        <div className="flex flex-wrap gap-2 max-h-32 overflow-y-auto p-1 bg-slate-50 rounded-xl border border-slate-200/80">
          {forest.trees.map((tree, idx) => (
            <button
              key={idx}
              onClick={() => setSelectedTreeIdx(idx)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium flex items-center gap-1.5 transition-all ${
                selectedTreeIdx === idx
                  ? 'bg-indigo-600 text-white font-semibold shadow-xs'
                  : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
              }`}
            >
              <GitBranch className="w-3 h-3" />
              <span>Árbol #{idx + 1}</span>
              <span className={`text-[10px] px-1 py-0.2 rounded-xs ${
                selectedTreeIdx === idx ? 'bg-indigo-700 text-indigo-100' : 'bg-slate-100 text-slate-500'
              }`}>
                p={tree.treeDepth}
              </span>
            </button>
          ))}
        </div>
      </div>

      {/* Selected Tree Inspector */}
      {selectedTree && (
        <div className="flex flex-col gap-3">
          <div className="flex flex-wrap items-center justify-between gap-2 p-3 bg-indigo-50/60 rounded-xl border border-indigo-100 text-xs text-indigo-950">
            <div className="flex items-center gap-2 font-semibold">
              <Eye className="w-4 h-4 text-indigo-600" />
              <span>Estructura de Árbol #{selectedTree.index + 1}</span>
            </div>
            <div className="flex items-center gap-4 text-slate-600">
              <span>Profundidad: <strong className="text-slate-900">{selectedTree.treeDepth}</strong></span>
              <span>Hojas: <strong className="text-slate-900">{selectedTree.leafCount}</strong></span>
              <span>Muestras OOB (no vistas): <strong className="text-slate-900">{selectedTree.oobIndices.length}</strong></span>
            </div>
          </div>

          {/* Render individual tree */}
          <TreeGraph
            root={selectedTree.classifier.root}
            type="classification"
            classColors={{
              0: datasetMeta.targetClasses?.[0]?.color || '#ef4444',
              1: datasetMeta.targetClasses?.[1]?.color || '#10b981',
            }}
          />
        </div>
      )}

      {/* Didactic Box: Why Ensemble Works */}
      <div className="p-4 bg-slate-50 rounded-xl border border-slate-200 flex flex-col gap-2 text-xs">
        <div className="flex items-center gap-2 font-bold text-slate-900">
          <Sparkles className="w-4 h-4 text-indigo-600" />
          <span>La Didáctica del Ensamble: ¿Por qué múltiples árboles vencen a uno solo?</span>
        </div>
        <p className="text-slate-600 leading-relaxed">
          1. <strong>Bagging (Bootstrap Aggregation):</strong> Cada árbol ve aproximadamente el 63.2% de los datos únicos con repetición. Ningún árbol tiene la verdad absoluta de todo el conjunto.
        </p>
        <p className="text-slate-600 leading-relaxed">
          2. <strong>Cancelación de Errores:</strong> Un árbol solitario puede sobreajustarse a un punto ruidoso en la esquina, pero los otros {forest.trees.length - 1} árboles no vieron ese punto de la misma manera. En la votación, el ruido individual es aplastado por el consenso de la mayoría.
        </p>
      </div>
    </div>
  );
};
