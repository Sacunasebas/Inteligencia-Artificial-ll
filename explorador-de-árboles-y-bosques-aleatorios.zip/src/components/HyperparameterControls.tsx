import React from 'react';
import { ClassificationHyperparams, RegressionHyperparams, RandomForestHyperparams, ModelType } from '../types';
import { Sliders, Sparkles, AlertTriangle, ShieldCheck } from 'lucide-react';

interface HyperparameterControlsProps {
  modelType: ModelType;
  classParams?: ClassificationHyperparams;
  regParams?: RegressionHyperparams;
  forestParams?: RandomForestHyperparams;
  onChangeClassParams?: (params: ClassificationHyperparams) => void;
  onChangeRegParams?: (params: RegressionHyperparams) => void;
  onChangeForestParams?: (params: RandomForestHyperparams) => void;
  onApplyPreset?: (preset: 'underfit' | 'optimal' | 'overfit') => void;
}

export const HyperparameterControls: React.FC<HyperparameterControlsProps> = ({
  modelType,
  classParams,
  regParams,
  forestParams,
  onChangeClassParams,
  onChangeRegParams,
  onChangeForestParams,
  onApplyPreset,
}) => {
  return (
    <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col gap-5">
      {/* Header & Quick Presets */}
      <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3.5">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-lg bg-emerald-50 text-emerald-700">
            <Sliders className="w-4 h-4" />
          </div>
          <div>
            <h3 className="font-bold text-slate-900 text-sm">Control Didáctico de Hiperparámetros</h3>
            <p className="text-xs text-slate-700">Modifica los valores para observar el impacto en tiempo real</p>
          </div>
        </div>

        {/* Quick Didactic Presets */}
        <div className="flex items-center gap-1.5">
          <span className="text-xs text-slate-700 font-medium mr-1 hidden sm:inline">Preajustes:</span>
          <button
            onClick={() => onApplyPreset?.('underfit')}
            className="px-2.5 py-1 text-xs font-semibold rounded-lg bg-rose-50 text-rose-700 hover:bg-rose-100 border border-rose-200 transition-colors"
            title="Ajusta los hiperparámetros para provocar subajuste"
          >
            Subajuste
          </button>
          <button
            onClick={() => onApplyPreset?.('optimal')}
            className="px-2.5 py-1 text-xs font-semibold rounded-lg bg-emerald-50 text-emerald-700 hover:bg-emerald-100 border border-emerald-200 transition-colors"
            title="Ajusta los hiperparámetros hacia el punto dulce óptimo"
          >
            Óptimo
          </button>
          <button
            onClick={() => onApplyPreset?.('overfit')}
            className="px-2.5 py-1 text-xs font-semibold rounded-lg bg-amber-50 text-amber-700 hover:bg-amber-100 border border-amber-200 transition-colors"
            title="Ajusta los hiperparámetros para provocar sobreajuste"
          >
            Sobreajuste
          </button>
        </div>
      </div>

      {/* Classification Controls */}
      {modelType === 'classification_tree' && classParams && onChangeClassParams && (
        <div className="flex flex-col gap-4">
          {/* max_depth */}
          <div className="space-y-1.5">
            <div className="flex justify-between items-center text-xs">
              <span className="font-bold text-slate-800">
                max_depth <span className="text-slate-700 font-normal">(Profundidad Máxima)</span>
              </span>
              <span className="font-mono px-2 py-0.5 rounded-md bg-slate-100 text-slate-900 font-bold border border-slate-200">
                {classParams.maxDepth}
              </span>
            </div>
            <input
              type="range"
              min={1}
              max={10}
              step={1}
              value={classParams.maxDepth}
              onChange={(e) => onChangeClassParams({ ...classParams, maxDepth: Number(e.target.value) })}
              className="w-full accent-emerald-600 h-2 bg-slate-100 rounded-lg cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-700">
              <span>1 (Subajuste / 1 corte)</span>
              <span>4-5 (Equilibrio)</span>
              <span>10 (Sobreajuste / Árbol gigante)</span>
            </div>
            <p className="text-[11px] text-slate-700 bg-slate-50 p-2 rounded-lg border border-slate-100">
              💡 <strong>Impacto:</strong> Limita cuántas preguntas sucesivas puede encadenar el árbol. Un valor alto memoriza muestras aisladas; un valor bajo no captura la forma de los datos.
            </p>
          </div>

          {/* min_samples_leaf */}
          <div className="space-y-1.5">
            <div className="flex justify-between items-center text-xs">
              <span className="font-bold text-slate-800">
                min_samples_leaf <span className="text-slate-700 font-normal">(Muestras Mínimas por Hoja)</span>
              </span>
              <span className="font-mono px-2 py-0.5 rounded-md bg-slate-100 text-slate-900 font-bold border border-slate-200">
                {classParams.minSamplesLeaf}
              </span>
            </div>
            <input
              type="range"
              min={1}
              max={15}
              step={1}
              value={classParams.minSamplesLeaf}
              onChange={(e) => onChangeClassParams({ ...classParams, minSamplesLeaf: Number(e.target.value) })}
              className="w-full accent-emerald-600 h-2 bg-slate-100 rounded-lg cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-700">
              <span>1 (Permite hojas de 1 punto / ruido)</span>
              <span>≥ 5 (Suaviza fronteras y regulariza)</span>
            </div>
            <p className="text-[11px] text-slate-700 bg-slate-50 p-2 rounded-lg border border-slate-100">
              💡 <strong>Impacto:</strong> Una de las formas más efectivas de poda (pruning). Impide que el árbol aísle un solo punto atípico de entrenamiento.
            </p>
          </div>

          {/* min_samples_split */}
          <div className="space-y-1.5">
            <div className="flex justify-between items-center text-xs">
              <span className="font-bold text-slate-800">
                min_samples_split <span className="text-slate-700 font-normal">(Mínimo para Dividir un Nodo)</span>
              </span>
              <span className="font-mono px-2 py-0.5 rounded-md bg-slate-100 text-slate-900 font-bold border border-slate-200">
                {classParams.minSamplesSplit}
              </span>
            </div>
            <input
              type="range"
              min={2}
              max={25}
              step={1}
              value={classParams.minSamplesSplit}
              onChange={(e) => onChangeClassParams({ ...classParams, minSamplesSplit: Number(e.target.value) })}
              className="w-full accent-emerald-600 h-2 bg-slate-100 rounded-lg cursor-pointer"
            />
          </div>

          {/* criterion: gini vs entropy */}
          <div className="space-y-1.5 pt-1">
            <div className="flex justify-between items-center text-xs">
              <span className="font-bold text-slate-800">criterion (Criterio de Impureza)</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => onChangeClassParams({ ...classParams, criterion: 'gini' })}
                className={`py-1.5 px-3 rounded-lg text-xs font-semibold border transition-all ${
                  classParams.criterion === 'gini'
                    ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                }`}
              >
                Gini (Impureza de Gini)
              </button>
              <button
                type="button"
                onClick={() => onChangeClassParams({ ...classParams, criterion: 'entropy' })}
                className={`py-1.5 px-3 rounded-lg text-xs font-semibold border transition-all ${
                  classParams.criterion === 'entropy'
                    ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                }`}
              >
                Entropía (Information Gain)
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Regression Controls */}
      {modelType === 'regression_tree' && regParams && onChangeRegParams && (
        <div className="flex flex-col gap-4">
          {/* max_depth */}
          <div className="space-y-1.5">
            <div className="flex justify-between items-center text-xs">
              <span className="font-bold text-slate-800">
                max_depth <span className="text-slate-700 font-normal">(Profundidad Máxima)</span>
              </span>
              <span className="font-mono px-2 py-0.5 rounded-md bg-slate-100 text-slate-900 font-bold border border-slate-200">
                {regParams.maxDepth}
              </span>
            </div>
            <input
              type="range"
              min={1}
              max={10}
              step={1}
              value={regParams.maxDepth}
              onChange={(e) => onChangeRegParams({ ...regParams, maxDepth: Number(e.target.value) })}
              className="w-full accent-blue-600 h-2 bg-slate-100 rounded-lg cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-700">
              <span>1 (2 escalones / Subajuste)</span>
              <span>4-5 (Curva suave)</span>
              <span>10 (Escalón por cada outlier)</span>
            </div>
            <p className="text-[11px] text-slate-700 bg-slate-50 p-2 rounded-lg border border-slate-100">
              💡 <strong>Impacto en Regresión:</strong> En regresión, cada nivel adicional duplica los escalones constantes. Con `max_depth` alto, los escalones se vuelven microscópicos y persiguen el ruido.
            </p>
          </div>

          {/* min_samples_leaf */}
          <div className="space-y-1.5">
            <div className="flex justify-between items-center text-xs">
              <span className="font-bold text-slate-800">
                min_samples_leaf <span className="text-slate-700 font-normal">(Muestras Mínimas por Escalón)</span>
              </span>
              <span className="font-mono px-2 py-0.5 rounded-md bg-slate-100 text-slate-900 font-bold border border-slate-200">
                {regParams.minSamplesLeaf}
              </span>
            </div>
            <input
              type="range"
              min={1}
              max={15}
              step={1}
              value={regParams.minSamplesLeaf}
              onChange={(e) => onChangeRegParams({ ...regParams, minSamplesLeaf: Number(e.target.value) })}
              className="w-full accent-blue-600 h-2 bg-slate-100 rounded-lg cursor-pointer"
            />
            <p className="text-[11px] text-slate-700 bg-slate-50 p-2 rounded-lg border border-slate-100">
              💡 <strong>Impacto:</strong> Obliga a que la predicción de cada escalón sea el promedio de al menos N muestras, filtrando fluctuaciones aleatorias en los precios.
            </p>
          </div>

          {/* criterion: MSE vs MAE */}
          <div className="space-y-1.5 pt-1">
            <div className="flex justify-between items-center text-xs">
              <span className="font-bold text-slate-800">criterion (Criterio de Error)</span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => onChangeRegParams({ ...regParams, criterion: 'mse' })}
                className={`py-1.5 px-3 rounded-lg text-xs font-semibold border transition-all ${
                  regParams.criterion === 'mse'
                    ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                }`}
              >
                MSE (Media Cuadrática)
              </button>
              <button
                type="button"
                onClick={() => onChangeRegParams({ ...regParams, criterion: 'mae' })}
                className={`py-1.5 px-3 rounded-lg text-xs font-semibold border transition-all ${
                  regParams.criterion === 'mae'
                    ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                }`}
              >
                MAE (Mediana Absoluta)
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Random Forest Controls */}
      {modelType === 'random_forest' && forestParams && onChangeForestParams && (
        <div className="flex flex-col gap-4">
          {/* n_estimators */}
          <div className="space-y-1.5">
            <div className="flex justify-between items-center text-xs">
              <span className="font-bold text-slate-800">
                n_estimators <span className="text-slate-700 font-normal">(Número de Árboles en el Bosque)</span>
              </span>
              <span className="font-mono px-2 py-0.5 rounded-md bg-indigo-100 text-indigo-900 font-bold border border-indigo-200">
                {forestParams.nEstimators} árboles
              </span>
            </div>
            <input
              type="range"
              min={1}
              max={30}
              step={1}
              value={forestParams.nEstimators}
              onChange={(e) => onChangeForestParams({ ...forestParams, nEstimators: Number(e.target.value) })}
              className="w-full accent-indigo-600 h-2 bg-slate-100 rounded-lg cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-700">
              <span>1 (Árbol individual inestable)</span>
              <span>15-20 (Frontera suave y estable)</span>
              <span>30 (Alta estabilidad)</span>
            </div>
            <p className="text-[11px] text-slate-700 bg-slate-50 p-2 rounded-lg border border-slate-100">
              💡 <strong>Impacto:</strong> A más árboles, la frontera de decisión se vuelve suave y probabilística (no cuadrada ni abrupta). Reducimos la varianza sin perjudicar el sesgo.
            </p>
          </div>

          {/* max_depth of individual trees */}
          <div className="space-y-1.5">
            <div className="flex justify-between items-center text-xs">
              <span className="font-bold text-slate-800">
                max_depth <span className="text-slate-700 font-normal">(Profundidad de Cada Árbol)</span>
              </span>
              <span className="font-mono px-2 py-0.5 rounded-md bg-slate-100 text-slate-900 font-bold border border-slate-200">
                {forestParams.maxDepth}
              </span>
            </div>
            <input
              type="range"
              min={1}
              max={10}
              step={1}
              value={forestParams.maxDepth}
              onChange={(e) => onChangeForestParams({ ...forestParams, maxDepth: Number(e.target.value) })}
              className="w-full accent-indigo-600 h-2 bg-slate-100 rounded-lg cursor-pointer"
            />
          </div>

          {/* bootstrapRatio */}
          <div className="space-y-1.5">
            <div className="flex justify-between items-center text-xs">
              <span className="font-bold text-slate-800">
                bootstrap_samples <span className="text-slate-700 font-normal">(% Muestreo con Reemplazo)</span>
              </span>
              <span className="font-mono px-2 py-0.5 rounded-md bg-slate-100 text-slate-900 font-bold border border-slate-200">
                {(forestParams.bootstrapRatio * 100).toFixed(0)}%
              </span>
            </div>
            <input
              type="range"
              min={0.5}
              max={1.0}
              step={0.05}
              value={forestParams.bootstrapRatio}
              onChange={(e) => onChangeForestParams({ ...forestParams, bootstrapRatio: Number(e.target.value) })}
              className="w-full accent-indigo-600 h-2 bg-slate-100 rounded-lg cursor-pointer"
            />
            <p className="text-[11px] text-slate-700 bg-slate-50 p-2 rounded-lg border border-slate-100">
              💡 <strong>Bagging (Bootstrap):</strong> Cada árbol se entrena con un subconjunto aleatorio diferente de los datos. Las muestras restantes no vistas forman el conjunto <strong>Out-Of-Bag (OOB)</strong>.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
