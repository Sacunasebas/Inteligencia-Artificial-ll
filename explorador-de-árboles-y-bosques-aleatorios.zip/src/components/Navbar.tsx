import React from 'react';
import { ModelType } from '../types';
import { GitFork, TrendingUp, Trees, Trophy, BookOpen, Sparkles } from 'lucide-react';

interface NavbarProps {
  currentModule: ModelType;
  onChangeModule: (mod: ModelType) => void;
  showChallenges: boolean;
  onToggleChallenges: () => void;
  showGuide: boolean;
  onToggleGuide: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentModule,
  onChangeModule,
  showChallenges,
  onToggleChallenges,
  showGuide,
  onToggleGuide,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Brand */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-slate-900 text-emerald-400 flex items-center justify-center font-bold shadow-sm ring-1 ring-slate-800">
              <Trees className="w-5 h-5 text-emerald-400" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-slate-900 text-lg tracking-tight">ML Decision Lab</span>
                <span className="hidden sm:inline-block px-2 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 border border-emerald-200">
                  Pedagógico & Didáctico
                </span>
              </div>
              <p className="text-xs text-slate-700 hidden sm:block">
                Comprende el impacto real de los hiperparámetros con casos prácticos
              </p>
            </div>
          </div>

          {/* Module Navigation Tabs */}
          <nav className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-xl border border-slate-200/80">
            <button
              id="tab-classification"
              onClick={() => {
                onChangeModule('classification_tree');
              }}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-sm font-medium transition-all ${
                currentModule === 'classification_tree' && !showChallenges && !showGuide
                  ? 'bg-white text-slate-900 shadow-xs font-semibold'
                  : 'text-slate-800 hover:text-slate-900 hover:bg-white/50'
              }`}
            >
              <GitFork className="w-4 h-4 text-emerald-600" />
              <span>Árbol de Decisión</span>
            </button>

            <button
              id="tab-regression"
              onClick={() => {
                onChangeModule('regression_tree');
              }}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-sm font-medium transition-all ${
                currentModule === 'regression_tree' && !showChallenges && !showGuide
                  ? 'bg-white text-slate-900 shadow-xs font-semibold'
                  : 'text-slate-800 hover:text-slate-900 hover:bg-white/50'
              }`}
            >
              <TrendingUp className="w-4 h-4 text-blue-600" />
              <span>Árbol de Regresión</span>
            </button>

            <button
              id="tab-forest"
              onClick={() => {
                onChangeModule('random_forest');
              }}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-lg text-sm font-medium transition-all ${
                currentModule === 'random_forest' && !showChallenges && !showGuide
                  ? 'bg-white text-slate-900 shadow-xs font-semibold'
                  : 'text-slate-800 hover:text-slate-900 hover:bg-white/50'
              }`}
            >
              <Trees className="w-4 h-4 text-indigo-600" />
              <span>Random Forest</span>
            </button>
          </nav>

          {/* Action buttons: Challenges & Guide */}
          <div className="flex items-center gap-2">
            <button
              id="btn-challenges"
              onClick={onToggleChallenges}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                showChallenges
                  ? 'bg-amber-500 text-white border-amber-600 shadow-xs'
                  : 'bg-amber-50 text-amber-900 border-amber-200 hover:bg-amber-100'
              }`}
              title="Retos prácticos con metas de rendimiento"
            >
              <Trophy className="w-3.5 h-3.5 text-amber-600" />
              <span className="hidden md:inline">Retos Didácticos</span>
            </button>

            <button
              id="btn-guide"
              onClick={onToggleGuide}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border transition-all ${
                showGuide
                  ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
                  : 'bg-white text-slate-800 border-slate-200 hover:bg-slate-50'
              }`}
              title="Guía conceptual de hiperparámetros"
            >
              <BookOpen className="w-3.5 h-3.5 text-slate-700" />
              <span className="hidden md:inline">Guía Teórica</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
