/**
 * Types and interfaces for the Decision Tree, Regression Tree, and Random Forest didactic app.
 */

export type ModelType = 'classification_tree' | 'regression_tree' | 'random_forest';

export interface DataPoint2D {
  id: number;
  x1: number; // e.g. Ingreso mensual (k$) or Metros cuadrados
  x2: number; // e.g. Historial crediticio or Antigüedad
  y: number;  // 0 or 1 for classification; continuous number for regression
  split: 'train' | 'test';
}

export interface DatasetMeta {
  id: string;
  name: string;
  category: 'classification' | 'regression';
  description: string;
  feature1Name: string;
  feature1Unit: string;
  feature1Range: [number, number];
  feature2Name: string;
  feature2Unit: string;
  feature2Range: [number, number];
  targetName: string;
  targetClasses?: { [key: number]: { label: string; color: string; badge: string } };
  targetUnit?: string;
}

// Tree Node Structure
export interface TreeNode {
  id: string;
  isLeaf: boolean;
  depth: number;
  samples: number;
  trainIndices: number[];
  
  // Classification specific
  classCounts?: { [cls: number]: number };
  impurity?: number; // Gini or Entropy
  predictedClass?: number;
  classProbabilities?: { [cls: number]: number };
  
  // Regression specific
  predictedValue?: number;
  mse?: number;

  // Split details (for internal nodes)
  featureIndex?: 0 | 1;
  featureName?: string;
  threshold?: number;
  leftChild?: TreeNode;
  rightChild?: TreeNode;

  // Layout coordinates for SVG rendering
  x?: number;
  y?: number;
  width?: number;
}

// Hyperparameters for Classification Tree
export interface ClassificationHyperparams {
  maxDepth: number;          // 1 to 10
  minSamplesSplit: number;   // 2 to 30
  minSamplesLeaf: number;    // 1 to 20
  criterion: 'gini' | 'entropy';
}

// Hyperparameters for Regression Tree
export interface RegressionHyperparams {
  maxDepth: number;          // 1 to 10
  minSamplesSplit: number;   // 2 to 30
  minSamplesLeaf: number;    // 1 to 20
  criterion: 'mse' | 'mae';
}

// Hyperparameters for Random Forest
export interface RandomForestHyperparams {
  nEstimators: number;       // 1 to 30
  maxDepth: number;          // 1 to 10
  minSamplesLeaf: number;    // 1 to 15
  bootstrapRatio: number;    // 0.5 to 1.0 (e.g. 0.8)
  maxFeatures: 'all' | 'sqrt'; // 'all' (2 features) or 'sqrt' (1 feature per split)
}

// Metrics
export interface ClassificationMetrics {
  trainAccuracy: number;
  testAccuracy: number;
  overfittingGap: number; // trainAcc - testAcc
  confusionMatrix: {
    tp: number;
    fp: number;
    fn: number;
    tn: number;
  };
  treeDepth: number;
  leafCount: number;
  totalNodes: number;
  diagnosis: {
    status: 'underfitting' | 'optimal' | 'mild_overfit' | 'severe_overfit';
    title: string;
    message: string;
    advice: string;
  };
}

export interface RegressionMetrics {
  trainMse: number;
  testMse: number;
  trainR2: number;
  testR2: number;
  trainRmse: number;
  testRmse: number;
  overfittingGap: number; // testMse - trainMse
  treeDepth: number;
  leafCount: number;
  diagnosis: {
    status: 'underfitting' | 'optimal' | 'mild_overfit' | 'severe_overfit';
    title: string;
    message: string;
    advice: string;
  };
}

export interface ForestMetrics {
  trainAccuracy: number;
  testAccuracy: number;
  singleTreeTestAccuracy: number; // for side-by-side comparison
  accuracyGain: number; // testAcc - singleTreeTestAcc
  oobScore: number;
  totalTrees: number;
  avgDepth: number;
  diagnosis: {
    status: 'low_trees' | 'high_trees_optimal' | 'overfitted_individual';
    title: string;
    message: string;
  };
}

export interface PedagogicalChallenge {
  id: string;
  title: string;
  module: ModelType;
  description: string;
  initialParams: any;
  targetCondition: string;
  checkCompletion: (metrics: any) => boolean;
  hint: string;
  solutionExplanation: string;
}
